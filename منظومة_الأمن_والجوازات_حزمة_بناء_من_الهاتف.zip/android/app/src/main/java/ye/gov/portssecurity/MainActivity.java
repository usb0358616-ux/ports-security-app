package ye.gov.portssecurity;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
