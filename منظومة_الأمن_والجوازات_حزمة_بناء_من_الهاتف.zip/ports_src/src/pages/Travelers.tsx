import { useState, useRef, useEffect, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Traveler, TravelerCategory, MovementType } from '@/lib/types';
import { 
  getTravelers, saveTravelers, generateId, normalizeArabic, getReports, saveReports, 
  formatTravelerFullName, isNonYemeni, checkTravelerExpirations, getDaysUntil,
  sanitizeAndClassifyTraveler 
} from '@/lib/storage';
import { YEMEN_GOVERNORATES, COUNTRIES, ID_TYPES } from '@/lib/constants';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { 
  Plus, Upload, Search, Printer, Trash2, AlertCircle, Scan, Link as LinkIcon, 
  FileText, Globe, User, MapPin, Download, Save, Image as ImageIcon, FileJson, 
  Sparkles, Users, AlertTriangle, HeartHandshake, CreditCard, ChevronRight, 
  ChevronLeft, ChevronsRight, ChevronsLeft, Calendar, FileCheck, CheckCircle2, 
  Clock, X, Eye, LogIn, LogOut, Heart, UserPlus, ShieldAlert, Award, Copy, Layers
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { QRCodeCanvas } from 'qrcode.react';
import { scanPassport } from '@/services/geminiService';
import { DeleteConfirmation } from '@/components/DeleteConfirmation';
import { exportToExcel, exportToPDF, exportToImage, exportToWord, exportToCSV, exportToJSON } from '@/lib/exportUtils';
import { PrintableTraveler } from '@/components/PrintableTraveler';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { SmartExcelImportModal, ImportMode } from '@/components/SmartExcelImportModal';
import { FileSpreadsheet, ShieldCheck } from 'lucide-react';


const PAGE_SIZE = 50;

export type TabKey = TravelerCategory | 'expiring';

export const CATEGORY_CONFIG: Record<TabKey, { label: string; shortLabel: string; icon: any; color: string; bg: string; border: string }> = {
  traveler: { 
    label: 'المسافرين (كافة السجلات)', 
    shortLabel: 'المسافرين',
    icon: Users, 
    color: 'text-blue-700', 
    bg: 'bg-blue-50',
    border: 'border-blue-200'
  },
  foreigner: { 
    label: 'الأجانب (قاعدة غير اليمنيين)', 
    shortLabel: 'الأجانب',
    icon: Globe, 
    color: 'text-emerald-700', 
    bg: 'bg-emerald-50',
    border: 'border-emerald-200'
  },
  entry: { 
    label: 'حركة الدخول (قادمون)', 
    shortLabel: 'حركة الدخول',
    icon: LogIn, 
    color: 'text-teal-700', 
    bg: 'bg-teal-50',
    border: 'border-teal-200'
  },
  exit: { 
    label: 'حركة الخروج (مغادرون)', 
    shortLabel: 'حركة الخروج',
    icon: LogOut, 
    color: 'text-indigo-700', 
    bg: 'bg-indigo-50',
    border: 'border-indigo-200'
  },
  visa_renewal: { 
    label: 'التأشيرات (إصدار وتجديد)', 
    shortLabel: 'التأشيرات',
    icon: FileCheck, 
    color: 'text-purple-700', 
    bg: 'bg-purple-50',
    border: 'border-purple-200'
  },
  residency_renewal: { 
    label: 'الإقامات (إصدار وتجديد)', 
    shortLabel: 'الإقامات',
    icon: CreditCard, 
    color: 'text-cyan-700', 
    bg: 'bg-cyan-50',
    border: 'border-cyan-200'
  },
  marriage_yemeni_woman: { 
    label: 'طلب زواج بيمنية', 
    shortLabel: 'زواج بيمنية',
    icon: Heart, 
    color: 'text-rose-700', 
    bg: 'bg-rose-50',
    border: 'border-rose-200'
  },
  marriage_foreigner: { 
    label: 'طلب زواج بأجنبي', 
    shortLabel: 'زواج بأجنبي',
    icon: HeartHandshake, 
    color: 'text-pink-700', 
    bg: 'bg-pink-50',
    border: 'border-pink-200'
  },
  citizenship_application: { 
    label: 'طالب جنسية يمنية', 
    shortLabel: 'طلب جنسية',
    icon: Award, 
    color: 'text-amber-700', 
    bg: 'bg-amber-50',
    border: 'border-amber-200'
  },
  refugee: { 
    label: 'اللاجئين (UNHCR)', 
    shortLabel: 'اللاجئين',
    icon: UserPlus, 
    color: 'text-orange-700', 
    bg: 'bg-orange-50',
    border: 'border-orange-200'
  },
  illegal_immigrant: { 
    label: 'المهاجرين غير الشرعيين', 
    shortLabel: 'غير شرعيين',
    icon: AlertTriangle, 
    color: 'text-red-700', 
    bg: 'bg-red-50',
    border: 'border-red-200'
  },
  expiring: { 
    label: 'تنبيهات الانتهاء (أسبوع فأقل)', 
    shortLabel: 'تنبيهات الانتهاء',
    icon: ShieldAlert, 
    color: 'text-red-800', 
    bg: 'bg-red-100',
    border: 'border-red-400'
  },
};

const createEmptyTraveler = (category: TravelerCategory = 'traveler'): Partial<Traveler> => {
  const isForeign = category === 'foreigner' || category === 'marriage_yemeni_woman';
  return {
    category,
    movementType: category === 'entry' ? 'دخول' : category === 'exit' ? 'خروج' : 'عام',
    fullName: '',
    firstName: '',
    secondName: '',
    thirdName: '',
    fourthName: '',
    lastName: '',
    age: 30,
    idNumber: '',
    idType: isForeign ? 'جواز أجنبي' : category === 'illegal_immigrant' ? 'بدون وثائق رسمية' : category === 'refugee' ? 'كرت لجوء أممي' : 'جواز سفر',
    country: isForeign ? 'مصر' : category === 'illegal_immigrant' ? 'إثيوبيا' : category === 'refugee' ? 'الصومال' : 'اليمن',
    governorate: '',
    phone: '',
    passportIssueDate: '',
    passportExpiryDate: '',
    visaIssueDate: '',
    visaExpiryDate: '',
    residencyIssueDate: '',
    residencyExpiryDate: '',
    vettingResult: 'سليم أمنياً - لا توجد قيود مسجلة',
    destination: 'الجمهورية اليمنية',
    visitReason: '',
    investigatingOfficer: 'ضابط المنافذ المناوب',
    travelAllowed: category === 'illegal_immigrant' ? 'لا' : 'نعم',
    center: 'منفذ الوديعة البري',
    agency: '',
    receiveDate: new Date().toISOString().split('T')[0],
    status: 'معتمد',

    // Movement details
    entryPort: 'منفذ الوديعة البري',
    entryDate: new Date().toISOString().split('T')[0],
    originCountry: 'المملكة العربية السعودية',
    entryCarrierOrFlight: '',
    entryPurpose: 'زيارة',
    allowedStayDays: 90,

    exitPort: 'منفذ الوديعة البري',
    exitDate: new Date().toISOString().split('T')[0],
    destinationCountry: 'المملكة العربية السعودية',
    exitCarrierOrFlight: '',
    exitPurpose: 'سفر',
    exitPermitNumber: '',

    // Foreigners
    sponsorName: '',
    sponsorPhone: '',
    sponsorAddress: '',

    // Illegal immigrants
    interceptionPoint: 'نقطة صحراء العبر الحدودية',
    interceptionDate: new Date().toISOString().split('T')[0],
    smugglingRoute: '',
    biometricsTaken: 'نعم',
    healthStatus: 'سليم',
    deportationStatus: 'قيد التحقيق',
    interceptingUnit: 'دورية أمن المنافذ',

    // Refugees
    unhcrNumber: '',
    refugeeStatus: 'طالب لجوء',
    campLocation: 'مخيم خرز',
    aidOrganization: 'المفوضية السامية (UNHCR)',
    dependentsCount: 0,

    // Visas
    visaNumber: '',
    requestedVisaPeriod: '6 أشهر',
    visaExtensionReason: '',
    visaFeeStatus: 'مسدد',
    visaRequestStatus: 'قيد المراجعة',
    visaReceiptNumber: '',

    // Residencies
    residencyNumber: '',
    profession: '',
    employerName: '',
    requestedResidencyPeriod: 'سنة واحدة',
    medicalTestStatus: 'لائق',
    residencyFeeStatus: 'مسدد',
    residencyRequestStatus: 'قيد الإجراء',
    residencyReceiptNumber: '',

    // Marriage to Yemeni Woman
    spouseFullName: '',
    spouseIdNumber: '',
    marriageContractNumber: '',
    marriageContractDate: '',
    courtOrAuthority: 'المحكمة الشرعية الابتدائية',
    marriageApprovalStatus: 'قيد الدراسة والتحري',
    marriageGuardianName: '',

    // Marriage to Foreigner
    foreignSpouseName: '',
    foreignSpouseNationality: 'المملكة المتحدة',
    foreignSpousePassport: '',
    foreignMarriageApprovalNumber: '',

    // Yemeni Citizenship
    citizenshipFileNumber: '',
    citizenshipApplicationDate: new Date().toISOString().split('T')[0],
    residenceYearsInYemen: 10,
    motherNationality: 'اليمن',
    citizenshipReason: 'إقامة طويلة مستمرة',
    citizenshipStatus: 'قيد البحث والتحري',
    additionalData: '',
    notes: '',
  };
};

export default function Travelers() {
  const [searchParams, setSearchParams] = useSearchParams();
  const rawTab = searchParams.get('tab') || 'traveler';
  const activeTab: TabKey = (rawTab in CATEGORY_CONFIG) ? (rawTab as TabKey) : 'traveler';

  const [travelers, setTravelers] = useState<Traveler[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [governorateFilter, setGovernorateFilter] = useState('all');
  const [allowedFilter, setAllowedFilter] = useState('all');
  const [movementFilter, setMovementFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isLinkReportOpen, setIsLinkReportOpen] = useState(false);
  const [isCreateReportOpen, setIsCreateReportOpen] = useState(false);
  const [selectedTraveler, setSelectedTraveler] = useState<Traveler | null>(null);
  const [formData, setFormData] = useState<Partial<Traveler>>(createEmptyTraveler(activeTab === 'expiring' ? 'traveler' : activeTab));
  const [isScanning, setIsScanning] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [printingTraveler, setPrintingTraveler] = useState<Traveler | null>(null);
  const [allReports, setAllReports] = useState<any[]>([]);
  const [selectedReportIds, setSelectedReportIds] = useState<string[]>([]);
  const [newReportData, setNewReportData] = useState({
    title: '',
    description: '',
    type: 'ضبط أمني عام'
  });

  // Smart Excel and Vetting Import Modal States
  const [isSmartImportOpen, setIsSmartImportOpen] = useState(false);
  const [parsedExcelRows, setParsedExcelRows] = useState<any[]>([]);
  const [parsedExcelCols, setParsedExcelCols] = useState<string[]>([]);
  const [importFileName, setImportFileName] = useState<string>('');
  const [directVettingFileTrigger, setDirectVettingFileTrigger] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const excelImportRef = useRef<HTMLInputElement>(null);
  const vettingImportRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();


  useEffect(() => {
    const list = getTravelers();
    setTravelers(list);
    setAllReports(getReports());
  }, []);

  // When tab query changes, reset page to 1
  useEffect(() => {
    setCurrentPage(1);
  }, [activeTab]);

  const handleTabChange = (key: TabKey) => {
    setSearchParams({ tab: key });
  };

  // Real-time counter for each category + expiring documents
  const categoryCounts = useMemo(() => {
    const counts: Record<TabKey, number> = {
      traveler: travelers.length, // Base database contains ALL
      foreigner: 0,
      entry: 0,
      exit: 0,
      visa_renewal: 0,
      residency_renewal: 0,
      marriage_yemeni_woman: 0,
      marriage_foreigner: 0,
      citizenship_application: 0,
      refugee: 0,
      illegal_immigrant: 0,
      expiring: 0,
    };

    travelers.forEach(t => {
      // Expiration check
      if (checkTravelerExpirations(t).hasAlert) {
        counts.expiring++;
      }

      // Foreigners: Any non-Yemeni OR isForeigner OR in categories
      if (t.isForeigner || isNonYemeni(t.country) || t.category === 'foreigner' || t.additionalCategories?.includes('foreigner')) {
        counts.foreigner++;
      }

      // Entry
      if (t.movementType === 'دخول' || t.category === 'entry' || t.additionalCategories?.includes('entry')) {
        counts.entry++;
      }

      // Exit
      if (t.movementType === 'خروج' || t.category === 'exit' || t.additionalCategories?.includes('exit')) {
        counts.exit++;
      }

      // Visas
      if (t.category === 'visa_renewal' || t.additionalCategories?.includes('visa_renewal') || Boolean(t.visaNumber && t.visaNumber.trim())) {
        counts.visa_renewal++;
      }

      // Residencies
      if (t.category === 'residency_renewal' || t.additionalCategories?.includes('residency_renewal') || Boolean(t.residencyNumber && t.residencyNumber.trim())) {
        counts.residency_renewal++;
      }

      // Marriage to Yemeni Woman
      if (t.category === 'marriage_yemeni_woman' || t.additionalCategories?.includes('marriage_yemeni_woman') || Boolean(t.spouseFullName && t.spouseFullName.trim())) {
        counts.marriage_yemeni_woman++;
      }

      // Marriage to Foreigner
      if (t.category === 'marriage_foreigner' || t.additionalCategories?.includes('marriage_foreigner') || Boolean(t.foreignSpouseName && t.foreignSpouseName.trim())) {
        counts.marriage_foreigner++;
      }

      // Citizenship Application
      if (t.category === 'citizenship_application' || t.additionalCategories?.includes('citizenship_application') || Boolean(t.citizenshipFileNumber && t.citizenshipFileNumber.trim())) {
        counts.citizenship_application++;
      }

      // Refugee
      if (t.category === 'refugee' || t.additionalCategories?.includes('refugee')) {
        counts.refugee++;
      }

      // Illegal Immigrant
      if (t.category === 'illegal_immigrant' || t.additionalCategories?.includes('illegal_immigrant')) {
        counts.illegal_immigrant++;
      }
    });

    return counts;
  }, [travelers]);

  // Filtered Travelers List
  const filteredTravelers = useMemo(() => {
    return travelers.filter(t => {
      // 1. Tab / Category Filter
      if (activeTab === 'traveler') {
        // Base Master Database: includes all travelers!
      } else if (activeTab === 'foreigner') {
        const isForeign = t.isForeigner || isNonYemeni(t.country) || t.category === 'foreigner' || t.additionalCategories?.includes('foreigner');
        if (!isForeign) return false;
      } else if (activeTab === 'entry') {
        const isEntry = t.movementType === 'دخول' || t.category === 'entry' || t.additionalCategories?.includes('entry');
        if (!isEntry) return false;
      } else if (activeTab === 'exit') {
        const isExit = t.movementType === 'خروج' || t.category === 'exit' || t.additionalCategories?.includes('exit');
        if (!isExit) return false;
      } else if (activeTab === 'visa_renewal') {
        const isVisa = t.category === 'visa_renewal' || t.additionalCategories?.includes('visa_renewal') || Boolean(t.visaNumber && t.visaNumber.trim());
        if (!isVisa) return false;
      } else if (activeTab === 'residency_renewal') {
        const isRes = t.category === 'residency_renewal' || t.additionalCategories?.includes('residency_renewal') || Boolean(t.residencyNumber && t.residencyNumber.trim());
        if (!isRes) return false;
      } else if (activeTab === 'marriage_yemeni_woman') {
        const isMarryYem = t.category === 'marriage_yemeni_woman' || t.additionalCategories?.includes('marriage_yemeni_woman') || Boolean(t.spouseFullName && t.spouseFullName.trim());
        if (!isMarryYem) return false;
      } else if (activeTab === 'marriage_foreigner') {
        const isMarryFrg = t.category === 'marriage_foreigner' || t.additionalCategories?.includes('marriage_foreigner') || Boolean(t.foreignSpouseName && t.foreignSpouseName.trim());
        if (!isMarryFrg) return false;
      } else if (activeTab === 'citizenship_application') {
        const isCit = t.category === 'citizenship_application' || t.additionalCategories?.includes('citizenship_application') || Boolean(t.citizenshipFileNumber && t.citizenshipFileNumber.trim());
        if (!isCit) return false;
      } else if (activeTab === 'refugee') {
        const isRef = t.category === 'refugee' || t.additionalCategories?.includes('refugee');
        if (!isRef) return false;
      } else if (activeTab === 'illegal_immigrant') {
        const isImm = t.category === 'illegal_immigrant' || t.additionalCategories?.includes('illegal_immigrant');
        if (!isImm) return false;
      } else if (activeTab === 'expiring') {
        const exp = checkTravelerExpirations(t);
        if (!exp.hasAlert) return false;
      }

      // 2. Search Query Filter
      if (searchQuery.trim()) {
        const q = normalizeArabic(searchQuery.toLowerCase().trim());
        const full = normalizeArabic((t.fullName || formatTravelerFullName(t)).toLowerCase());
        const idNo = (t.idNumber || '').toLowerCase();
        const phone = (t.phone || '').toLowerCase();
        const country = normalizeArabic((t.country || '').toLowerCase());
        const sponsor = normalizeArabic((t.sponsorName || '').toLowerCase());
        const spouse = normalizeArabic((t.spouseFullName || t.foreignSpouseName || '').toLowerCase());
        const visa = (t.visaNumber || '').toLowerCase();
        const res = (t.residencyNumber || '').toLowerCase();
        const extra = normalizeArabic((t.additionalData || '').toLowerCase());

        const matches = 
          full.includes(q) || 
          idNo.includes(q) || 
          phone.includes(q) || 
          country.includes(q) || 
          sponsor.includes(q) || 
          spouse.includes(q) || 
          visa.includes(q) || 
          res.includes(q) ||
          extra.includes(q);

        if (!matches) return false;
      }

      // 3. Governorate filter
      if (governorateFilter !== 'all' && t.governorate !== governorateFilter) {
        return false;
      }

      // 4. Allowed filter
      if (allowedFilter !== 'all' && t.travelAllowed !== allowedFilter) {
        return false;
      }

      // 5. Movement filter
      if (movementFilter !== 'all' && t.movementType !== movementFilter) {
        return false;
      }

      return true;
    });
  }, [travelers, activeTab, searchQuery, governorateFilter, allowedFilter, movementFilter]);

  // 50 rows per page pagination
  const totalPages = Math.max(1, Math.ceil(filteredTravelers.length / PAGE_SIZE));
  const paginatedTravelers = useMemo(() => {
    const start = (currentPage - 1) * PAGE_SIZE;
    return filteredTravelers.slice(start, start + PAGE_SIZE);
  }, [filteredTravelers, currentPage]);

  // Open Add Modal from ANY tab
  const handleOpenAddModal = () => {
    setSelectedTraveler(null);
    const defaultCat: TravelerCategory = activeTab === 'expiring' ? 'traveler' : (activeTab as TravelerCategory);
    setFormData(createEmptyTraveler(defaultCat));
    setIsAddModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEditModal = (traveler: Traveler) => {
    setSelectedTraveler(traveler);
    setFormData({
      ...traveler,
      fullName: formatTravelerFullName(traveler)
    });
    setIsAddModalOpen(true);
  };

  // Save Traveler - Automatic Cross-Classification
  const handleSaveTraveler = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName && !formData.firstName) {
      toast({ title: 'خطأ', description: 'يرجى إدخال اسم المسافر / صاحب المعاملة', variant: 'destructive' });
      return;
    }

    const sanitized = sanitizeAndClassifyTraveler({
      ...formData,
      id: selectedTraveler?.id || `t-${generateId()}`,
    });

    let updatedList: Traveler[];
    if (selectedTraveler) {
      updatedList = travelers.map(t => t.id === selectedTraveler.id ? sanitized : t);
      toast({ 
        title: 'تم التحديث بنجاح', 
        description: `تم حفظ وتحديث بيانات "${sanitized.fullName}" وإعادة توجيهه تلقائياً للأقسام المعنية.` 
      });
    } else {
      updatedList = [sanitized, ...travelers];
      toast({ 
        title: 'تمت الإضافة بنجاح', 
        description: `تم حفظ "${sanitized.fullName}". تم ربطه بتبويب المسافرين${sanitized.isForeigner ? '، وتبويب الأجانب' : ''}، وكافة الأقسام المرتبطة بنوع المعاملة.` 
      });
    }

    saveTravelers(updatedList);
    setTravelers(updatedList);
    setIsAddModalOpen(false);
  };

  // Delete
  const handleDeleteTraveler = () => {
    if (!deleteId) return;
    const updated = travelers.filter(t => t.id !== deleteId);
    saveTravelers(updated);
    setTravelers(updated);
    setDeleteId(null);
    toast({ title: 'تم الحذف', description: 'تم حذف السجل بنجاح' });
  };

  // Quick Print
  const handlePrint = (traveler: Traveler) => {
    setPrintingTraveler(traveler);
    setTimeout(() => {
      window.print();
    }, 200);
  };

  // Passport OCR with Gemini
  const handlePassportScan = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsScanning(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        try {
          const result = await scanPassport(base64Data, file.type);
          if (result) {
            setFormData(prev => ({
              ...prev,
              fullName: result.fullName || prev.fullName,
              firstName: result.firstName || prev.firstName,
              secondName: result.secondName || prev.secondName,
              thirdName: result.thirdName || prev.thirdName,
              fourthName: result.fourthName || prev.fourthName,
              lastName: result.lastName || prev.lastName,
              idNumber: result.passportNumber || prev.idNumber,
              country: result.nationality || prev.country,
              age: result.age ? Number(result.age) : prev.age,
              passportIssueDate: result.issueDate || prev.passportIssueDate,
              passportExpiryDate: result.expiryDate || prev.passportExpiryDate,
              idType: 'جواز سفر',
            }));
            toast({ title: 'نجح الفحص الذكي', description: 'تم استخراج بيانات الجواز وتعبئة الحقول آلياً.' });
          }
        } catch (err: any) {
          toast({ title: 'تنبيه الفحص', description: 'تعذر استخراج البيانات آلياً، يرجى الإدخال يدوياً.', variant: 'destructive' });
        } finally {
          setIsScanning(false);
        }
      };
      reader.readAsDataURL(file);
    } catch {
      setIsScanning(false);
    }
  };

  // Smart Excel File Loader
  const handleExcelFileSelected = (e: React.ChangeEvent<HTMLInputElement>, isVettingOnly = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportFileName(file.name);
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        
        // Parse rows and extract headers
        const data: any[] = XLSX.utils.sheet_to_json(ws, { defval: '' });
        if (!data || data.length === 0) {
          toast({ title: 'تنبيه', description: 'الملف المختار فارغ أو لا يحتوي على صفوف بيانات.', variant: 'destructive' });
          return;
        }

        // Get all unique column names from the first few rows
        const colsSet = new Set<string>();
        data.slice(0, 10).forEach(row => {
          Object.keys(row).forEach(k => colsSet.add(k));
        });
        const detectedCols = Array.from(colsSet);

        setParsedExcelRows(data);
        setParsedExcelCols(detectedCols);
        setDirectVettingFileTrigger(isVettingOnly);
        setIsSmartImportOpen(true);
      } catch (err: any) {
        toast({ title: 'خطأ', description: 'تعذر قراءة ملف الإكسل: ' + err.message, variant: 'destructive' });
      }
    };
    reader.readAsBinaryString(file);
    // Reset file input so user can pick the same file again if needed
    e.target.value = '';
  };

  // Execute Confirmed Smart Import & Auto Routing
  const handleConfirmSmartImport = (
    mappedRows: any[], 
    importMode: ImportMode, 
    targetDefaultCategory: string
  ) => {
    if (importMode === 'vetting_only') {
      // Vetting mode: Update existing records by matching idNumber or fullName
      let matchedCount = 0;
      let newAddedCount = 0;

      const currentTravelersMap = new Map<string, Traveler>();
      travelers.forEach(t => {
        if (t.idNumber) currentTravelersMap.set(t.idNumber.trim(), t);
      });

      const updatedList = [...travelers];

      mappedRows.forEach(row => {
        const docNo = row.idNumber ? String(row.idNumber).trim() : '';
        const vettingResult = row.vettingResult || 'مباينة أمنية مستوردة';
        const travelAllowed = row.travelAllowed || (vettingResult.includes('منع') || vettingResult.includes('مطلوب') ? 'لا' : 'نعم');

        if (docNo && currentTravelersMap.has(docNo)) {
          // Existing traveler found - update their vetting result and travel permission
          const existing = currentTravelersMap.get(docNo)!;
          const idx = updatedList.findIndex(t => t.id === existing.id);
          if (idx !== -1) {
            const mergedAdditional = [updatedList[idx].additionalData, row.additionalData].filter(Boolean).join('\n');
            updatedList[idx] = {
              ...updatedList[idx],
              vettingResult,
              travelAllowed: travelAllowed as any,
              additionalData: mergedAdditional,
              updatedAt: new Date().toISOString(),
            };
            matchedCount++;
          }
        } else {
          // No match: add as a new vetted traveler entry
          const newVetted = sanitizeAndClassifyTraveler({
            id: `vet-${generateId()}`,
            category: (targetDefaultCategory as TravelerCategory) || 'traveler',
            fullName: row.fullName || (row.firstName ? `${row.firstName} ${row.lastName || ''}`.trim() : 'مسافر مستورد بالمباينة'),
            idNumber: docNo,
            idType: row.idType || 'جواز سفر',
            country: row.country || 'اليمن',
            vettingResult,
            travelAllowed: travelAllowed as any,
            movementType: row.movementType || 'دخول',
            passportIssueDate: row.passportIssueDate || '',
            passportExpiryDate: row.passportExpiryDate || '',
            visaExpiryDate: row.visaExpiryDate || '',
            residencyExpiryDate: row.residencyExpiryDate || '',
            additionalData: row.additionalData || '',
          });
          updatedList.unshift(newVetted);
          newAddedCount++;
        }
      });

      saveTravelers(updatedList);
      setTravelers(updatedList);
      toast({
        title: 'اكتمل استيراد المباينة بنجاح',
        description: `تم تحديث المباينة لـ ${matchedCount} سجل مسافر مطابق، وإضافة ${newAddedCount} سجل فحص جديد.`,
      });
      return;
    }

    // Comprehensive Smart Import: All records auto-classified into travelers, foreigners, entry/exit, visas, residencies, etc.
    const newProcessedTravelers: Traveler[] = mappedRows.map(row => {
      const explicitFullName = row.fullName ? String(row.fullName).trim() : '';
      const reconstructedFullName = explicitFullName || [
        row.firstName,
        row.secondName,
        row.thirdName,
        row.fourthName,
        row.lastName
      ].filter(Boolean).join(' ').trim();

      const country = row.country ? String(row.country).trim() : 'اليمن';
      const movementType = (row.movementType === 'خروج' || targetDefaultCategory === 'exit') 
        ? 'خروج' 
        : (row.movementType === 'دخول' || targetDefaultCategory === 'entry') 
        ? 'دخول' 
        : 'عام';

      return sanitizeAndClassifyTraveler({
        id: `imp-${generateId()}`,
        category: (targetDefaultCategory as TravelerCategory) || 'traveler',
        fullName: reconstructedFullName || 'مسافر غير مسمى',
        firstName: row.firstName || reconstructedFullName.split(' ')[0] || '',
        secondName: row.secondName || reconstructedFullName.split(' ')[1] || '',
        thirdName: row.thirdName || reconstructedFullName.split(' ')[2] || '',
        fourthName: row.fourthName || reconstructedFullName.split(' ')[3] || '',
        lastName: row.lastName || reconstructedFullName.split(' ').slice(4).join(' ') || '',
        idNumber: row.idNumber ? String(row.idNumber).trim() : '',
        idType: row.idType || 'جواز سفر',
        country,
        age: Number(row.age) || 30,
        phone: row.phone ? String(row.phone) : '',
        governorate: row.governorate || '',
        
        // Movements & Port
        movementType,
        entryPort: row.entryPort || (movementType === 'دخول' ? 'منفذ الوديعة البري' : undefined),
        entryDate: row.entryDate || (movementType === 'دخول' ? new Date().toISOString().split('T')[0] : undefined),
        originCountry: row.originCountry || '',
        entryCarrierOrFlight: row.entryCarrierOrFlight || '',
        entryPurpose: row.entryPurpose || 'سفر وزيارة',

        exitPort: row.exitPort || (movementType === 'خروج' ? 'منفذ الوديعة البري' : undefined),
        exitDate: row.exitDate || (movementType === 'خروج' ? new Date().toISOString().split('T')[0] : undefined),
        destinationCountry: row.destinationCountry || '',
        exitCarrierOrFlight: row.exitCarrierOrFlight || '',
        exitPurpose: row.exitPurpose || 'سفر ومغادرة',

        // Dates & Expiry
        passportIssueDate: row.passportIssueDate || '',
        passportExpiryDate: row.passportExpiryDate || '',
        visaIssueDate: row.visaIssueDate || '',
        visaExpiryDate: row.visaExpiryDate || '',
        residencyIssueDate: row.residencyIssueDate || '',
        residencyExpiryDate: row.residencyExpiryDate || '',

        // Foreigners, Visa & Residency
        sponsorName: row.sponsorName || '',
        sponsorPhone: row.sponsorPhone || '',
        residencyNumber: row.residencyNumber || '',
        profession: row.profession || '',
        employerName: row.employerName || '',
        visaNumber: row.visaNumber || '',
        visaType: row.visaType || '',
        requestedVisaPeriod: row.requestedVisaPeriod || '',

        // Marriage & Citizenship
        spouseFullName: row.spouseFullName || '',
        foreignSpouseName: row.foreignSpouseName || '',
        foreignSpouseNationality: row.foreignSpouseNationality || '',
        citizenshipFileNumber: row.citizenshipFileNumber || '',

        // Vetting & Refugees
        vettingResult: row.vettingResult || 'سليم أمنياً - لا توجد قيود مسجلة',
        travelAllowed: row.travelAllowed || 'نعم',
        unhcrNumber: row.unhcrNumber || '',
        interceptionPoint: row.interceptionPoint || '',

        // Additional / Excess Excel Fields: [اسم العمود / القيمة]
        additionalData: row.additionalData || '',
      });
    });

    const merged = [...newProcessedTravelers, ...travelers];
    saveTravelers(merged);
    setTravelers(merged);

    // Calculate distribution summary
    let foreignersCount = 0;
    let entryCount = 0;
    let exitCount = 0;
    let expiringCount = 0;

    newProcessedTravelers.forEach(t => {
      if (t.isForeigner) foreignersCount++;
      if (t.movementType === 'دخول') entryCount++;
      if (t.movementType === 'خروج') exitCount++;
      if (checkTravelerExpirations(t).hasAlert) expiringCount++;
    });

    toast({
      title: 'اكتمل الاستيراد والتوزيع الذكي بنجاح',
      description: `تم استيراد ${newProcessedTravelers.length} سجلاً وتوزيعها تلقائياً (${foreignersCount} للأجانب، ${entryCount} حركة دخول، ${exitCount} حركة خروج، ${expiringCount} تنبيه وثائق منتهية/قاربت على الانتهاء).`,
    });
  };


  // Link Reports
  const handleSaveLinkedReports = () => {
    if (!selectedTraveler) return;
    const updated = travelers.map(t => {
      if (t.id === selectedTraveler.id) {
        return { ...t, linkedReportIds: selectedReportIds };
      }
      return t;
    });
    saveTravelers(updated);
    setTravelers(updated);
    setIsLinkReportOpen(false);
    toast({ title: 'تم ربط البلاغات', description: 'تم تحديث سجل البلاغات الأمنية للمسافر بنجاح' });
  };

  // Create Quick Report for Traveler
  const handleCreateReport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTraveler || !newReportData.title) return;

    const newReport = {
      id: `rep-${generateId()}`,
      title: newReportData.title,
      description: newReportData.description,
      type: newReportData.type,
      status: 'جديد' as const,
      linkedTravelerIds: [selectedTraveler.id],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const updatedReports = [newReport, ...allReports];
    saveReports(updatedReports);
    setAllReports(updatedReports);

    // Link report to traveler
    const updatedTravelers = travelers.map(t => {
      if (t.id === selectedTraveler.id) {
        const existing = t.linkedReportIds || [];
        return {
          ...t,
          linkedReportIds: [...existing, newReport.id],
          travelAllowed: 'لا' as const,
          vettingResult: `[بلاغ ضبط فوري: ${newReportData.title}] ${t.vettingResult || ''}`
        };
      }
      return t;
    });

    saveTravelers(updatedTravelers);
    setTravelers(updatedTravelers);
    setIsCreateReportOpen(false);
    toast({
      title: 'تم إصدار بلاغ ضبط',
      description: `تم إدراج بلاغ أمني ومنع "${selectedTraveler.fullName}" من السفر آلياً.`,
      variant: 'destructive',
    });
  };

  // Dynamic nationality check in form
  const isFormCountryForeign = isNonYemeni(formData.country);

  // Form expiration warning check
  const passportFormDays = getDaysUntil(formData.passportExpiryDate);
  const visaFormDays = getDaysUntil(formData.visaExpiryDate);
  const residencyFormDays = getDaysUntil(formData.residencyExpiryDate);

  return (
    <div className="space-y-6 print:hidden">
      {/* Printable Component Hook */}
      <PrintableTraveler traveler={printingTraveler} />

      {/* Top Banner Alert for Expiring Documents (Residency, Visa, Passport <= 7 days or expired) */}
      {categoryCounts.expiring > 0 && (
        <div className="bg-gradient-to-r from-red-500 via-rose-500 to-amber-600 rounded-2xl p-4 text-white shadow-lg flex flex-col md:flex-row items-center justify-between gap-4 animate-in fade-in">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-white/20 rounded-xl backdrop-blur-xs">
              <ShieldAlert className="h-7 w-7 text-white animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-bold flex items-center gap-2">
                <span>تنبيهات انتهاء الوثائق العاجلة</span>
                <span className="bg-white text-red-700 text-xs px-2.5 py-0.5 rounded-full font-mono font-black">
                  {categoryCounts.expiring} سجلات
                </span>
              </h2>
              <p className="text-xs text-white/90 mt-0.5">
                يوجد وثائق أو إقامات أو تأشيرات أو جوازات تنتهي خلال أسبوع فقط (أو منتهية الصلاحية) تتطلب التدقيق والإجراء القانوني.
              </p>
            </div>
          </div>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => handleTabChange('expiring')}
            className="bg-white text-red-700 hover:bg-slate-100 font-bold text-xs shadow-md whitespace-nowrap"
          >
            <ShieldAlert className="h-4 w-4 ml-1.5 text-red-600" />
            عرض تنبيهات الانتهاء فوراً ({categoryCounts.expiring})
          </Button>
        </div>
      )}

      {/* Header and Action Buttons */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">
              {CATEGORY_CONFIG[activeTab]?.label || 'شؤون المسافرين والأجانب'}
            </h1>
            <span className="bg-slate-100 text-slate-700 text-xs px-2.5 py-1 rounded-full font-mono font-bold">
              {filteredTravelers.length} سجل
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            القاعدة الأساسية المركزية للمسافرين والأجانب، مع تصنيف وتوجيه ذكي تلقائي لكافة المعاملات وحركات المنافذ.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <Button 
            onClick={handleOpenAddModal} 
            className="bg-primary hover:bg-primary/90 text-white gap-2 shadow-sm font-bold"
          >
            <Plus className="h-4 w-4" />
            إضافة حركة / معاملة جديدة
          </Button>

          {/* OCR scan button */}
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handlePassportScan} 
            accept="image/*" 
            className="hidden" 
          />
          <Button 
            variant="outline" 
            onClick={() => fileInputRef.current?.click()} 
            disabled={isScanning}
            className="gap-2 border-slate-300 hover:bg-slate-50"
          >
            <Scan className={`h-4 w-4 ${isScanning ? 'animate-spin text-primary' : 'text-slate-600'}`} />
            {isScanning ? 'جارِ فحص الجواز...' : 'مسح ذكي للجواز'}
          </Button>

          {/* Hidden inputs for Excel files */}
          <input 
            type="file" 
            ref={excelImportRef} 
            onChange={(e) => handleExcelFileSelected(e, false)} 
            accept=".xlsx, .xls" 
            className="hidden" 
          />
          <input 
            type="file" 
            ref={vettingImportRef} 
            onChange={(e) => handleExcelFileSelected(e, true)} 
            accept=".xlsx, .xls" 
            className="hidden" 
          />

          {/* Import Dropdown with Smart, Vetting, and Excel */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="outline" 
                className="gap-2 border-emerald-300 bg-emerald-50/60 hover:bg-emerald-100/70 text-emerald-800 font-bold"
              >
                <Upload className="h-4 w-4 text-emerald-700" />
                <span>خيارات الاستيراد</span>
                <Sparkles className="h-3.5 w-3.5 text-amber-500 animate-pulse" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64 p-1.5 space-y-1">
              <DropdownMenuItem 
                onClick={() => excelImportRef.current?.click()} 
                className="gap-2.5 p-2.5 cursor-pointer rounded-lg hover:bg-emerald-50 focus:bg-emerald-50"
              >
                <div className="p-1.5 bg-emerald-100 text-emerald-700 rounded-md">
                  <FileSpreadsheet className="h-4 w-4" />
                </div>
                <div>
                  <strong className="block text-xs text-slate-800">استيراد من إكسل (Smart)</strong>
                  <span className="text-[10px] text-slate-500">معالجة وتوزيع آلي للأجانب والدخول والخروج</span>
                </div>
              </DropdownMenuItem>

              <DropdownMenuItem 
                onClick={() => vettingImportRef.current?.click()} 
                className="gap-2.5 p-2.5 cursor-pointer rounded-lg hover:bg-amber-50 focus:bg-amber-50"
              >
                <div className="p-1.5 bg-amber-100 text-amber-700 rounded-md">
                  <ShieldCheck className="h-4 w-4" />
                </div>
                <div>
                  <strong className="block text-xs text-amber-900">استيراد المباينة والقيود الأمنية</strong>
                  <span className="text-[10px] text-slate-500">مطابقة وتحديث نتائج الفحص وقرارات السفر</span>
                </div>
              </DropdownMenuItem>

              <DropdownMenuItem 
                onClick={() => excelImportRef.current?.click()} 
                className="gap-2.5 p-2.5 cursor-pointer rounded-lg hover:bg-purple-50 focus:bg-purple-50"
              >
                <div className="p-1.5 bg-purple-100 text-purple-700 rounded-md">
                  <Sparkles className="h-4 w-4 text-purple-700" />
                </div>
                <div>
                  <strong className="block text-xs text-purple-900">استيراد ذكي (AI Auto-Detect)</strong>
                  <span className="text-[10px] text-slate-500">تحليل ذكي لأسماء الأعمدة المجهولة أو المركبة</span>
                </div>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>


          {/* Export Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2 border-slate-300 hover:bg-slate-50">
                <Download className="h-4 w-4 text-slate-600" />
                تصدير البيانات
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuItem onClick={() => exportToExcel(filteredTravelers, `Travelers_${activeTab}`)} className="gap-2">
                <FileText className="h-4 w-4 text-emerald-600" />
                <span>تصدير Excel (.xlsx)</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportToCSV(filteredTravelers, `Travelers_${activeTab}`)} className="gap-2">
                <FileText className="h-4 w-4 text-blue-600" />
                <span>تصدير CSV (.csv)</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportToJSON(filteredTravelers, `Travelers_${activeTab}`)} className="gap-2">
                <FileJson className="h-4 w-4 text-amber-600" />
                <span>تصدير JSON (.json)</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportToPDF('travelers-table-container', `Travelers_${activeTab}`)} className="gap-2">
                <FileText className="h-4 w-4 text-rose-600" />
                <span>تصدير تقرير PDF</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportToImage('travelers-table-container', `Travelers_${activeTab}`)} className="gap-2">
                <ImageIcon className="h-4 w-4 text-indigo-600" />
                <span>تصدير صورة صورة (.png)</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportToWord(filteredTravelers, `Travelers_${activeTab}`)} className="gap-2">
                <FileText className="h-4 w-4 text-blue-800" />
                <span>تصدير Word (.doc)</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Tabs Navigation Bar */}
      <div className="bg-white p-2.5 rounded-2xl border border-slate-200/80 shadow-xs overflow-x-auto">
        <div className="flex items-center gap-1.5 min-w-max">
          {(Object.keys(CATEGORY_CONFIG) as TabKey[]).map(key => {
            const config = CATEGORY_CONFIG[key];
            const Icon = config.icon;
            const count = categoryCounts[key] || 0;
            const isActive = activeTab === key;
            const isAlertTab = key === 'expiring';

            return (
              <button
                key={key}
                onClick={() => handleTabChange(key)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all duration-150 ${
                  isActive 
                    ? isAlertTab 
                      ? 'bg-red-600 text-white shadow-md font-bold'
                      : 'bg-primary text-white shadow-md font-bold'
                    : isAlertTab && count > 0
                      ? 'bg-red-50 text-red-700 hover:bg-red-100 border border-red-200 font-bold animate-pulse'
                      : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200/60'
                }`}
              >
                <Icon className={`h-4 w-4 ${isActive ? 'text-white' : isAlertTab ? 'text-red-600' : 'text-slate-500'}`} />
                <span>{config.shortLabel}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                  isActive 
                    ? 'bg-white/20 text-white' 
                    : isAlertTab 
                      ? 'bg-red-200 text-red-800' 
                      : 'bg-slate-200/80 text-slate-700'
                }`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute right-3.5 top-2.5 h-4 w-4 text-slate-400" />
          <Input 
            placeholder="بحث بالاسم الكامل، رقم الجواز، الهاتف، الكفيل، الزوجة، أو رقم التأشيرة/الإقامة..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10 bg-slate-50/60 border-slate-200 text-xs"
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="absolute left-3 top-2.5 text-slate-400 hover:text-slate-600"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <Select value={movementFilter} onValueChange={setMovementFilter}>
          <SelectTrigger className="w-[140px] text-xs bg-slate-50/60">
            <SelectValue placeholder="نوع الحركة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كافة الحركات</SelectItem>
            <SelectItem value="دخول">حركة دخول</SelectItem>
            <SelectItem value="خروج">حركة خروج</SelectItem>
            <SelectItem value="عام">معاملة عامة</SelectItem>
          </SelectContent>
        </Select>

        <Select value={governorateFilter} onValueChange={setGovernorateFilter}>
          <SelectTrigger className="w-[140px] text-xs bg-slate-50/60">
            <SelectValue placeholder="المحافظة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كافة المحافظات</SelectItem>
            {YEMEN_GOVERNORATES.map(gov => (
              <SelectItem key={gov} value={gov}>{gov}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={allowedFilter} onValueChange={setAllowedFilter}>
          <SelectTrigger className="w-[140px] text-xs bg-slate-50/60">
            <SelectValue placeholder="حالة المنع/السماح" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كافة الحالات</SelectItem>
            <SelectItem value="نعم">مسموح بالسفر</SelectItem>
            <SelectItem value="لا">ممنوع من السفر</SelectItem>
          </SelectContent>
        </Select>

        {(searchQuery || governorateFilter !== 'all' || allowedFilter !== 'all' || movementFilter !== 'all') && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => {
              setSearchQuery('');
              setGovernorateFilter('all');
              setAllowedFilter('all');
              setMovementFilter('all');
            }}
            className="text-xs text-slate-500 hover:text-slate-800"
          >
            إعادة الضبط
          </Button>
        )}
      </div>

      {/* Main Table Container */}
      <div id="travelers-table-container" className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-slate-50 border-b border-slate-200">
              <TableRow>
                <TableHead className="w-12 text-center text-xs font-bold text-slate-700">#</TableHead>
                <TableHead className="text-right text-xs font-bold text-slate-700">الاسم الكامل</TableHead>
                <TableHead className="text-right text-xs font-bold text-slate-700">الجنسية والهوية</TableHead>
                <TableHead className="text-right text-xs font-bold text-slate-700">رقم ونوع الوثيقة</TableHead>
                <TableHead className="text-right text-xs font-bold text-slate-700">نوع الحركة والتصنيف</TableHead>
                <TableHead className="text-right text-xs font-bold text-slate-700">تنبيهات الصلاحية (أسبوع فأقل)</TableHead>
                <TableHead className="text-right text-xs font-bold text-slate-700">المنفذ والوجهة</TableHead>
                <TableHead className="text-center text-xs font-bold text-slate-700">القرار</TableHead>
                <TableHead className="text-center text-xs font-bold text-slate-700 w-36">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedTravelers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="h-44 text-center">
                    <div className="flex flex-col items-center justify-center text-slate-400 gap-2">
                      <Users className="h-8 w-8 text-slate-300" />
                      <p className="text-sm font-medium">لا توجد سجلات مطابقة للبحث أو التصنيف الحالي</p>
                      <Button variant="outline" size="sm" onClick={handleOpenAddModal} className="text-xs mt-1">
                        إضافة سجل جديد
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                paginatedTravelers.map((traveler, index) => {
                  const itemIndex = (currentPage - 1) * PAGE_SIZE + index + 1;
                  const fullName = formatTravelerFullName(traveler);
                  const isForeign = traveler.isForeigner || isNonYemeni(traveler.country);
                  const expData = checkTravelerExpirations(traveler);

                  return (
                    <TableRow 
                      key={traveler.id} 
                      className={`hover:bg-slate-50/80 transition-colors ${expData.hasAlert ? 'bg-red-50/30' : ''}`}
                    >
                      <TableCell className="text-center font-mono text-xs text-slate-500">
                        {itemIndex}
                      </TableCell>

                      <TableCell className="font-semibold text-slate-900 text-xs">
                        <div className="flex items-center gap-2">
                          <span>{fullName}</span>
                          {traveler.linkedReportIds && traveler.linkedReportIds.length > 0 && (
                            <span 
                              title="مرتبط ببلاغ ضبط أمني"
                              className="bg-red-600 text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full animate-pulse"
                            >
                              مطلوب
                            </span>
                          )}
                        </div>
                        {traveler.phone && (
                          <span className="block text-[11px] font-mono text-slate-400 mt-0.5">
                            {traveler.phone}
                          </span>
                        )}
                        {traveler.additionalData && (
                          <div className="mt-1">
                            <button
                              type="button"
                              onClick={() => handleOpenEditModal(traveler)}
                              title={traveler.additionalData}
                              className="inline-flex items-center gap-1 text-[10px] bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200/90 font-semibold px-1.5 py-0.5 rounded cursor-pointer transition-colors"
                            >
                              <Layers className="h-2.5 w-2.5 text-amber-600" />
                              <span>بيانات إضافية ({traveler.additionalData.split('\n').filter(Boolean).length})</span>
                            </button>
                          </div>
                        )}
                      </TableCell>

                      <TableCell className="text-xs">
                        <div className="flex items-center gap-1.5">
                          <span className="font-medium text-slate-800">{traveler.country}</span>
                          {isForeign ? (
                            <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">
                              أجنبي
                            </span>
                          ) : (
                            <span className="text-[10px] bg-blue-100 text-blue-800 font-bold px-1.5 py-0.2 rounded">
                              مواطن
                            </span>
                          )}
                        </div>
                        {traveler.governorate && (
                          <span className="text-[10px] text-slate-400 block">{traveler.governorate}</span>
                        )}
                      </TableCell>

                      <TableCell className="text-xs">
                        <span className="font-mono font-bold text-slate-800 block">{traveler.idNumber}</span>
                        <span className="text-[10px] text-slate-500">{traveler.idType}</span>
                      </TableCell>

                      <TableCell className="text-xs">
                        <div className="flex flex-wrap items-center gap-1">
                          {traveler.movementType && (
                            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                              traveler.movementType === 'دخول' 
                                ? 'bg-teal-100 text-teal-800' 
                                : traveler.movementType === 'خروج'
                                ? 'bg-indigo-100 text-indigo-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}>
                              {traveler.movementType === 'دخول' ? '↓ دخول' : traveler.movementType === 'خروج' ? '↑ خروج' : traveler.movementType}
                            </span>
                          )}

                          {traveler.category && (
                            <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-medium">
                              {CATEGORY_CONFIG[traveler.category]?.shortLabel || traveler.category}
                            </span>
                          )}
                        </div>
                      </TableCell>

                      {/* Expiration Alerts column */}
                      <TableCell className="text-xs">
                        {expData.hasAlert ? (
                          <div className="space-y-1">
                            {expData.alerts.map((alert, aIdx) => (
                              <span 
                                key={aIdx} 
                                className={`inline-block text-[10px] px-2 py-0.5 rounded font-bold ${alert.badgeClass}`}
                              >
                                {alert.badgeText}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <span className="text-[11px] text-emerald-600 font-medium">
                            ✓ الوثائق سارية
                          </span>
                        )}
                      </TableCell>

                      <TableCell className="text-xs">
                        <span className="text-slate-800 block">
                          {traveler.entryPort || traveler.exitPort || traveler.center || '-'}
                        </span>
                        <span className="text-[10px] text-slate-400 block">
                          {traveler.destination || traveler.originCountry || '-'}
                        </span>
                      </TableCell>

                      <TableCell className="text-center text-xs">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[11px] font-bold ${
                          traveler.travelAllowed === 'نعم'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {traveler.travelAllowed === 'نعم' ? 'مسموح' : 'ممنوع'}
                        </span>
                      </TableCell>

                      <TableCell className="text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="معاينة التفاصيل"
                            onClick={() => {
                              setSelectedTraveler(traveler);
                              setIsViewModalOpen(true);
                            }}
                            className="h-7 w-7 text-slate-600 hover:text-slate-900"
                          >
                            <Eye className="h-3.5 w-3.5" />
                          </Button>

                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="طباعة الاستمارة"
                            onClick={() => handlePrint(traveler)}
                            className="h-7 w-7 text-blue-600 hover:text-blue-900"
                          >
                            <Printer className="h-3.5 w-3.5" />
                          </Button>

                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="تعديل السجل"
                            onClick={() => handleOpenEditModal(traveler)}
                            className="h-7 w-7 text-amber-600 hover:text-amber-900"
                          >
                            <FileText className="h-3.5 w-3.5" />
                          </Button>

                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="حذف"
                            onClick={() => setDeleteId(traveler.id)}
                            className="h-7 w-7 text-rose-600 hover:text-rose-900"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>

        {/* 50 Rows Per Page Pagination Bar */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-600">
            عرض <span className="font-bold text-slate-900">{filteredTravelers.length === 0 ? 0 : (currentPage - 1) * PAGE_SIZE + 1}</span> إلى{' '}
            <span className="font-bold text-slate-900">{Math.min(currentPage * PAGE_SIZE, filteredTravelers.length)}</span> من إجمالي{' '}
            <span className="font-bold text-slate-900">{filteredTravelers.length}</span> سجل ({PAGE_SIZE} سطر لكل صفحة)
          </div>

          <div className="flex items-center gap-1.5">
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage(1)}
              title="الصفحة الأولى"
              className="h-8 w-8 p-0"
            >
              <ChevronsRight className="h-4 w-4" />
            </Button>

            <Button
              variant="outline"
              size="sm"
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              className="h-8 px-2.5 text-xs gap-1"
            >
              <ChevronRight className="h-3.5 w-3.5" />
              <span>السابق</span>
            </Button>

            {/* Numeric Page Buttons */}
            <div className="flex items-center gap-1">
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let pageNum = currentPage;
                if (totalPages <= 5) {
                  pageNum = i + 1;
                } else if (currentPage <= 3) {
                  pageNum = i + 1;
                } else if (currentPage >= totalPages - 2) {
                  pageNum = totalPages - 4 + i;
                } else {
                  pageNum = currentPage - 2 + i;
                }

                return (
                  <Button
                    key={pageNum}
                    variant={currentPage === pageNum ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setCurrentPage(pageNum)}
                    className="h-8 w-8 p-0 text-xs font-mono font-bold"
                  >
                    {pageNum}
                  </Button>
                );
              })}
            </div>

            <Button
              variant="outline"
              size="sm"
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              className="h-8 px-2.5 text-xs gap-1"
            >
              <span>التالي</span>
              <ChevronLeft className="h-3.5 w-3.5" />
            </Button>

            <Button
              variant="outline"
              size="sm"
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage(totalPages)}
              title="الصفحة الأخيرة"
              className="h-8 w-8 p-0"
            >
              <ChevronsLeft className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* =========================================================================
          Add / Edit Traveler & Cross-Tab Transaction Modal (Scrollable Up & Down)
         ========================================================================= */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="max-w-4xl max-h-[88vh] overflow-y-auto p-6" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-lg font-bold text-slate-900 flex items-center justify-between">
              <span>{selectedTraveler ? 'تعديل بيانات المعاملة / المسافر' : 'إضافة حركة أو معاملة جديدة'}</span>
              <span className="text-xs bg-slate-100 text-slate-700 px-2.5 py-1 rounded-full font-normal">
                {CATEGORY_CONFIG[formData.category || 'traveler']?.label}
              </span>
            </DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              يمكن إدخال البيانات في أي تبويب؛ عند تحديد جنسية غير يمنية أو نوع معاملة مخصص يتم تصنيف وحفظ السجل آلياً في كافة التبويبات المعنية.
            </DialogDescription>
          </DialogHeader>

          {/* Smart Automatic Cross-Routing Notice */}
          {isFormCountryForeign && (
            <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-3 text-xs text-emerald-900 flex items-start gap-2.5">
              <Globe className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <strong>توجيه ذكي للأجانب:</strong> نظراً لأن الجنسية المحددة هي (<strong>{formData.country}</strong>)، سيقوم النظام تلقائياً بعد الحفظ بإدراج هذا السجل في قاعدة بيانات <strong>«الأجانب»</strong>، بالإضافة لتبويب <strong>«المسافرين»</strong> وتبويب المعاملة المحددة.
              </div>
            </div>
          )}

          <form onSubmit={handleSaveTraveler} className="space-y-6 mt-2">
            {/* 1. Transaction Type & Category Selection */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-4">
              <h3 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                <FileCheck className="h-4 w-4 text-primary" />
                <span>نوع الحركة والمعاملة الرئيسية</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">نوع الحركة</label>
                  <Select 
                    value={formData.movementType || 'عام'} 
                    onValueChange={(val: MovementType) => setFormData(p => ({ ...p, movementType: val }))}
                  >
                    <SelectTrigger className="text-xs bg-white">
                      <SelectValue placeholder="اختر نوع الحركة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="دخول">حركة دخول (قادمون عبر المنفذ)</SelectItem>
                      <SelectItem value="خروج">حركة خروج (مغادرون عبر المنفذ)</SelectItem>
                      <SelectItem value="عام">معاملة عامة / إجراء إداري</SelectItem>
                      <SelectItem value="ترانزيت">عبور (ترانزيت)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="md:col-span-2">
                  <label className="text-xs font-semibold text-slate-700 block mb-1">تصنيف المعاملة والقسم الموجه إليه</label>
                  <Select 
                    value={formData.category || 'traveler'} 
                    onValueChange={(val: TravelerCategory) => setFormData(p => ({ ...p, category: val }))}
                  >
                    <SelectTrigger className="text-xs bg-white">
                      <SelectValue placeholder="اختر التصنيف" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="traveler">مسافر عادي (مواطنون / عام)</SelectItem>
                      <SelectItem value="foreigner">شؤون الأجانب والوافدين</SelectItem>
                      <SelectItem value="entry">حركة دخول منافذ</SelectItem>
                      <SelectItem value="exit">حركة خروج منافذ</SelectItem>
                      <SelectItem value="visa_renewal">طلب وإصدار وتجديد تأشيرات</SelectItem>
                      <SelectItem value="residency_renewal">طلب وإصدار وتجديد إقامات</SelectItem>
                      <SelectItem value="marriage_yemeni_woman">طلب تصريح زواج بيمنية</SelectItem>
                      <SelectItem value="marriage_foreigner">طلب تصريح زواج بأجنبي</SelectItem>
                      <SelectItem value="citizenship_application">طالب اكتساب الجنسية اليمنية</SelectItem>
                      <SelectItem value="refugee">شؤون اللاجئين (UNHCR)</SelectItem>
                      <SelectItem value="illegal_immigrant">ضبط هجرة غير شرعية</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* 2. Unified Full Name and Personal Identity */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                <User className="h-4 w-4 text-primary" />
                <span>الاسم الكامل والبيانات الشخصية</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="md:col-span-2">
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    الاسم الكامل (الأول، الثاني، الثالث، الرابع، واللقب في حقل واحد) *
                  </label>
                  <Input
                    required
                    placeholder="مثال: محمد عبدالله سالم أحمد باوزير"
                    value={formData.fullName || ''}
                    onChange={(e) => setFormData(p => ({ ...p, fullName: e.target.value }))}
                    className="text-xs"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">الجنسية / الدولة *</label>
                  <Select 
                    value={formData.country || 'اليمن'} 
                    onValueChange={(val) => setFormData(p => ({ ...p, country: val }))}
                  >
                    <SelectTrigger className="text-xs bg-white">
                      <SelectValue placeholder="اختر الجنسية" />
                    </SelectTrigger>
                    <SelectContent className="max-h-56">
                      {COUNTRIES.map(c => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">نوع الوثيقة</label>
                  <Select 
                    value={formData.idType || 'جواز سفر'} 
                    onValueChange={(val) => setFormData(p => ({ ...p, idType: val }))}
                  >
                    <SelectTrigger className="text-xs bg-white">
                      <SelectValue placeholder="نوع الوثيقة" />
                    </SelectTrigger>
                    <SelectContent>
                      {ID_TYPES.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                      <SelectItem value="بدون وثائق رسمية">بدون وثائق رسمية</SelectItem>
                      <SelectItem value="كرت لجوء أممي">كرت لجوء أممي</SelectItem>
                      <SelectItem value="جواز أجنبي">جواز أجنبي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">رقم الوثيقة / الجواز *</label>
                  <Input
                    required
                    placeholder="مثال: 08349201"
                    value={formData.idNumber || ''}
                    onChange={(e) => setFormData(p => ({ ...p, idNumber: e.target.value }))}
                    className="text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">العمر</label>
                  <Input
                    type="number"
                    placeholder="العمر بالسنوات"
                    value={formData.age || ''}
                    onChange={(e) => setFormData(p => ({ ...p, age: Number(e.target.value) }))}
                    className="text-xs"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">المحافظة / المدينة</label>
                  <Input
                    placeholder="مثال: حضرموت / المكلا"
                    value={formData.governorate || ''}
                    onChange={(e) => setFormData(p => ({ ...p, governorate: e.target.value }))}
                    className="text-xs"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">رقم الهاتف</label>
                  <Input
                    placeholder="مثال: 771234567"
                    value={formData.phone || ''}
                    onChange={(e) => setFormData(p => ({ ...p, phone: e.target.value }))}
                    className="text-xs font-mono"
                  />
                </div>
              </div>
            </div>

            {/* 3. Document Issue and Expiry Dates (With Live Alerts) */}
            <div className="bg-amber-50/60 p-4 rounded-xl border border-amber-200/80 space-y-3">
              <h3 className="text-xs font-bold text-amber-900 flex items-center gap-2">
                <Calendar className="h-4 w-4 text-amber-700" />
                <span>تواريخ إصدار وانتهاء الوثائق والتأشيرات والإقامات (فحص تلقائي للمتبقي أسبوع)</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* Passport Dates */}
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">تاريخ إصدار الجواز</label>
                  <Input
                    type="date"
                    value={formData.passportIssueDate || ''}
                    onChange={(e) => setFormData(p => ({ ...p, passportIssueDate: e.target.value }))}
                    className="text-xs bg-white"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-700">تاريخ انتهاء الجواز</label>
                    {passportFormDays !== null && (
                      <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                        passportFormDays < 0 ? 'bg-red-600 text-white' : passportFormDays <= 7 ? 'bg-amber-500 text-white' : 'text-emerald-700'
                      }`}>
                        {passportFormDays < 0 ? 'منتهي' : passportFormDays <= 7 ? `ينتهي خلال ${passportFormDays} أيام!` : 'ساري'}
                      </span>
                    )}
                  </div>
                  <Input
                    type="date"
                    value={formData.passportExpiryDate || ''}
                    onChange={(e) => setFormData(p => ({ ...p, passportExpiryDate: e.target.value }))}
                    className="text-xs bg-white"
                  />
                </div>

                {/* Visa Dates */}
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">تاريخ إصدار التأشيرة</label>
                  <Input
                    type="date"
                    value={formData.visaIssueDate || ''}
                    onChange={(e) => setFormData(p => ({ ...p, visaIssueDate: e.target.value }))}
                    className="text-xs bg-white"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-700">تاريخ انتهاء التأشيرة</label>
                    {visaFormDays !== null && (
                      <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                        visaFormDays < 0 ? 'bg-red-600 text-white' : visaFormDays <= 7 ? `bg-amber-500 text-white` : 'text-emerald-700'
                      }`}>
                        {visaFormDays < 0 ? 'منتهية' : visaFormDays <= 7 ? `تنتهي خلال ${visaFormDays} أيام!` : 'سارية'}
                      </span>
                    )}
                  </div>
                  <Input
                    type="date"
                    value={formData.visaExpiryDate || ''}
                    onChange={(e) => setFormData(p => ({ ...p, visaExpiryDate: e.target.value }))}
                    className="text-xs bg-white"
                  />
                </div>

                {/* Residency Dates */}
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">تاريخ إصدار الإقامة</label>
                  <Input
                    type="date"
                    value={formData.residencyIssueDate || ''}
                    onChange={(e) => setFormData(p => ({ ...p, residencyIssueDate: e.target.value }))}
                    className="text-xs bg-white"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-700">تاريخ انتهاء الإقامة</label>
                    {residencyFormDays !== null && (
                      <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                        residencyFormDays < 0 ? 'bg-red-600 text-white' : residencyFormDays <= 7 ? `bg-red-500 text-white` : 'text-emerald-700'
                      }`}>
                        {residencyFormDays < 0 ? 'منتهية' : residencyFormDays <= 7 ? `تنتهي خلال ${residencyFormDays} أيام!` : 'سارية'}
                      </span>
                    )}
                  </div>
                  <Input
                    type="date"
                    value={formData.residencyExpiryDate || ''}
                    onChange={(e) => setFormData(p => ({ ...p, residencyExpiryDate: e.target.value }))}
                    className="text-xs bg-white"
                  />
                </div>
              </div>
            </div>

            {/* 4. Dynamic Fields Based on Category / Movement */}
            {/* A. Entry Fields */}
            {(formData.movementType === 'دخول' || formData.category === 'entry') && (
              <div className="bg-teal-50/60 p-4 rounded-xl border border-teal-200/80 space-y-3">
                <h3 className="text-xs font-bold text-teal-900 flex items-center gap-2">
                  <LogIn className="h-4 w-4 text-teal-700" />
                  <span>بيانات حركة الدخول والمنافذ</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">منفذ الدخول</label>
                    <Input
                      placeholder="مثال: منفذ الوديعة البري"
                      value={formData.entryPort || ''}
                      onChange={(e) => setFormData(p => ({ ...p, entryPort: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">تاريخ الدخول</label>
                    <Input
                      type="date"
                      value={formData.entryDate || ''}
                      onChange={(e) => setFormData(p => ({ ...p, entryDate: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">جهة القدوم (الدولة القادم منها)</label>
                    <Input
                      placeholder="مثال: المملكة العربية السعودية"
                      value={formData.originCountry || ''}
                      onChange={(e) => setFormData(p => ({ ...p, originCountry: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">وسيلة النقل / رقم الرحلة / المركبة</label>
                    <Input
                      placeholder="مثال: رحلة IY601 / باص البركة 481"
                      value={formData.entryCarrierOrFlight || ''}
                      onChange={(e) => setFormData(p => ({ ...p, entryCarrierOrFlight: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">الغرض من الدخول</label>
                    <Input
                      placeholder="زيارة، عمل، علاج، إقامة..."
                      value={formData.entryPurpose || ''}
                      onChange={(e) => setFormData(p => ({ ...p, entryPurpose: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">الإقامة المصرح بها (أيام)</label>
                    <Input
                      type="number"
                      placeholder="90"
                      value={formData.allowedStayDays || ''}
                      onChange={(e) => setFormData(p => ({ ...p, allowedStayDays: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* B. Exit Fields */}
            {(formData.movementType === 'خروج' || formData.category === 'exit') && (
              <div className="bg-indigo-50/60 p-4 rounded-xl border border-indigo-200/80 space-y-3">
                <h3 className="text-xs font-bold text-indigo-900 flex items-center gap-2">
                  <LogOut className="h-4 w-4 text-indigo-700" />
                  <span>بيانات حركة الخروج والمغادرة</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">منفذ الخروج</label>
                    <Input
                      placeholder="مثال: مطار عدن الدولي"
                      value={formData.exitPort || ''}
                      onChange={(e) => setFormData(p => ({ ...p, exitPort: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">تاريخ الخروج</label>
                    <Input
                      type="date"
                      value={formData.exitDate || ''}
                      onChange={(e) => setFormData(p => ({ ...p, exitDate: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">جهة المغادرة (بلد المقصد)</label>
                    <Input
                      placeholder="مثال: مصر / الأردن / عمان"
                      value={formData.destinationCountry || ''}
                      onChange={(e) => setFormData(p => ({ ...p, destinationCountry: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">وسيلة النقل / رقم الرحلة</label>
                    <Input
                      placeholder="مثال: طيران اليمنية رحلة 601"
                      value={formData.exitCarrierOrFlight || ''}
                      onChange={(e) => setFormData(p => ({ ...p, exitCarrierOrFlight: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">سبب المغادرة</label>
                    <Input
                      placeholder="علاج، سياحة، خروج نهائي..."
                      value={formData.exitPurpose || ''}
                      onChange={(e) => setFormData(p => ({ ...p, exitPurpose: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">رقم تصريح / تأشيرة الخروج</label>
                    <Input
                      placeholder="EX-2026-99"
                      value={formData.exitPermitNumber || ''}
                      onChange={(e) => setFormData(p => ({ ...p, exitPermitNumber: e.target.value }))}
                      className="text-xs bg-white font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* C. Foreigner Fields */}
            {(formData.category === 'foreigner' || isFormCountryForeign) && (
              <div className="bg-emerald-50/60 p-4 rounded-xl border border-emerald-200/80 space-y-3">
                <h3 className="text-xs font-bold text-emerald-900 flex items-center gap-2">
                  <Globe className="h-4 w-4 text-emerald-700" />
                  <span>بيانات الكفيل وشؤون الإقامة في الجمهورية</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">اسم الكفيل / المنشأة</label>
                    <Input
                      placeholder="شركة / مؤسسة / شخص"
                      value={formData.sponsorName || ''}
                      onChange={(e) => setFormData(p => ({ ...p, sponsorName: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">هاتف الكفيل</label>
                    <Input
                      placeholder="777000000"
                      value={formData.sponsorPhone || ''}
                      onChange={(e) => setFormData(p => ({ ...p, sponsorPhone: e.target.value }))}
                      className="text-xs bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">عنوان الكفيل / مقر العمل</label>
                    <Input
                      placeholder="صنعاء / عدن / حضرموت..."
                      value={formData.sponsorAddress || ''}
                      onChange={(e) => setFormData(p => ({ ...p, sponsorAddress: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* D. Visa Renewal Fields */}
            {formData.category === 'visa_renewal' && (
              <div className="bg-purple-50/60 p-4 rounded-xl border border-purple-200/80 space-y-3">
                <h3 className="text-xs font-bold text-purple-900 flex items-center gap-2">
                  <FileCheck className="h-4 w-4 text-purple-700" />
                  <span>بيانات طلب ومعاملة التأشيرة</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">رقم التأشيرة</label>
                    <Input
                      placeholder="V-2026-99"
                      value={formData.visaNumber || ''}
                      onChange={(e) => setFormData(p => ({ ...p, visaNumber: e.target.value }))}
                      className="text-xs bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">المدة المطلوبة للتمديد</label>
                    <Input
                      placeholder="3 أشهر / 6 أشهر"
                      value={formData.requestedVisaPeriod || ''}
                      onChange={(e) => setFormData(p => ({ ...p, requestedVisaPeriod: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">سبب طلب التمديد</label>
                    <Input
                      placeholder="استكمال عمل / علاج / سياحة"
                      value={formData.visaExtensionReason || ''}
                      onChange={(e) => setFormData(p => ({ ...p, visaExtensionReason: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">حالة سداد الرسوم</label>
                    <Select 
                      value={formData.visaFeeStatus || 'مسدد'} 
                      onValueChange={(val: any) => setFormData(p => ({ ...p, visaFeeStatus: val }))}
                    >
                      <SelectTrigger className="text-xs bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="مسدد">مسدد</SelectItem>
                        <SelectItem value="غير مسدد">غير مسدد</SelectItem>
                        <SelectItem value="معفى">معفى قانوناً</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">رقم إيصال السداد</label>
                    <Input
                      placeholder="RC-99812"
                      value={formData.visaReceiptNumber || ''}
                      onChange={(e) => setFormData(p => ({ ...p, visaReceiptNumber: e.target.value }))}
                      className="text-xs bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">حالة الطلب</label>
                    <Select 
                      value={formData.visaRequestStatus || 'قيد المراجعة'} 
                      onValueChange={(val: any) => setFormData(p => ({ ...p, visaRequestStatus: val }))}
                    >
                      <SelectTrigger className="text-xs bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="قيد المراجعة">قيد المراجعة والتدقيق</SelectItem>
                        <SelectItem value="معتمد">معتمد وصادر</SelectItem>
                        <SelectItem value="مرفوض">مرفوض أمنياً</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {/* E. Residency Renewal Fields */}
            {formData.category === 'residency_renewal' && (
              <div className="bg-cyan-50/60 p-4 rounded-xl border border-cyan-200/80 space-y-3">
                <h3 className="text-xs font-bold text-cyan-900 flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-cyan-700" />
                  <span>بيانات طلب ومعاملة تجديد الإقامة</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">رقم الإقامة الحالي</label>
                    <Input
                      placeholder="IQ-2025-449"
                      value={formData.residencyNumber || ''}
                      onChange={(e) => setFormData(p => ({ ...p, residencyNumber: e.target.value }))}
                      className="text-xs bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">المهنة المدونة</label>
                    <Input
                      placeholder="طبيب / مهندس / محاسب / فني"
                      value={formData.profession || ''}
                      onChange={(e) => setFormData(p => ({ ...p, profession: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">صاحب العمل / الكفيل</label>
                    <Input
                      placeholder="اسم الجهة أو الكفيل"
                      value={formData.employerName || ''}
                      onChange={(e) => setFormData(p => ({ ...p, employerName: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">مدة الإقامة المطلوبة</label>
                    <Input
                      placeholder="سنة واحدة / سنتان"
                      value={formData.requestedResidencyPeriod || ''}
                      onChange={(e) => setFormData(p => ({ ...p, requestedResidencyPeriod: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">الفحص الطبي</label>
                    <Select 
                      value={formData.medicalTestStatus || 'لائق'} 
                      onValueChange={(val: any) => setFormData(p => ({ ...p, medicalTestStatus: val }))}
                    >
                      <SelectTrigger className="text-xs bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="لائق">لائق طبياً</SelectItem>
                        <SelectItem value="غير لائق">غير لائق طبياً</SelectItem>
                        <SelectItem value="قيد الفحص">قيد الفحص والتحليل</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">حالة معاملة الإقامة</label>
                    <Select 
                      value={formData.residencyRequestStatus || 'قيد الإجراء'} 
                      onValueChange={(val: any) => setFormData(p => ({ ...p, residencyRequestStatus: val }))}
                    >
                      <SelectTrigger className="text-xs bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="قيد الإجراء">قيد الإجراء والمراجعة</SelectItem>
                        <SelectItem value="معتمد ومجدد">معتمد ومجدد رسمي</SelectItem>
                        <SelectItem value="مرفوض">مرفوض</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {/* F. Marriage to Yemeni Woman Fields */}
            {formData.category === 'marriage_yemeni_woman' && (
              <div className="bg-rose-50/60 p-4 rounded-xl border border-rose-200/80 space-y-3">
                <h3 className="text-xs font-bold text-rose-900 flex items-center gap-2">
                  <Heart className="h-4 w-4 text-rose-700" />
                  <span>بيانات طلب تصريح زواج أجنبي من مواطنة يمنية</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">الاسم الكامل للزوجة اليمنية *</label>
                    <Input
                      placeholder="فاطمة محمد ناصر المنصوري"
                      value={formData.spouseFullName || ''}
                      onChange={(e) => setFormData(p => ({ ...p, spouseFullName: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">الرقم الوطني / بطاقة الزوجة</label>
                    <Input
                      placeholder="0201994821"
                      value={formData.spouseIdNumber || ''}
                      onChange={(e) => setFormData(p => ({ ...p, spouseIdNumber: e.target.value }))}
                      className="text-xs bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">رقم عقد الزواج / الطلب</label>
                    <Input
                      placeholder="CR-MAR-8821"
                      value={formData.marriageContractNumber || ''}
                      onChange={(e) => setFormData(p => ({ ...p, marriageContractNumber: e.target.value }))}
                      className="text-xs bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">المحكمة الشرعية / الجهة المصادقة</label>
                    <Input
                      placeholder="محكمة صيرة الابتدائية الشرعية"
                      value={formData.courtOrAuthority || ''}
                      onChange={(e) => setFormData(p => ({ ...p, courtOrAuthority: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">اسم ولي الأمر / الضامن</label>
                    <Input
                      placeholder="محمد ناصر المنصوري"
                      value={formData.marriageGuardianName || ''}
                      onChange={(e) => setFormData(p => ({ ...p, marriageGuardianName: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">حالة الموافقة الأمنية</label>
                    <Select 
                      value={formData.marriageApprovalStatus || 'قيد الدراسة والتحري'} 
                      onValueChange={(val: any) => setFormData(p => ({ ...p, marriageApprovalStatus: val }))}
                    >
                      <SelectTrigger className="text-xs bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="قيد الدراسة والتحري">قيد الدراسة والتحري الأمني</SelectItem>
                        <SelectItem value="موافقة أمنية معتمدة">موافقة أمنية معتمدة ✓</SelectItem>
                        <SelectItem value="مرفوض">طلب مرفوض ✗</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {/* G. Marriage to Foreigner Fields */}
            {formData.category === 'marriage_foreigner' && (
              <div className="bg-pink-50/60 p-4 rounded-xl border border-pink-200/80 space-y-3">
                <h3 className="text-xs font-bold text-pink-900 flex items-center gap-2">
                  <HeartHandshake className="h-4 w-4 text-pink-700" />
                  <span>بيانات طلب تصريح زواج مواطن يمني من أجنبية</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">اسم الطرف الأجنبي *</label>
                    <Input
                      placeholder="سارة إليزابيث جونسون"
                      value={formData.foreignSpouseName || ''}
                      onChange={(e) => setFormData(p => ({ ...p, foreignSpouseName: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">جنسية الطرف الأجنبي</label>
                    <Input
                      placeholder="بريطانية / مصرية..."
                      value={formData.foreignSpouseNationality || ''}
                      onChange={(e) => setFormData(p => ({ ...p, foreignSpouseNationality: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">رقم جواز الطرف الأجنبي</label>
                    <Input
                      placeholder="GB-9921470"
                      value={formData.foreignSpousePassport || ''}
                      onChange={(e) => setFormData(p => ({ ...p, foreignSpousePassport: e.target.value }))}
                      className="text-xs bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">رقم موافقة وزارة الداخلية</label>
                    <Input
                      placeholder="MOI-FRG-2026-302"
                      value={formData.foreignMarriageApprovalNumber || ''}
                      onChange={(e) => setFormData(p => ({ ...p, foreignMarriageApprovalNumber: e.target.value }))}
                      className="text-xs bg-white font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* H. Yemeni Citizenship Application Fields */}
            {formData.category === 'citizenship_application' && (
              <div className="bg-amber-50/60 p-4 rounded-xl border border-amber-200/80 space-y-3">
                <h3 className="text-xs font-bold text-amber-900 flex items-center gap-2">
                  <Award className="h-4 w-4 text-amber-700" />
                  <span>بيانات طلب اكتساب وتجنس الجنسية اليمنية</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">رقم ملف الجنسية</label>
                    <Input
                      placeholder="CIT-NAT-2026-118"
                      value={formData.citizenshipFileNumber || ''}
                      onChange={(e) => setFormData(p => ({ ...p, citizenshipFileNumber: e.target.value }))}
                      className="text-xs bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">سنوات الإقامة في اليمن</label>
                    <Input
                      type="number"
                      placeholder="15"
                      value={formData.residenceYearsInYemen || ''}
                      onChange={(e) => setFormData(p => ({ ...p, residenceYearsInYemen: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">سبب ومستند طلب الجنسية</label>
                    <Select 
                      value={formData.citizenshipReason || 'إقامة طويلة مستمرة'} 
                      onValueChange={(val: any) => setFormData(p => ({ ...p, citizenshipReason: val }))}
                    >
                      <SelectTrigger className="text-xs bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="إقامة طويلة مستمرة">إقامة طويلة متصلة (أكثر من 10 سنوات)</SelectItem>
                        <SelectItem value="ابن مواطنة يمنية">ابن أم يمنية</SelectItem>
                        <SelectItem value="زواج من مواطن يمني">زوجة مواطن يمني</SelectItem>
                        <SelectItem value="كفاءات وخدمات جليلة">كفاءات علمية وخدمات جليلة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">حالة المعاملة في اللجنة العليا</label>
                    <Select 
                      value={formData.citizenshipStatus || 'قيد البحث والتحري'} 
                      onValueChange={(val: any) => setFormData(p => ({ ...p, citizenshipStatus: val }))}
                    >
                      <SelectTrigger className="text-xs bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="قيد البحث والتحري">قيد البحث والتحري الأمني</SelectItem>
                        <SelectItem value="استيفاء الشروط القانونية">استيفاء الشروط القانونية</SelectItem>
                        <SelectItem value="مرفوع للجنة العليا">مرفوع للجنة التجنس العليا</SelectItem>
                        <SelectItem value="ممنوح بقرار جمهوري">ممنوح بقرار رسمي ✓</SelectItem>
                        <SelectItem value="مرفوض">مرفوض</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {/* I. Undocumented Migrant Fields */}
            {formData.category === 'illegal_immigrant' && (
              <div className="bg-rose-50/60 p-4 rounded-xl border border-rose-200/80 space-y-3">
                <h3 className="text-xs font-bold text-rose-900 flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-rose-700" />
                  <span>بيانات الضبط والإبعاد للهجرة غير الشرعية</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">نقطة الضبط الحدودية</label>
                    <Input
                      placeholder="صحراء العبر / رأس العارة..."
                      value={formData.interceptionPoint || ''}
                      onChange={(e) => setFormData(p => ({ ...p, interceptionPoint: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">خط التسلل والتهريب</label>
                    <Input
                      placeholder="تسلل بري / زورق بحري..."
                      value={formData.smugglingRoute || ''}
                      onChange={(e) => setFormData(p => ({ ...p, smugglingRoute: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">حالة التبصيم العشري</label>
                    <Select 
                      value={formData.biometricsTaken || 'نعم'} 
                      onValueChange={(val: any) => setFormData(p => ({ ...p, biometricsTaken: val }))}
                    >
                      <SelectTrigger className="text-xs bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="نعم">تم التبصيم محلياً</SelectItem>
                        <SelectItem value="لا">لم يتم بعد</SelectItem>
                        <SelectItem value="قيد الإجراء">قيد الإجراء</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">حالة الترحيل والإبعاد</label>
                    <Select 
                      value={formData.deportationStatus || 'قيد التحقيق'} 
                      onValueChange={(val: any) => setFormData(p => ({ ...p, deportationStatus: val }))}
                    >
                      <SelectTrigger className="text-xs bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="قيد التحقيق">قيد التحقيق</SelectItem>
                        <SelectItem value="محتجز">محتجز بمركز الإيواء</SelectItem>
                        <SelectItem value="قرار ترحيل">صدر قرار إبعاد</SelectItem>
                        <SelectItem value="تم الترحيل">تم الترحيل رسمياً</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {/* J. Refugee Fields */}
            {formData.category === 'refugee' && (
              <div className="bg-orange-50/60 p-4 rounded-xl border border-orange-200/80 space-y-3">
                <h3 className="text-xs font-bold text-orange-900 flex items-center gap-2">
                  <UserPlus className="h-4 w-4 text-orange-700" />
                  <span>بيانات ملف اللجوء والمفوضية السامية</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">رقم ملف المفوضية (UNHCR)</label>
                    <Input
                      placeholder="UNHCR-YEM-2024-99"
                      value={formData.unhcrNumber || ''}
                      onChange={(e) => setFormData(p => ({ ...p, unhcrNumber: e.target.value }))}
                      className="text-xs bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">صفة اللجوء</label>
                    <Select 
                      value={formData.refugeeStatus || 'طالب لجوء'} 
                      onValueChange={(val: any) => setFormData(p => ({ ...p, refugeeStatus: val }))}
                    >
                      <SelectTrigger className="text-xs bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="طالب لجوء">طالب لجوء</SelectItem>
                        <SelectItem value="لاجئ معترف به">لاجئ معترف به رسمياً</SelectItem>
                        <SelectItem value="حماية مؤقتة">حماية مؤقتة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">موقع المخيم أو الإقامة</label>
                    <Input
                      placeholder="مخيم خرز / عدن..."
                      value={formData.campLocation || ''}
                      onChange={(e) => setFormData(p => ({ ...p, campLocation: e.target.value }))}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">عدد المرافقين</label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={formData.dependentsCount || 0}
                      onChange={(e) => setFormData(p => ({ ...p, dependentsCount: Number(e.target.value) }))}
                      className="text-xs bg-white"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 5. Security Vetting and Investigating Officer */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-3">
              <h3 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                <span>نتائج المباينة الأمنية وضابط التحقيق</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="md:col-span-2">
                  <label className="text-xs font-semibold text-slate-700 block mb-1">نتيجة الفحص والمباينة الأمنية</label>
                  <Input
                    placeholder="سليم أمنياً - لا توجد قيود مسجلة"
                    value={formData.vettingResult || ''}
                    onChange={(e) => setFormData(p => ({ ...p, vettingResult: e.target.value }))}
                    className="text-xs bg-white font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">قرار السماح بالسفر / المعاملة</label>
                  <Select 
                    value={formData.travelAllowed || 'نعم'} 
                    onValueChange={(val: any) => setFormData(p => ({ ...p, travelAllowed: val }))}
                  >
                    <SelectTrigger className="text-xs bg-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="نعم">مسموح بالسفر / الإجراء ✓</SelectItem>
                      <SelectItem value="لا">ممنوع من السفر / موقوف ✗</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">ضابط المعاينة / التحقيق</label>
                  <Input
                    placeholder="ملازم/ أحمد الكندي"
                    value={formData.investigatingOfficer || ''}
                    onChange={(e) => setFormData(p => ({ ...p, investigatingOfficer: e.target.value }))}
                    className="text-xs bg-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">المنفذ / المركز</label>
                  <Input
                    placeholder="منفذ الوديعة البري"
                    value={formData.center || ''}
                    onChange={(e) => setFormData(p => ({ ...p, center: e.target.value }))}
                    className="text-xs bg-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">الوجهة أو الغرض العام</label>
                  <Input
                    placeholder="الوجهة المقصودة"
                    value={formData.destination || ''}
                    onChange={(e) => setFormData(p => ({ ...p, destination: e.target.value }))}
                    className="text-xs bg-white"
                  />
                </div>
              </div>
            </div>

            {/* 6. Additional Data / Excess Fields from Excel */}
            <div className="bg-amber-50/70 p-4 rounded-xl border border-amber-200/90 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-amber-950 flex items-center gap-2">
                  <Layers className="h-4 w-4 text-amber-700" />
                  <span>بيانات إضافية وحقول زائدة من ملفات الإكسل</span>
                </h3>
                <span className="text-[11px] font-mono text-amber-800 bg-amber-100/70 px-2 py-0.5 rounded">
                  اسم العمود / القيمة
                </span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                يتم هنا جمع كافة الأعمدة الزائدة المستوردة من الإكسل التي ليس لها حقول مطابقة في النظام (مثل رقم محضر الضبط، أرقام البلاغات، ملاحظات إضافية). يمكنك مراجعتها، تعديلها، أو إضافة حقول جديدة بنفس التنسيق.
              </p>
              <textarea
                rows={4}
                placeholder={"رقم محضر الضبط / 123\nملاحظات الدورية / تم الفحص\nرقم البلاغ السابق / 991"}
                value={formData.additionalData || ''}
                onChange={(e) => setFormData(p => ({ ...p, additionalData: e.target.value }))}
                className="w-full text-xs p-3 rounded-lg border border-amber-300 bg-white font-mono leading-relaxed focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-2xs"
                dir="rtl"
              />
            </div>

            {/* Action Buttons sticky footer */}
            <div className="sticky bottom-0 bg-white/95 backdrop-blur-xs py-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsAddModalOpen(false)}
                className="text-xs"
              >
                إلغاء
              </Button>
              <Button 
                type="submit" 
                className="bg-primary hover:bg-primary/90 text-white text-xs font-bold gap-1.5 shadow-sm"
              >
                <Save className="h-4 w-4" />
                <span>حفظ المعاملة وتوجيهها آلياً</span>
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* =========================================================================
          View Traveler Modal (Scrollable Up & Down)
         ========================================================================= */}
      <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
        <DialogContent className="max-w-3xl max-h-[88vh] overflow-y-auto p-6" dir="rtl">
          {selectedTraveler && (
            <div className="space-y-6">
              <DialogHeader>
                <DialogTitle className="text-lg font-bold text-slate-900 flex items-center justify-between">
                  <span>تفاصيل المعاملة الرسمية</span>
                  <span className="text-xs bg-slate-100 text-slate-700 px-2.5 py-1 rounded-full font-normal">
                    {CATEGORY_CONFIG[selectedTraveler.category || 'traveler']?.label}
                  </span>
                </DialogTitle>
                <DialogDescription className="text-xs text-slate-500">
                  السجل المحلي المعتمد في نظام المنافذ والجوازات.
                </DialogDescription>
              </DialogHeader>

              {/* Expiration alert in View Dialog */}
              {(() => {
                const viewExp = checkTravelerExpirations(selectedTraveler);
                if (viewExp.hasAlert) {
                  return (
                    <div className="p-3 bg-red-50 border border-red-300 rounded-xl text-xs space-y-1">
                      <p className="font-bold text-red-900 flex items-center gap-1.5">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                        <span>تنبيه وثيقة منتهية أو متبقي أسبوع فقط:</span>
                      </p>
                      <div className="flex flex-wrap gap-2 pt-1">
                        {viewExp.alerts.map((al, idx) => (
                          <span key={idx} className={`px-2 py-0.5 rounded text-[11px] font-bold ${al.badgeClass}`}>
                            {al.label}: {al.badgeText} ({al.date})
                          </span>
                        ))}
                      </div>
                    </div>
                  );
                }
                return null;
              })()}

              {/* Main Info Card */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="text-base font-bold text-slate-900">
                      {formatTravelerFullName(selectedTraveler)}
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {selectedTraveler.country} {selectedTraveler.isForeigner ? '(أجنبي / وافد)' : '(مواطن)'} · {selectedTraveler.governorate || '-'}
                    </p>
                  </div>
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                    selectedTraveler.travelAllowed === 'نعم' 
                      ? 'bg-emerald-100 text-emerald-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {selectedTraveler.travelAllowed === 'نعم' ? 'مسموح بالسفر ✓' : 'ممنوع من السفر ✗'}
                  </span>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs pt-2 border-t border-slate-200">
                  <div>
                    <span className="text-slate-400 block">رقم الوثيقة:</span>
                    <span className="font-mono font-bold text-slate-800">{selectedTraveler.idNumber}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">نوع الوثيقة:</span>
                    <span className="font-medium text-slate-800">{selectedTraveler.idType}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">نوع الحركة:</span>
                    <span className="font-medium text-slate-800">{selectedTraveler.movementType || 'عام'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">العمر:</span>
                    <span className="font-medium text-slate-800">{selectedTraveler.age || '-'} سنة</span>
                  </div>
                </div>
              </div>

              {/* Dates Card */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-2">
                <h3 className="text-xs font-bold text-slate-800">صلاحيات وتواريخ الوثائق:</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                  <div>
                    <span className="text-slate-400 block">إصدار الجواز:</span>
                    <span className="font-mono font-bold">{selectedTraveler.passportIssueDate || '-'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">انتهاء الجواز:</span>
                    <span className="font-mono font-bold text-red-700">{selectedTraveler.passportExpiryDate || '-'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">انتهاء التأشيرة:</span>
                    <span className="font-mono font-bold text-amber-700">{selectedTraveler.visaExpiryDate || '-'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">انتهاء الإقامة:</span>
                    <span className="font-mono font-bold text-purple-700">{selectedTraveler.residencyExpiryDate || '-'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">المنفذ:</span>
                    <span className="font-medium">{selectedTraveler.center || selectedTraveler.entryPort || selectedTraveler.exitPort || '-'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">الوجهة:</span>
                    <span className="font-medium">{selectedTraveler.destination || '-'}</span>
                  </div>
                </div>
              </div>

              {/* Special Category Details */}
              {selectedTraveler.spouseFullName && (
                <div className="bg-rose-50 p-3.5 rounded-xl border border-rose-200 text-xs">
                  <h4 className="font-bold text-rose-900 mb-1">طلب زواج بيمنية:</h4>
                  <p>الزوجة: {selectedTraveler.spouseFullName} (رقم وطني: {selectedTraveler.spouseIdNumber || '-'})</p>
                  <p>رقم العقد: {selectedTraveler.marriageContractNumber || '-'} | المحكمة: {selectedTraveler.courtOrAuthority || '-'} | ولي الأمر: {selectedTraveler.marriageGuardianName || '-'}</p>
                </div>
              )}

              {selectedTraveler.foreignSpouseName && (
                <div className="bg-pink-50 p-3.5 rounded-xl border border-pink-200 text-xs">
                  <h4 className="font-bold text-pink-900 mb-1">طلب زواج بأجنبي:</h4>
                  <p>الطرف الأجنبي: {selectedTraveler.foreignSpouseName} | الجنسية: {selectedTraveler.foreignSpouseNationality || '-'}</p>
                  <p>الجواز: {selectedTraveler.foreignSpousePassport || '-'} | تصريح الداخلية: {selectedTraveler.foreignMarriageApprovalNumber || '-'}</p>
                </div>
              )}

              {selectedTraveler.citizenshipFileNumber && (
                <div className="bg-amber-50 p-3.5 rounded-xl border border-amber-200 text-xs">
                  <h4 className="font-bold text-amber-900 mb-1">طلب اكتساب الجنسية اليمنية:</h4>
                  <p>ملف رقم: {selectedTraveler.citizenshipFileNumber} | سنوات الإقامة: {selectedTraveler.residenceYearsInYemen || '-'} سنة</p>
                  <p>المستند: {selectedTraveler.citizenshipReason || '-'} | الحالة: {selectedTraveler.citizenshipStatus || '-'}</p>
                </div>
              )}

              {/* Additional / Excess Excel Data Card */}
              {selectedTraveler.additionalData && (
                <div className="bg-amber-50/80 p-4 rounded-xl border border-amber-200/90 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-amber-950 flex items-center gap-2">
                      <Layers className="h-4 w-4 text-amber-700" />
                      <span>بيانات إضافية وحقول فائضة (مستوردة من الإكسل):</span>
                    </h3>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-7 text-[11px] bg-white border-amber-300 text-amber-900 hover:bg-amber-100 gap-1 font-semibold"
                      onClick={() => {
                        navigator.clipboard.writeText(selectedTraveler.additionalData || '');
                        toast({ title: 'تم النسخ', description: 'تم نسخ البيانات الإضافية إلى الحافظة' });
                      }}
                    >
                      <Copy className="h-3 w-3" />
                      <span>نسخ البيانات</span>
                    </Button>
                  </div>
                  
                  <div className="bg-white rounded-lg border border-amber-200/70 divide-y divide-slate-100 max-h-56 overflow-y-auto">
                    {selectedTraveler.additionalData.split('\n').filter(Boolean).map((line, lIdx) => {
                      const slashIndex = line.indexOf('/');
                      const colHeader = slashIndex !== -1 ? line.substring(0, slashIndex).trim() : line.trim();
                      const colValue = slashIndex !== -1 ? line.substring(slashIndex + 1).trim() : '';

                      return (
                        <div key={lIdx} className="p-2.5 flex items-start justify-between gap-3 text-xs hover:bg-amber-50/40 transition-colors">
                          <span className="font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded text-[11px] shrink-0 font-mono">
                            {colHeader}
                          </span>
                          <span className="font-semibold text-amber-950 text-left font-mono break-all" dir="auto">
                            {colValue || '-'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* QR and Vetting Block */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400 block mb-1">سجل المباينة الأمنية:</span>
                  <p className="text-xs font-mono text-slate-800">{selectedTraveler.vettingResult || 'سليم أمنياً'}</p>
                  <p className="text-[11px] text-slate-500 mt-1">ضابط التحقيق: {selectedTraveler.investigatingOfficer || '-'}</p>
                </div>
                <QRCodeCanvas 
                  value={`PORT_SYS:${selectedTraveler.idNumber}:${formatTravelerFullName(selectedTraveler)}`}
                  size={60} 
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-200">
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedReportIds(selectedTraveler.linkedReportIds || []);
                      setIsLinkReportOpen(true);
                    }}
                    className="text-xs gap-1.5"
                  >
                    <LinkIcon className="h-3.5 w-3.5" />
                    <span>ربط ببلاغات</span>
                  </Button>

                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => {
                      setNewReportData({
                        title: `ضبط أمني: ${formatTravelerFullName(selectedTraveler)}`,
                        description: `تم إدراج بلاغ أمني لمنع المسافر (${formatTravelerFullName(selectedTraveler)}) وثيقة رقم (${selectedTraveler.idNumber})`,
                        type: 'منع من السفر وضبط'
                      });
                      setIsCreateReportOpen(true);
                    }}
                    className="text-xs gap-1.5"
                  >
                    <AlertTriangle className="h-3.5 w-3.5" />
                    <span>إصدار بلاغ ضبط</span>
                  </Button>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handlePrint(selectedTraveler)}
                    className="text-xs gap-1.5"
                  >
                    <Printer className="h-3.5 w-3.5" />
                    <span>طباعة</span>
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => setIsViewModalOpen(false)}
                    className="text-xs"
                  >
                    إغلاق
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Link Reports Modal */}
      <Dialog open={isLinkReportOpen} onOpenChange={setIsLinkReportOpen}>
        <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto p-6" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-base font-bold">ربط المسافر ببلاغات ضبط أمنية</DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              حدد البلاغات الأمنية المسجلة لربطها بملف المسافر الحالي.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-2.5 my-4">
            {allReports.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-4">لا توجد بلاغات مسجلة في النظام.</p>
            ) : (
              allReports.map((report: any) => {
                const isSelected = selectedReportIds.includes(report.id);
                return (
                  <div
                    key={report.id}
                    onClick={() => {
                      if (isSelected) {
                        setSelectedReportIds(prev => prev.filter(id => id !== report.id));
                      } else {
                        setSelectedReportIds(prev => [...prev, report.id]);
                      }
                    }}
                    className={`p-3 rounded-xl border text-xs cursor-pointer transition-colors ${
                      isSelected 
                        ? 'bg-red-50 border-red-300 text-red-900' 
                        : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <strong className="block">{report.title}</strong>
                      <span className="font-mono text-[10px] text-slate-400">{report.type}</span>
                    </div>
                    <p className="text-[11px] text-slate-600 line-clamp-1 mt-0.5">{report.description}</p>
                  </div>
                );
              })
            )}
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
            <Button variant="outline" size="sm" onClick={() => setIsLinkReportOpen(false)} className="text-xs">
              إلغاء
            </Button>
            <Button size="sm" onClick={handleSaveLinkedReports} className="text-xs font-bold">
              حفظ الربط
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Quick Create Report Modal */}
      <Dialog open={isCreateReportOpen} onOpenChange={setIsCreateReportOpen}>
        <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto p-6" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-base font-bold text-red-700 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              <span>إصدار بلاغ ضبط أمني فوري</span>
            </DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              سيتم إنشاء بلاغ رسمي في قائمة البلاغات وتغيير قرار السفر إلى «ممنوع» آلياً.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCreateReport} className="space-y-4 my-2">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">عنوان البلاغ</label>
              <Input
                required
                value={newReportData.title}
                onChange={(e) => setNewReportData(p => ({ ...p, title: e.target.value }))}
                className="text-xs"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">نوع البلاغ</label>
              <Select 
                value={newReportData.type} 
                onValueChange={(val) => setNewReportData(p => ({ ...p, type: val }))}
              >
                <SelectTrigger className="text-xs bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="منع من السفر وضبط">منع من السفر وضبط</SelectItem>
                  <SelectItem value="مطلوب أمنياً">مطلوب أمنياً</SelectItem>
                  <SelectItem value="اشتباه تزوير وثائق">اشتباه تزوير وثائق</SelectItem>
                  <SelectItem value="مخالفة أنظمة الإقامة">مخالفة أنظمة الإقامة والعمل</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">تفاصيل ومبررات البلاغ</label>
              <Textarea
                rows={3}
                value={newReportData.description}
                onChange={(e) => setNewReportData(p => ({ ...p, description: e.target.value }))}
                className="text-xs"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsCreateReportOpen(false)} className="text-xs">
                إلغاء
              </Button>
              <Button type="submit" variant="destructive" size="sm" className="text-xs font-bold">
                تأكيد إصدار البلاغ
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <DeleteConfirmation
        isOpen={Boolean(deleteId)}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDeleteTraveler}
        title="حذف سجل المعاملة"
        description="هل أنت متأكد من رغبتك في حذف هذا السجل نهائياً من قاعدة البيانات المحلية؟"
      />

      {/* Smart Excel, Vetting, and AI Column Detector Modal */}
      <SmartExcelImportModal
        isOpen={isSmartImportOpen}
        onClose={() => setIsSmartImportOpen(false)}
        excelData={parsedExcelRows}
        excelColumns={parsedExcelCols}
        fileName={importFileName}
        currentActiveTab={activeTab}
        onConfirmImport={handleConfirmSmartImport}
      />
    </div>

  );
}
