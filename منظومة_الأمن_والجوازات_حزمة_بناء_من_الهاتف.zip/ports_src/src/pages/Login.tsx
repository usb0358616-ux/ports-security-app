import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ShieldCheck, Lock, User as UserIcon, Fingerprint, Sparkles } from 'lucide-react';
import { setCurrentUser, getUsers } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';
import { BiometricLoginModal } from '@/components/BiometricLoginModal';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isBiometricOpen, setIsBiometricOpen] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Verify against local storage users
    const users = getUsers();
    const foundUser = users.find(u => u.username === username && u.password === password);

    setTimeout(() => {
      if (foundUser) {
        setCurrentUser(foundUser);
        toast({ title: 'تم تسجيل الدخول بنجاح', description: 'مرحباً بك في نظام المنافذ الذكي' });
        navigate('/');
      } else {
        toast({ 
          title: 'خطأ في الدخول', 
          description: 'اسم المستخدم أو كلمة المرور غير صحيحة', 
          variant: 'destructive' 
        });
      }
      setIsLoading(false);
    }, 400);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 px-4 py-8" dir="rtl">
      <Card className="w-full max-w-md shadow-2xl border-primary/20 backdrop-blur-xs">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto bg-primary/10 p-4 rounded-full w-fit text-primary ring-8 ring-primary/5">
            <ShieldCheck className="h-12 w-12" />
          </div>
          <div>
            <CardTitle className="text-2xl font-bold tracking-tight">نظام المنافذ والجوازات الذكي</CardTitle>
            <CardDescription className="text-xs mt-1">
              منظومة الرقابة والتفتيش الأمني للمنافذ البرية والجوية والبحرية
            </CardDescription>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Biometric Quick Login Action */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/20 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold flex items-center gap-1.5 text-primary">
                <Sparkles className="h-3.5 w-3.5" />
                الدخول السريع الآمن
              </span>
              <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-mono">
                FIDO2 / Biometrics
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              سجّل الدخول الفوري باستخدام قارئ بصمة الإصبع أو التعرف على الوجه المعتمد للجهاز.
            </p>
            <Button
              type="button"
              variant="default"
              onClick={() => setIsBiometricOpen(true)}
              className="w-full py-5 text-sm gap-2 bg-primary hover:bg-primary/90 text-primary-foreground shadow-md"
            >
              <Fingerprint className="h-5 w-5 animate-pulse" />
              <span>تسجيل الدخول بالبصمة الحيوية</span>
            </Button>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">أو الدخول ببيانات الحساب</span>
            </div>
          </div>

          {/* Traditional Login Form */}
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium pr-1 flex items-center gap-1.5">
                <UserIcon className="h-3.5 w-3.5 text-muted-foreground" />
                اسم المستخدم
              </label>
              <Input 
                autoFocus
                placeholder="أدخل اسم المستخدم" 
                value={username} 
                onChange={(e) => setUsername(e.target.value)}
                className="text-right"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium pr-1 flex items-center gap-1.5">
                <Lock className="h-3.5 w-3.5 text-muted-foreground" />
                كلمة المرور
              </label>
              <Input 
                type="password" 
                placeholder="••••••••" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)}
                className="text-right"
              />
            </div>
            <Button type="submit" variant="outline" className="w-full py-5 text-sm font-medium border-primary/20 hover:bg-muted" disabled={isLoading}>
              {isLoading ? 'جاري التحقق...' : 'دخول بكلمة المرور'}
            </Button>
          </form>

          <div className="p-3 bg-muted/60 rounded-lg border text-[11px] text-center text-muted-foreground">
            <p className="font-semibold text-foreground mb-0.5">الحسابات الافتراضية المحلية:</p>
            <p className="font-mono text-xs">المدير: admin (رمز: 1) | موظف: user (رمز: 1)</p>
          </div>

          <div className="border-t pt-4 text-center text-[11px] text-muted-foreground flex items-center justify-between">
            <span>نظام محلي مشفر (Offline First)</span>
            <span className="font-mono">v1.2.0</span>
          </div>
        </CardContent>
      </Card>

      <BiometricLoginModal
        isOpen={isBiometricOpen}
        onClose={() => setIsBiometricOpen(false)}
        onSuccess={() => {
          setIsBiometricOpen(false);
          navigate('/');
        }}
      />
    </div>
  );
};

export default Login;

