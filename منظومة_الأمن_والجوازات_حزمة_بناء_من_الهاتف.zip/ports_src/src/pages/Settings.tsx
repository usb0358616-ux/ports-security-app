import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { 
  Building2, 
  Save, 
  ShieldCheck, 
  MapPin, 
  BadgeCheck, 
  Bell, 
  Sparkles, 
  Users, 
  Database,
  Fingerprint,
  RefreshCw,
  HardDrive,
  Download,
  Upload,
  FileJson,
  FileText
} from 'lucide-react';
import { UsersManager } from '@/components/UsersManager';
import { getCurrentUser, getTravelers, getReports, getMovements } from '@/lib/storage';
import { useOfflineSync } from '@/lib/offlineSync';
import { exportFullSystemBackup, restoreFullSystemBackup, exportToCSV, exportToJSON } from '@/lib/exportUtils';
import { OfficialHeader, getOfficialHeaderConfig, saveOfficialHeaderConfig } from '@/components/OfficialHeader';

const Settings = () => {
  const [activeTab, setActiveTab] = useState<'general' | 'users'>('general');
  const currentUser = getCurrentUser();
  const { queueCount, lastSync, isSyncing, triggerSync } = useOfflineSync();
  const [dataStats, setDataStats] = useState({ travelers: 0, reports: 0, movements: 0 });

  useEffect(() => {
    setDataStats({
      travelers: getTravelers().length,
      reports: getReports().length,
      movements: getMovements().length,
    });
  }, []);

  const [config, setConfig] = useState({
    country: localStorage.getItem('config_country') || 'الجمهورية اليمنية',
    ministry: localStorage.getItem('config_ministry') || 'وزارة الداخلية',
    sector: localStorage.getItem('config_sector') || 'قطاع استخبارات الشرطة',
    agencyName: localStorage.getItem('config_agencyName') || 'مصلحة الهجرة والجوازات والجنسية',
    centerName: localStorage.getItem('config_centerName') || 'منفذ الوديعة البري',
    region: localStorage.getItem('config_region') || 'حضرموت',
    branchCode: localStorage.getItem('config_branchCode') || 'SHW-01',
    customLogo: localStorage.getItem('config_customLogo') || '',
    geminiKey: localStorage.getItem('config_geminiKey') || 'AIzaSyAAVh__MfT2Ubcx07nPWs5hzYRf3dKJlsg',
  });
  const { toast } = useToast();

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({ title: 'خطأ في الملف', description: 'يرجى اختيار ملف صورة صالح (PNG أو JPG).', variant: 'destructive' });
      return;
    }

    const reader = new FileReader();
    reader.onload = (evt) => {
      const base64 = evt.target?.result as string;
      setConfig(prev => ({ ...prev, customLogo: base64 }));
      toast({ title: 'تم تحميل الشعار بنجاح', description: 'انقر على حفظ الإعدادات لتثبيت الشعار في كافة المخرجات.' });
    };
    reader.readAsDataURL(file);
  };

  const handleResetLogo = () => {
    setConfig(prev => ({ ...prev, customLogo: '' }));
    toast({ title: 'تمت استعادة الشعار الرسمي الافتراضي' });
  };

  const handleSave = () => {
    saveOfficialHeaderConfig({
      country: config.country,
      ministry: config.ministry,
      sector: config.sector,
      agencyName: config.agencyName,
      centerName: config.centerName,
      branchCode: config.branchCode,
      customLogo: config.customLogo,
    });
    localStorage.setItem('config_region', config.region);
    localStorage.setItem('config_geminiKey', config.geminiKey);
    toast({ title: 'تم حفظ الإعدادات الرسمية', description: 'تم تحديث ترويسة التقارير والشعار في كافة وثائق النظام.' });
    setTimeout(() => window.location.reload(), 1000);
  };

  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!confirm('تحذير: سيتم استبدال البيانات المحلية الحالية بالبيانات الموجودة في ملف النسخة الاحتياطية. هل ترغب بالاستمرار؟')) {
      e.target.value = '';
      return;
    }

    const res = await restoreFullSystemBackup(file);
    if (res.success) {
      toast({ title: 'اكتملت الاستعادة', description: res.message });
      setTimeout(() => window.location.reload(), 1200);
    } else {
      toast({ title: 'فشلت الاستعادة', description: res.message, variant: 'destructive' });
    }
    e.target.value = '';
  };

  const isAdmin = currentUser?.role === 'آدمن';

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-primary">إعدادات النظام والمستخدمين</h1>
          <p className="text-muted-foreground mt-1 text-sm">
            تكوين معلومات المنفذ، إدارة الحسابات، صلاحيات البصمة الحيوية، والمزامنة المحلية (Offline)
          </p>
        </div>
        <div className="flex bg-muted p-1 rounded-lg">
          <Button 
            variant={activeTab === 'general' ? 'default' : 'ghost'} 
            size="sm"
            onClick={() => setActiveTab('general')}
            className="rounded-md"
          >
            الإعدادات العامة
          </Button>
          <Button 
            variant={activeTab === 'users' ? 'default' : 'ghost'} 
            size="sm"
            onClick={() => setActiveTab('users')}
            className="rounded-md gap-2"
          >
            <Users className="h-4 w-4" />
            إدارة المستخدمين والروابط الحيوية
          </Button>
        </div>
      </div>

      {activeTab === 'general' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Building2 className="h-5 w-5 text-primary" />
                  <CardTitle>الترويسة الرسمية وهوية المنفذ</CardTitle>
                </div>
                <CardDescription>
                  تظهر هذه المعلومات وشعار المنفذ في ترويسة كافة التقارير الرسمية والطباعة الورقية وملفات Word و PDF المعتمدة
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">اسم الدولة / السيادة</label>
                    <Input 
                      value={config.country} 
                      onChange={e => setConfig({...config, country: e.target.value})}
                      className="text-right font-bold"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">اسم الوزارة</label>
                    <Input 
                      value={config.ministry} 
                      onChange={e => setConfig({...config, ministry: e.target.value})}
                      className="text-right"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">القطاع الأمني / الإداري</label>
                    <Input 
                      value={config.sector} 
                      onChange={e => setConfig({...config, sector: e.target.value})}
                      className="text-right"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">اسم المصلحة / الوكالة</label>
                    <Input 
                      value={config.agencyName} 
                      onChange={e => setConfig({...config, agencyName: e.target.value})}
                      className="text-right"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">اسم المنفذ / المركز الحدودي</label>
                    <Input 
                      value={config.centerName} 
                      onChange={e => setConfig({...config, centerName: e.target.value})}
                      className="text-right font-bold text-primary"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <MapPin className="h-4 w-4" /> المحافظة / النطاق الجغرافي
                    </label>
                    <Input 
                      value={config.region} 
                      onChange={e => setConfig({...config, region: e.target.value})}
                      className="text-right"
                    />
                  </div>
                  <div className="space-y-2 col-span-full">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <BadgeCheck className="h-4 w-4" /> كود الفرع الاستخباراتي
                    </label>
                    <Input 
                      value={config.branchCode} 
                      onChange={e => setConfig({...config, branchCode: e.target.value})}
                      className="text-right font-mono"
                    />
                  </div>
                </div>

                {/* Custom Logo Upload Section */}
                <div className="border-t pt-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">شعار المنفذ / الهيئة (محلي Offline)</h4>
                      <p className="text-xs text-slate-500">
                        يتم تخزين صورة الشعار محلياً في جهازك بصيغة مشفرة للظهور في الطباعة والتصدير بدون إنترنت
                      </p>
                    </div>
                    {config.customLogo && (
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="sm" 
                        onClick={handleResetLogo}
                        className="text-xs text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                      >
                        استعادة الشعار الافتراضي
                      </Button>
                    )}
                  </div>

                  <div className="flex items-center gap-4 p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <div className="w-16 h-16 rounded-full border border-slate-300 bg-white flex items-center justify-center overflow-hidden shrink-0 shadow-2xs">
                      {config.customLogo ? (
                        <img src={config.customLogo} alt="شعار المنفذ" className="w-full h-full object-contain p-1" />
                      ) : (
                        <span className="text-[10px] text-slate-400 font-bold text-center p-1">الشعار الرسمي</span>
                      )}
                    </div>
                    <div className="flex-1 space-y-1.5">
                      <label className="inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer shadow-2xs transition-colors">
                        <Upload className="h-3.5 w-3.5 text-primary" />
                        <span>تحميل شعار من الجهاز (PNG / JPG)</span>
                        <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                      </label>
                      <p className="text-[11px] text-slate-500">
                        يفضل استخدام صورة مربعة أو دائرية مفرغة بخلفية شفافة لنتائج طباعة مثالية.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Live Preview of Official Header */}
                <div className="border-t pt-4 space-y-2">
                  <h4 className="text-xs font-bold text-slate-700">معاينة مباشرة للترويسة الرسمية المعتمدة:</h4>
                  <div className="p-4 bg-white rounded-xl border-2 border-slate-300 shadow-xs">
                    <OfficialHeader 
                      title="استمارة تدقيق ومعاينة رسمية"
                      subtitle={`المنفذ: ${config.centerName}`}
                      classification="رسمي - معتمد"
                    />
                  </div>
                </div>

                <div className="space-y-2 border-t pt-4">
                  <label className="text-sm font-medium flex items-center gap-2 text-primary">
                    <Sparkles className="h-4 w-4" /> مفتاح Gemini API (للذكاء الاصطناعي)
                  </label>
                  <Input 
                    type="password"
                    placeholder="أدخل مفتاح API هنا..."
                    value={config.geminiKey} 
                    onChange={e => setConfig({...config, geminiKey: e.target.value})}
                    className="text-right"
                  />
                  <p className="text-[10px] text-muted-foreground mt-1">
                    هذا المفتاح اختياري لمسح الجوازات آلياً وتحليل البلاغات السحابية. يعمل النظام محلياً بالكامل بدونه.
                  </p>
                </div>

                <div className="pt-2 flex justify-end">
                  <Button onClick={handleSave} className="gap-2 font-bold shadow-sm">
                    <Save className="h-4 w-4" /> حفظ الترويسة والإعدادات
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <ShieldCheck className="h-5 w-5 text-primary" />
                  <CardTitle>أمان النظام</CardTitle>
                </div>
                <CardDescription>إعدادات حماية البيانات والتشفير المحلي</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div>
                    <p className="font-medium">النسخ الاحتياطي التلقائي</p>
                    <p className="text-sm text-muted-foreground">حفظ نسخة من البيانات كل 6 ساعات في مجلد البرنامج</p>
                  </div>
                  <BadgeCheck className="h-5 w-5 text-green-500" />
                </div>
                <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div>
                    <p className="font-medium">التشفير (Offline AES-256)</p>
                    <p className="text-sm text-muted-foreground">حماية بيانات المسافرين في حالة فقدان الجهاز</p>
                  </div>
                  <BadgeCheck className="h-5 w-5 text-green-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="bg-primary text-primary-foreground">
              <CardHeader>
                <CardTitle className="text-lg">حالة النظام</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center text-sm">
                  <span>الإصدار</span>
                  <span className="font-mono">v1.1.2 (Standard)</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span>قاعدة البيانات</span>
                  <span className="font-mono">LocalStorage IndexedDB</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span>وضع التشغيل</span>
                  <span>محلي (Offline)</span>
                </div>
                <div className="pt-2">
                  <div className="h-2 bg-primary-foreground/20 rounded-full overflow-hidden">
                    <div className="h-full bg-accent w-[92%]"></div>
                  </div>
                  <p className="text-[10px] mt-1 opacity-80">تم تفعيل التخزين المحلي بنجاح</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Database className="h-4 w-4 text-primary" />
                    <CardTitle className="text-md">قاعدة البيانات المحلية (Offline Sync)</CardTitle>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={triggerSync}
                    disabled={isSyncing}
                    className="h-7 text-xs gap-1"
                  >
                    <RefreshCw className={`h-3 w-3 ${isSyncing ? 'animate-spin' : ''}`} />
                    <span>مزامنة</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between items-center py-1 border-b">
                    <span className="text-muted-foreground">سجلات المسافرين:</span>
                    <span className="font-bold">{dataStats.travelers} مسافر</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-b">
                    <span className="text-muted-foreground">بلاغات الضبط الأمني:</span>
                    <span className="font-bold">{dataStats.reports} بلاغ</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-b">
                    <span className="text-muted-foreground">حركة الأطقم والمتحركات:</span>
                    <span className="font-bold">{dataStats.movements} حركة</span>
                  </div>
                  <div className="flex justify-between items-center py-1">
                    <span className="text-muted-foreground">عمليات بانتظار المزامنة:</span>
                    <span className={`font-mono font-bold ${queueCount > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
                      {queueCount} عملية
                    </span>
                  </div>
                </div>
                <p className="text-[10px] text-muted-foreground pt-1">
                  آخر مزامنة لقاعدة البيانات: {new Date(lastSync).toLocaleTimeString('ar-YE')}
                </p>
              </CardContent>
            </Card>

            {/* Full System Backup & Restore Section */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <HardDrive className="h-4 w-4 text-primary" />
                  <CardTitle className="text-md">النسخ الاحتياطي والتصدير الخارجي</CardTitle>
                </div>
                <CardDescription className="text-xs">
                  تصدير نسخة كاملة أو استرجاعها للحفاظ على سجلات المنفذ
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  onClick={exportFullSystemBackup} 
                  className="w-full gap-2 text-xs h-9 bg-primary hover:bg-primary/90"
                >
                  <Download className="h-4 w-4" />
                  تصدير نسخة احتياطية كاملة (JSON)
                </Button>

                <div className="grid grid-cols-2 gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => exportToCSV(getTravelers(), 'كشف_المسافرين')}
                    className="text-xs h-8 gap-1.5"
                  >
                    <FileText className="h-3.5 w-3.5 text-emerald-600" />
                    المسافرين (CSV)
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => exportToCSV(getReports(), 'كشف_البلاغات')}
                    className="text-xs h-8 gap-1.5"
                  >
                    <FileText className="h-3.5 w-3.5 text-blue-600" />
                    البلاغات (CSV)
                  </Button>
                </div>

                <div className="border-t pt-2 mt-2">
                  <label className="text-[11px] text-muted-foreground block mb-1">استعادة نسخة احتياطية من ملف:</label>
                  <label className="flex items-center justify-center gap-2 w-full py-2 px-3 border border-dashed rounded-md text-xs font-medium cursor-pointer hover:bg-muted transition-colors">
                    <Upload className="h-3.5 w-3.5 text-primary" />
                    <span>رفع ملف النسخة الاحتياطية (.json)</span>
                    <input 
                      type="file" 
                      accept=".json" 
                      className="hidden" 
                      onChange={handleRestoreFile} 
                    />
                  </label>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Bell className="h-4 w-4" />
                  <CardTitle className="text-md">التنبيهات</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-xs text-muted-foreground">النظام يعمل في الوضع المحلي الكامل دون الحاجة لأي اتصال بالإنترنت.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      ) : (
        <UsersManager />
      )}
    </div>
  );
};

export default Settings;
