import { getTravelers, getReports, getMovements, checkTravelerExpirations, isNonYemeni } from '@/lib/storage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Users, FileText, AlertTriangle, Download, Printer, FileJson, 
  FileText as FileTextIcon, Image as ImageIcon, Globe, LogIn, LogOut, 
  ShieldAlert, CreditCard, Heart, Award
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { exportToExcel, exportToPDF, exportToImage, handlePrint } from '@/lib/exportUtils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Statistics = () => {
  const travelers = getTravelers();
  const reports = getReports();
  const movements = getMovements();

  // Calculation of statistics
  const totalTravelers = travelers.length;
  const entryCount = travelers.filter(t => t.movementType === 'دخول' || t.category === 'entry' || t.additionalCategories?.includes('entry')).length;
  const exitCount = travelers.filter(t => t.movementType === 'خروج' || t.category === 'exit' || t.additionalCategories?.includes('exit')).length;
  const foreignersCount = travelers.filter(t => t.isForeigner || isNonYemeni(t.country) || t.category === 'foreigner' || t.additionalCategories?.includes('foreigner')).length;
  const expiringCount = travelers.filter(t => checkTravelerExpirations(t).hasAlert).length;
  const deniedCount = travelers.filter(t => t.travelAllowed === 'لا').length;

  const stats = [
    { title: 'إجمالي المسافرين (القاعدة)', value: totalTravelers, icon: Users, color: 'text-blue-600' },
    { title: 'حركة الدخول (قادمون)', value: entryCount, icon: LogIn, color: 'text-teal-600' },
    { title: 'حركة الخروج (مغادرون)', value: exitCount, icon: LogOut, color: 'text-indigo-600' },
    { title: 'الأجانب والوافدون', value: foreignersCount, icon: Globe, color: 'text-emerald-600' },
    { title: 'تنبيهات انتهاء الوثائق (أسبوع)', value: expiringCount, icon: ShieldAlert, color: 'text-rose-600' },
    { title: 'الممنوعون من السفر / موقوفون', value: deniedCount, icon: AlertTriangle, color: 'text-red-600' },
    { title: 'بلاغات الضبط الأمنية', value: reports.length, icon: FileText, color: 'text-amber-600' },
    { title: 'حركة أطقم الدوريات', value: movements.filter(m => m.status === 'خروج').length, icon: Users, color: 'text-slate-600' },
  ];

  // Data for Category Breakdown
  const categoryBreakdown = [
    { name: 'دخول', count: entryCount, fill: '#0d9488' },
    { name: 'خروج', count: exitCount, fill: '#4f46e5' },
    { name: 'أجانب', count: foreignersCount, fill: '#10b981' },
    { name: 'تأشيرات', count: travelers.filter(t => t.category === 'visa_renewal' || t.additionalCategories?.includes('visa_renewal')).length, fill: '#7c3aed' },
    { name: 'إقامات', count: travelers.filter(t => t.category === 'residency_renewal' || t.additionalCategories?.includes('residency_renewal')).length, fill: '#06b6d4' },
    { name: 'زواج بيمنية', count: travelers.filter(t => t.category === 'marriage_yemeni_woman' || t.additionalCategories?.includes('marriage_yemeni_woman')).length, fill: '#e11d48' },
    { name: 'زواج بأجنبي', count: travelers.filter(t => t.category === 'marriage_foreigner' || t.additionalCategories?.includes('marriage_foreigner')).length, fill: '#ec4899' },
    { name: 'طلب جنسية', count: travelers.filter(t => t.category === 'citizenship_application' || t.additionalCategories?.includes('citizenship_application')).length, fill: '#f59e0b' },
    { name: 'هجرة غير شرعية', count: travelers.filter(t => t.category === 'illegal_immigrant' || t.additionalCategories?.includes('illegal_immigrant')).length, fill: '#dc2626' },
  ];

  // Data for Pie Chart (Travel Allowed vs Denied)
  const pieData = [
    { name: 'مسموح بالسفر', value: travelers.filter(t => t.travelAllowed === 'نعم').length, color: '#10b981' },
    { name: 'ممنوع من السفر', value: deniedCount, color: '#ef4444' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center no-print bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">الإحصائيات والتقارير الشاملة</h1>
          <p className="text-xs text-slate-500 mt-1">مؤشرات حركات المنافذ، شؤون الأجانب، معاملات الجنسية، وتنبيهات انتهاء الوثائق.</p>
        </div>
        <div className="flex gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2 border-slate-300">
                <Download className="h-4 w-4" /> تصدير الإحصائيات
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" dir="rtl">
              <DropdownMenuItem onClick={() => exportToExcel(stats, 'إحصائيات_نظام_المنافذ')}>
                <FileJson className="h-4 w-4 ml-2 text-emerald-600" /> Excel
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportToPDF('stats-content', 'إحصائيات_نظام_المنافذ')}>
                <FileTextIcon className="h-4 w-4 ml-2 text-rose-600" /> PDF
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportToImage('stats-content', 'إحصائيات_نظام_المنافذ')}>
                <ImageIcon className="h-4 w-4 ml-2 text-purple-600" /> صورة PNG
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button variant="outline" onClick={handlePrint} className="gap-2 border-slate-300">
            <Printer className="h-4 w-4" /> طباعة
          </Button>
        </div>
      </div>

      <div id="stats-content" className="space-y-6">
        {/* KPI Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((s, i) => (
            <Card key={i} className="shadow-xs border border-slate-200/80 bg-white">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-xs font-semibold text-slate-500">{s.title}</CardTitle>
                <s.icon className={`h-5 w-5 ${s.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold font-mono text-slate-900">{s.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Category Breakdown Bar Chart */}
          <Card className="p-5 shadow-xs border border-slate-200/80 min-h-[380px] bg-white">
            <CardTitle className="text-sm font-bold text-slate-800 mb-4">توزيع المعاملات وحركات المنافذ</CardTitle>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryBreakdown}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          {/* Travel Permission Pie Chart */}
          <Card className="p-5 shadow-xs border border-slate-200/80 min-h-[380px] bg-white">
            <CardTitle className="text-sm font-bold text-slate-800 mb-4">نسبة السماح والمنع من السفر</CardTitle>
            <div className="h-[300px] w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={85}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-col gap-2.5 mr-4 shrink-0">
                {pieData.map((d, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color }}></div>
                    <span className="font-semibold text-slate-700">{d.name}:</span>
                    <span className="font-mono font-bold text-slate-900">{d.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Statistics;
