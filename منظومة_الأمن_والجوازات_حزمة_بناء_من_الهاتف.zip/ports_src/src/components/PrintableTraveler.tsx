import React from 'react';
import { Traveler } from '@/lib/types';
import { formatTravelerFullName, checkTravelerExpirations } from '@/lib/storage';
import { OfficialHeader } from '@/components/OfficialHeader';

interface PrintableTravelerProps {
  traveler: Traveler | null;
}

export const PrintableTraveler: React.FC<PrintableTravelerProps> = ({ traveler }) => {
  if (!traveler) return null;

  const today = new Date();
  const dateStr = `${today.getDate()} / ${today.getMonth() + 1} / ${today.getFullYear()}م`;
  const fullName = formatTravelerFullName(traveler);
  const expirationData = checkTravelerExpirations(traveler);

  const getCategoryLabel = () => {
    switch (traveler.category) {
      case 'entry': return 'حركة دخول (قادمون عبر المنفذ)';
      case 'exit': return 'حركة خروج (مغادرون عبر المنفذ)';
      case 'foreigner': return 'أجانب ووافدون';
      case 'illegal_immigrant': return 'مهاجر غير شرعي / ضبط حدودي';
      case 'refugee': return 'شؤون اللاجئين (UNHCR)';
      case 'visa_renewal': return 'طلبات ومعاملات التأشيرات';
      case 'residency_renewal': return 'طلبات ومعاملات الإقامات';
      case 'marriage_yemeni_woman': return 'طلب تصريح زواج بيمنية';
      case 'marriage_foreigner': return 'طلب تصريح زواج بأجنبي';
      case 'citizenship_application': return 'طلب اكتساب الجنسية اليمنية';
      default: return 'مسافر (مواطن / عام)';
    }
  };

  return (
    <div id="printable-traveler" className="print-only print-view-container text-black" dir="rtl">
      {/* Unified Official Government Header */}
      <OfficialHeader
        title="استمارة تدقيق ومعاينة رسمية"
        subtitle={`التصنيف: ${getCategoryLabel()}`}
        documentNumber={traveler.requestNumber || traveler.idNumber}
        dateStr={dateStr}
        classification={traveler.travelAllowed === 'نعم' ? 'رسمي - مصرح' : 'سري - مقيد أمنياً'}
        qrPayload={`SMART_PORT:${traveler.idNumber}:${fullName}:${traveler.travelAllowed}:${traveler.category}`}
      />

      {/* Urgent Document Expiration Warning if <= 7 days */}
      {expirationData.hasAlert && (
        <div className="mb-4 p-2.5 border-2 border-slate-900 bg-slate-100 text-xs">
          <p className="font-bold text-slate-900 mb-1">⚠️ إشعار تدقيق انتهاء الوثائق (أسبوع أو أقل / منتهي):</p>
          <ul className="list-disc list-inside space-y-0.5 font-bold">
            {expirationData.alerts.map((alert, idx) => (
              <li key={idx} className="text-slate-800">
                {alert.label}: {alert.badgeText} (تاريخ الانتهاء المسجل: {alert.date})
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Main Content Layout */}
      <div className="flex gap-6 mb-6">
        {/* Photo & Status */}
        <div className="w-36 flex flex-col items-center gap-2">
          {traveler.photoUrl ? (
            <img 
              src={traveler.photoUrl} 
              alt="صورة المسافر" 
              className="w-32 h-40 object-cover border-2 border-slate-900 rounded" 
            />
          ) : (
            <div className="w-32 h-40 border-2 border-dashed border-slate-400 rounded flex items-center justify-center text-xs text-slate-500 text-center p-2">
              لا توجد صورة شخصية
            </div>
          )}
          <div className={`w-full py-1.5 px-2 text-center text-xs font-bold border ${
            traveler.travelAllowed === 'نعم' 
              ? 'bg-slate-100 border-slate-800 text-slate-900' 
              : 'bg-slate-200 border-slate-900 text-slate-900'
          }`}>
            القرار: {traveler.travelAllowed === 'نعم' ? 'مسموح بالسفر / الإجراء ✓' : 'ممنوع / قيد التوقيف ✗'}
          </div>
        </div>

        {/* Data Table */}
        <div className="flex-1">
          <table className="w-full border-collapse border border-slate-800 text-xs">
            <tbody>
              <tr className="bg-slate-100 font-bold">
                <td colSpan={4} className="border border-slate-800 p-1.5 text-center">البيانات الشخصية وهوية المعاملة</td>
              </tr>
              <tr>
                <td className="border border-slate-800 p-1.5 font-bold w-28 bg-slate-50">الاسم الكامل:</td>
                <td colSpan={3} className="border border-slate-800 p-1.5 font-bold text-sm">
                  {fullName}
                </td>
              </tr>
              <tr>
                <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">رقم الوثيقة:</td>
                <td className="border border-slate-800 p-1.5 font-mono font-bold">{traveler.idNumber}</td>
                <td className="border border-slate-800 p-1.5 font-bold w-24 bg-slate-50">نوع الوثيقة:</td>
                <td className="border border-slate-800 p-1.5">{traveler.idType}</td>
              </tr>
              <tr>
                <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">الجنسية:</td>
                <td className="border border-slate-800 p-1.5 font-bold">
                  {traveler.country} {traveler.isForeigner ? '(أجنبي / وافد)' : '(مواطن)'}
                </td>
                <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">العمر:</td>
                <td className="border border-slate-800 p-1.5">{traveler.age || '-'} سنة</td>
              </tr>
              <tr>
                <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">المحافظة / المدينة:</td>
                <td className="border border-slate-800 p-1.5">{traveler.governorate || '-'}</td>
                <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">رقم الهاتف:</td>
                <td className="border border-slate-800 p-1.5 font-mono">{traveler.phone || '-'}</td>
              </tr>
              <tr>
                <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">نوع الحركة:</td>
                <td className="border border-slate-800 p-1.5 font-bold">{traveler.movementType || 'عام'}</td>
                <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">الوجهة / المقصد:</td>
                <td className="border border-slate-800 p-1.5">{traveler.destination || '-'}</td>
              </tr>

              {/* Passport, Visa, and Residency Dates */}
              <tr className="bg-slate-100 font-bold">
                <td colSpan={4} className="border border-slate-800 p-1.5 text-center">تواريخ صلاحية الجوازات والتأشيرات والإقامات</td>
              </tr>
              <tr>
                <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">إصدار الجواز:</td>
                <td className="border border-slate-800 p-1.5 font-mono">{traveler.passportIssueDate || '-'}</td>
                <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">انتهاء الجواز:</td>
                <td className="border border-slate-800 p-1.5 font-mono font-bold">{traveler.passportExpiryDate || '-'}</td>
              </tr>
              {(traveler.visaIssueDate || traveler.visaExpiryDate || traveler.visaNumber) && (
                <tr>
                  <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">إصدار التأشيرة:</td>
                  <td className="border border-slate-800 p-1.5 font-mono">{traveler.visaIssueDate || '-'} (رقم: {traveler.visaNumber || '-'})</td>
                  <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">انتهاء التأشيرة:</td>
                  <td className="border border-slate-800 p-1.5 font-mono font-bold">{traveler.visaExpiryDate || '-'}</td>
                </tr>
              )}
              {(traveler.residencyIssueDate || traveler.residencyExpiryDate || traveler.residencyNumber) && (
                <tr>
                  <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">إصدار الإقامة:</td>
                  <td className="border border-slate-800 p-1.5 font-mono">{traveler.residencyIssueDate || '-'} (رقم: {traveler.residencyNumber || '-'})</td>
                  <td className="border border-slate-800 p-1.5 font-bold bg-slate-50">انتهاء الإقامة:</td>
                  <td className="border border-slate-800 p-1.5 font-mono font-bold">{traveler.residencyExpiryDate || '-'}</td>
                </tr>
              )}

              {/* Movement Details (Entry / Exit) */}
              {traveler.movementType === 'دخول' && (
                <tr className="bg-emerald-50">
                  <td className="border border-slate-800 p-1.5 font-bold text-emerald-950">بيانات الدخول:</td>
                  <td colSpan={3} className="border border-slate-800 p-1.5 text-emerald-950">
                    منفذ الدخول: <strong>{traveler.entryPort || traveler.center || '-'}</strong> | تاريخ الدخول: <strong>{traveler.entryDate || '-'}</strong> | جهة القدوم: <strong>{traveler.originCountry || '-'}</strong> | وسيلة النقل: {traveler.entryCarrierOrFlight || '-'} | الغرض: {traveler.entryPurpose || traveler.visitReason || '-'}
                  </td>
                </tr>
              )}

              {traveler.movementType === 'خروج' && (
                <tr className="bg-blue-50">
                  <td className="border border-slate-800 p-1.5 font-bold text-blue-950">بيانات الخروج:</td>
                  <td colSpan={3} className="border border-slate-800 p-1.5 text-blue-950">
                    منفذ الخروج: <strong>{traveler.exitPort || traveler.center || '-'}</strong> | تاريخ الخروج: <strong>{traveler.exitDate || '-'}</strong> | جهة المغادرة: <strong>{traveler.destinationCountry || traveler.destination || '-'}</strong> | وسيلة النقل: {traveler.exitCarrierOrFlight || '-'} | تصريح الخروج: {traveler.exitPermitNumber || '-'}
                  </td>
                </tr>
              )}

              {/* Marriage to Yemeni Woman */}
              {traveler.category === 'marriage_yemeni_woman' && (
                <tr className="bg-rose-50">
                  <td className="border border-slate-800 p-1.5 font-bold text-rose-950">طلب زواج بيمنية:</td>
                  <td colSpan={3} className="border border-slate-800 p-1.5 text-rose-950">
                    الزوجة: <strong>{traveler.spouseFullName || '-'}</strong> (رقم وطني: {traveler.spouseIdNumber || '-'}) | رقم العقد: {traveler.marriageContractNumber || '-'} | المحكمة: {traveler.courtOrAuthority || '-'} | ولي الأمر: {traveler.marriageGuardianName || '-'} | حالة الموافقة: <strong>{traveler.marriageApprovalStatus || '-'}</strong>
                  </td>
                </tr>
              )}

              {/* Marriage to Foreigner */}
              {traveler.category === 'marriage_foreigner' && (
                <tr className="bg-pink-50">
                  <td className="border border-slate-800 p-1.5 font-bold text-pink-950">طلب زواج بأجنبي:</td>
                  <td colSpan={3} className="border border-slate-800 p-1.5 text-pink-950">
                    الطرف الأجنبي: <strong>{traveler.foreignSpouseName || '-'}</strong> | الجنسية: {traveler.foreignSpouseNationality || '-'} | الجواز: {traveler.foreignSpousePassport || '-'} | رقم تصريح الداخلية: {traveler.foreignMarriageApprovalNumber || '-'} | الحالة: <strong>{traveler.marriageApprovalStatus || '-'}</strong>
                  </td>
                </tr>
              )}

              {/* Citizenship Application */}
              {traveler.category === 'citizenship_application' && (
                <tr className="bg-amber-50">
                  <td className="border border-slate-800 p-1.5 font-bold text-amber-950">طلب الجنسية اليمنية:</td>
                  <td colSpan={3} className="border border-slate-800 p-1.5 text-amber-950">
                    رقم الملف: <strong>{traveler.citizenshipFileNumber || '-'}</strong> | تاريخ التقديم: {traveler.citizenshipApplicationDate || '-'} | سنوات الإقامة باليمن: {traveler.residenceYearsInYemen || '-'} سنة | السبب: {traveler.citizenshipReason || '-'} | الحالة: <strong>{traveler.citizenshipStatus || '-'}</strong>
                  </td>
                </tr>
              )}

              {/* Undocumented Migrant */}
              {traveler.category === 'illegal_immigrant' && (
                <tr className="bg-amber-50">
                  <td className="border border-slate-800 p-1.5 font-bold text-amber-900">الضبط والإبعاد:</td>
                  <td colSpan={3} className="border border-slate-800 p-1.5 text-amber-900">
                    نقطة الضبط: {traveler.interceptionPoint || '-'} | التاريخ: {traveler.interceptionDate || '-'} | خط التسلل: {traveler.smugglingRoute || '-'} | التبصيم: {traveler.biometricsTaken || '-'} | حالة الإبعاد: {traveler.deportationStatus || '-'}
                  </td>
                </tr>
              )}

              {/* Refugee */}
              {traveler.category === 'refugee' && (
                <tr className="bg-emerald-50">
                  <td className="border border-slate-800 p-1.5 font-bold text-emerald-900">شؤون اللاجئين:</td>
                  <td colSpan={3} className="border border-slate-800 p-1.5 text-emerald-900">
                    رقم المفوضية: {traveler.unhcrNumber || '-'} | الصفة: {traveler.refugeeStatus || '-'} | المقر: {traveler.campLocation || '-'} | المرافقين: {traveler.dependentsCount || 0}
                  </td>
                </tr>
              )}

              {/* Vetting */}
              <tr className="bg-slate-100 font-bold">
                <td colSpan={4} className="border border-slate-800 p-1.5 text-center">نتائج الفحص والمباينة الأمنية</td>
              </tr>
              <tr>
                <td className="border border-slate-800 p-2 font-bold bg-slate-50 align-top">سجل المباينة:</td>
                <td colSpan={3} className="border border-slate-800 p-2 font-mono text-xs whitespace-pre-wrap">
                  {traveler.vettingResult || 'سليم أمنياً - لا توجد قيود مسجلة'}
                </td>
              </tr>

              {/* Additional / Excess Excel Data Fields */}
              {traveler.additionalData && traveler.additionalData.trim() && (
                <>
                  <tr className="bg-amber-50/80 font-bold">
                    <td colSpan={4} className="border border-slate-800 p-1.5 text-center text-amber-950">
                      البيانات والمعلومات الإضافية (من واقع سجلات الاستيراد)
                    </td>
                  </tr>
                  <tr>
                    <td className="border border-slate-800 p-2 font-bold bg-amber-50/50 align-top text-amber-950">
                      الحقول الإضافية:
                    </td>
                    <td colSpan={3} className="border border-slate-800 p-2">
                      <div className="space-y-1.5">
                        {traveler.additionalData.split('\n').filter(Boolean).map((line, idx) => {
                          const slashIndex = line.indexOf('/');
                          const colHeader = slashIndex !== -1 ? line.substring(0, slashIndex).trim() : line.trim();
                          const colVal = slashIndex !== -1 ? line.substring(slashIndex + 1).trim() : '';

                          return (
                            <div key={idx} className="flex items-start gap-2 text-xs border-b border-dotted border-slate-300 pb-1 last:border-none last:pb-0">
                              <span className="font-bold text-slate-900 bg-slate-100 px-1.5 py-0.5 rounded text-[11px] shrink-0">
                                {colHeader} /
                              </span>
                              <span className="font-mono text-slate-800 leading-relaxed font-semibold">
                                {colVal || '-'}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </td>
                  </tr>
                </>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Official Signatures & Seal Block */}
      <div className="border-t border-slate-800 pt-6 mt-8">
        <div className="grid grid-cols-3 gap-6 text-center text-xs">
          <div>
            <p className="font-bold mb-8">ضابط المعاينة والتدقيق</p>
            <p className="border-t border-dotted border-slate-600 pt-1">الاسم والتوقيع: ..........................</p>
          </div>
          <div>
            <p className="font-bold mb-8">ختم المنفذ الرسمي</p>
            <div className="w-20 h-20 mx-auto border-2 border-dashed border-slate-400 rounded-full flex items-center justify-center text-[10px] text-slate-500">
              مكان الختم
            </div>
          </div>
          <div>
            <p className="font-bold mb-8">مدير المنفذ / قائد الفرع</p>
            <p className="border-t border-dotted border-slate-600 pt-1">الاسم والتوقيع: ..........................</p>
          </div>
        </div>
      </div>

      <div className="mt-8 text-center text-[10px] text-slate-500 border-t pt-2">
        وثيقة صادرة إلكترونياً من نظام المنافذ والجوازات الذكي · مطابقة للبيانات المحلية المعتمدة
      </div>
    </div>
  );
};
