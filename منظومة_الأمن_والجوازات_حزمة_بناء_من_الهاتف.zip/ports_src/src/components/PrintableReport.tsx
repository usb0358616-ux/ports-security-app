import React from 'react';
import { Report } from '@/lib/types';
import { getTravelers } from '@/lib/storage';
import { OfficialHeader } from '@/components/OfficialHeader';

interface PrintableReportProps {
  report: Report | null;
}

export const PrintableReport: React.FC<PrintableReportProps> = ({ report }) => {
  if (!report) return null;

  const allTravelers = getTravelers();
  const linkedTravelers = allTravelers.filter(t => report.linkedTravelerIds?.includes(t.id));
  const today = new Date(report.createdAt || Date.now());
  const dateStr = `${today.getDate()} / ${today.getMonth() + 1} / ${today.getFullYear()}م`;

  return (
    <div id="printable-report" className="print-only print-view-container text-black" dir="rtl">
      {/* Unified Official Government Header */}
      <OfficialHeader
        title="تقرير بلاغ ضبط أمني"
        subtitle={`تصنيف البلاغ: ${report.type || 'عام'}`}
        documentNumber={report.id}
        dateStr={dateStr}
        classification={report.status === 'جديد' ? 'سري وعاجل للغاية' : 'سري - رسمي'}
        qrPayload={`SECURITY_REPORT:${report.id}:${report.title}:${report.type}`}
      />

      {/* Report Info Table */}
      <div className="mb-6">
        <table className="w-full border-collapse border border-slate-800 text-xs">
          <tbody>
            <tr className="bg-slate-100 font-bold">
              <td colSpan={4} className="border border-slate-800 p-2 text-center text-sm">بيانات موضوع البلاغ الأمني</td>
            </tr>
            <tr>
              <td className="border border-slate-800 p-2 font-bold w-32 bg-slate-50">عنوان البلاغ:</td>
              <td className="border border-slate-800 p-2 font-bold text-sm" colSpan={3}>{report.title}</td>
            </tr>
            <tr>
              <td className="border border-slate-800 p-2 font-bold bg-slate-50">نوع / تصنيف البلاغ:</td>
              <td className="border border-slate-800 p-2">{report.type}</td>
              <td className="border border-slate-800 p-2 font-bold w-28 bg-slate-50">درجة الأهمية:</td>
              <td className="border border-slate-800 p-2 font-bold text-red-700">
                {report.status === 'جديد' ? 'عاجل ومهم' : report.status}
              </td>
            </tr>
            <tr>
              <td className="border border-slate-800 p-3 font-bold bg-slate-50 align-top">تفاصيل الواقعة والشرح:</td>
              <td colSpan={3} className="border border-slate-800 p-3 whitespace-pre-wrap leading-relaxed text-xs">
                {report.description}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Linked Travelers Section if any */}
      {linkedTravelers.length > 0 && (
        <div className="mb-6">
          <h3 className="font-bold text-xs mb-2 border-b border-slate-400 pb-1">المسافرين المقترنين بهذا البلاغ ({linkedTravelers.length})</h3>
          <table className="w-full border-collapse border border-slate-800 text-xs">
            <thead>
              <tr className="bg-slate-100">
                <th className="border border-slate-800 p-1.5 text-right">الاسم الكامل</th>
                <th className="border border-slate-800 p-1.5 text-right">رقم الوثيقة</th>
                <th className="border border-slate-800 p-1.5 text-right">الجنسية</th>
                <th className="border border-slate-800 p-1.5 text-right">القرار الأمني</th>
              </tr>
            </thead>
            <tbody>
              {linkedTravelers.map(t => (
                <tr key={t.id}>
                  <td className="border border-slate-800 p-1.5 font-bold">
                    {t.firstName} {t.secondName} {t.thirdName} {t.fourthName} {t.lastName}
                  </td>
                  <td className="border border-slate-800 p-1.5 font-mono">{t.idNumber}</td>
                  <td className="border border-slate-800 p-1.5">{t.country}</td>
                  <td className="border border-slate-800 p-1.5 font-bold">
                    {t.travelAllowed === 'نعم' ? 'مسموح بالسفر' : 'ممنوع من السفر (مطلوب)'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Signatures & Approval */}
      <div className="border-t border-slate-800 pt-6 mt-10">
        <div className="grid grid-cols-3 gap-6 text-center text-xs">
          <div>
            <p className="font-bold mb-8">محرر البلاغ والتحريات</p>
            <p className="border-t border-dotted border-slate-600 pt-1">الرتبة والاسم: ..........................</p>
          </div>
          <div>
            <p className="font-bold mb-8">ختم وتصديق إدارة الضبط</p>
            <div className="w-20 h-20 mx-auto border-2 border-dashed border-slate-400 rounded-full flex items-center justify-center text-[10px] text-slate-500">
              مكان الختم
            </div>
          </div>
          <div>
            <p className="font-bold mb-8">مدير أمن المنفذ / قائد الفرع</p>
            <p className="border-t border-dotted border-slate-600 pt-1">التوقيع والاعتماد: ..........................</p>
          </div>
        </div>
      </div>

      <div className="mt-8 text-center text-[10px] text-slate-500 border-t pt-2">
        بلاغ أمني رسمي صادر عن منظومة الرقابة الأمنية للمنافذ · سرّي وللاستخدام الرسمي فقط
      </div>
    </div>
  );
};
