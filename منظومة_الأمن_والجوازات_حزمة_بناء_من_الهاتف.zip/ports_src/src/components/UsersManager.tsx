import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { getUsers, saveUsers, generateId, getCurrentUser } from '@/lib/storage';
import { registerBiometric, removeBiometric } from '@/lib/biometrics';
import { User } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { 
  UserPlus, 
  Trash2, 
  Key, 
  UserCog, 
  Fingerprint, 
  ShieldCheck, 
  Shield, 
  CheckCircle2, 
  XCircle, 
  Search,
  Lock,
  UserCheck
} from 'lucide-react';

export const UsersManager = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUserSession] = useState<User | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  // New User Form State
  const [newUser, setNewUser] = useState({
    name: '',
    username: '',
    password: '',
    confirmPassword: '',
    role: 'مدخل بيانات' as User['role'],
    biometricEnabled: false,
  });

  // Password Change Modal State
  const [passwordModalOpen, setPasswordModalOpen] = useState(false);
  const [targetUserId, setTargetUserId] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  // Edit User Modal State
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const { toast } = useToast();

  useEffect(() => {
    loadUsers();
    setCurrentUserSession(getCurrentUser());
  }, []);

  const loadUsers = () => {
    setUsers(getUsers());
  };

  const handleAddUser = () => {
    if (!newUser.name.trim() || !newUser.username.trim() || !newUser.password) {
      toast({ title: 'بيانات ناقصة', description: 'يرجى إدخال جميع الحقول المطلوبة', variant: 'destructive' });
      return;
    }

    if (newUser.password !== newUser.confirmPassword) {
      toast({ title: 'خطأ', description: 'كلمتا المرور غير متطابقتين', variant: 'destructive' });
      return;
    }

    if (users.some(u => u.username.toLowerCase() === newUser.username.trim().toLowerCase())) {
      toast({ title: 'اسم مستخدم مكرر', description: 'اسم المستخدم مسجل مسبقاً، اختر اسماً آخر', variant: 'destructive' });
      return;
    }

    const createdUser: User = {
      id: generateId(),
      name: newUser.name.trim(),
      username: newUser.username.trim(),
      password: newUser.password,
      role: newUser.role,
      biometricEnabled: newUser.biometricEnabled,
      createdAt: new Date().toISOString(),
    };

    const updatedUsers = [...users, createdUser];
    setUsers(updatedUsers);
    saveUsers(updatedUsers);

    setNewUser({
      name: '',
      username: '',
      password: '',
      confirmPassword: '',
      role: 'مدخل بيانات',
      biometricEnabled: false,
    });

    toast({ 
      title: 'تم إنشاء المستخدم', 
      description: `تمت إضافة ${createdUser.name} برتبة (${createdUser.role}) بنجاح وحفظه محلياً.` 
    });
  };

  const handleDeleteUser = (id: string) => {
    if (id === '1' || id === currentUser?.id) {
      toast({ title: 'إجراء محظور', description: 'لا يمكن حذف الحساب الإداري الرئيسي أو الحساب الحالي', variant: 'destructive' });
      return;
    }

    if (!confirm('هل أنت متأكد من حذف هذا المستخدم نهائياً؟')) {
      return;
    }

    const updatedUsers = users.filter(u => u.id !== id);
    setUsers(updatedUsers);
    saveUsers(updatedUsers);
    toast({ title: 'تم الحذف', description: 'تم إزالة المستخدم من قاعدة البيانات المحلية' });
  };

  const openPasswordDialog = (id: string) => {
    setTargetUserId(id);
    setNewPassword('');
    setConfirmNewPassword('');
    setPasswordModalOpen(true);
  };

  const handleSaveNewPassword = () => {
    if (!targetUserId || !newPassword) {
      toast({ title: 'خطأ', description: 'يرجى إدخال كلمة المرور الجديدة', variant: 'destructive' });
      return;
    }

    if (newPassword !== confirmNewPassword) {
      toast({ title: 'خطأ', description: 'كلمتا المرور غير متطابقتين', variant: 'destructive' });
      return;
    }

    const updatedUsers = users.map(u => u.id === targetUserId ? { ...u, password: newPassword } : u);
    setUsers(updatedUsers);
    saveUsers(updatedUsers);
    setPasswordModalOpen(false);
    toast({ title: 'تم تغيير كلمة المرور', description: 'تم حفظ كلمة المرور الجديدة محلياً بنجاح' });
  };

  const openEditDialog = (user: User) => {
    setEditingUser({ ...user });
    setEditModalOpen(true);
  };

  const handleSaveEditUser = () => {
    if (!editingUser) return;
    if (!editingUser.name.trim() || !editingUser.username.trim()) {
      toast({ title: 'خطأ', description: 'الاسم واسم المستخدم مطلوبان', variant: 'destructive' });
      return;
    }

    if (users.some(u => u.username.toLowerCase() === editingUser.username.trim().toLowerCase() && u.id !== editingUser.id)) {
      toast({ title: 'خطأ', description: 'اسم المستخدم مستخدم من قبل حساب آخر', variant: 'destructive' });
      return;
    }

    const updatedUsers = users.map(u => u.id === editingUser.id ? editingUser : u);
    setUsers(updatedUsers);
    saveUsers(updatedUsers);
    setEditModalOpen(false);
    toast({ title: 'تم التحديث', description: 'تم تحديث بيانات المستخدم وصلاحياته بنجاح' });
  };

  const handleToggleBiometric = async (user: User) => {
    if (user.biometricEnabled) {
      removeBiometric(user.id);
      loadUsers();
      toast({ title: 'تم إلغاء البصمة', description: `تم تعطيل البصمة الحيوية للمستخدم ${user.name}` });
    } else {
      const result = await registerBiometric(user, 'fingerprint');
      if (result.success) {
        loadUsers();
        toast({ 
          title: 'تم تسجيل البصمة الحيوية', 
          description: `تم تفعيل التوثيق بالبصمة للمستخدم ${user.name} بنجاح` 
        });
      } else {
        toast({ title: 'تعذر التسجيل', description: result.error || 'فشل تسجيل البصمة', variant: 'destructive' });
      }
    }
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.role.includes(searchQuery)
  );

  const biometricCount = users.filter(u => u.biometricEnabled).length;
  const adminCount = users.filter(u => u.role === 'آدمن').length;
  const officerCount = users.filter(u => u.role === 'ضابط').length;

  return (
    <div className="space-y-6" dir="rtl">
      {/* Quick Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card className="p-4 bg-card border-primary/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground font-medium">إجمالي المستخدمين</p>
              <h3 className="text-2xl font-bold mt-1">{users.length}</h3>
            </div>
            <UserCheck className="h-8 w-8 text-primary opacity-80" />
          </div>
        </Card>

        <Card className="p-4 bg-card border-primary/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground font-medium">المسؤولين (Admins)</p>
              <h3 className="text-2xl font-bold mt-1 text-primary">{adminCount}</h3>
            </div>
            <ShieldCheck className="h-8 w-8 text-primary opacity-80" />
          </div>
        </Card>

        <Card className="p-4 bg-card border-primary/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground font-medium">الضباط والمحققين</p>
              <h3 className="text-2xl font-bold mt-1 text-sky-600">{officerCount}</h3>
            </div>
            <Shield className="h-8 w-8 text-sky-600 opacity-80" />
          </div>
        </Card>

        <Card className="p-4 bg-card border-primary/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground font-medium">مفعلو البصمة الحيوية</p>
              <h3 className="text-2xl font-bold mt-1 text-emerald-600">{biometricCount}</h3>
            </div>
            <Fingerprint className="h-8 w-8 text-emerald-600 opacity-80" />
          </div>
        </Card>
      </div>

      {/* Add New User Section */}
      <Card className="border-primary/20 shadow-sm">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <UserPlus className="h-5 w-5" />
            </div>
            <div>
              <CardTitle className="text-lg">إضافة مستخدم جديد للنظام</CardTitle>
              <CardDescription className="text-xs">
                إنشاء حساب محلي لموظف بالمنفذ وتعيين رتبته وصلاحياته وربط البصمة الحيوية
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold">الاسم الكامل للموظف *</label>
              <Input 
                value={newUser.name}
                onChange={e => setNewUser({...newUser, name: e.target.value})}
                placeholder="مثال: نقيب أحمد محمد السالمي"
                className="text-right"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold">اسم المستخدم (Username) *</label>
              <Input 
                value={newUser.username}
                onChange={e => setNewUser({...newUser, username: e.target.value.toLowerCase().replace(/\s+/g, '_')})}
                placeholder="مثال: ahmed_salmi"
                className="text-right font-mono"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold">الرتبة والصلاحية (Role) *</label>
              <Select 
                value={newUser.role} 
                onValueChange={(val: User['role']) => setNewUser({...newUser, role: val})}
              >
                <SelectTrigger className="text-right">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent dir="rtl">
                  <SelectItem value="مدخل بيانات">مدخل بيانات (تسجيل المسافرين والمتحركات)</SelectItem>
                  <SelectItem value="ضابط">ضابط (المعاينة الجنائية واعتماد البلاغات)</SelectItem>
                  <SelectItem value="آدمن">آدمن (مدير النظام - صلاحيات كاملة)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold">كلمة المرور *</label>
              <Input 
                type="password"
                value={newUser.password}
                onChange={e => setNewUser({...newUser, password: e.target.value})}
                placeholder="••••••••"
                className="text-right"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold">تأكيد كلمة المرور *</label>
              <Input 
                type="password"
                value={newUser.confirmPassword}
                onChange={e => setNewUser({...newUser, confirmPassword: e.target.value})}
                placeholder="••••••••"
                className="text-right"
              />
            </div>

            <div className="flex items-end">
              <Button onClick={handleAddUser} className="w-full gap-2 py-5 shadow-sm">
                <UserPlus className="h-4 w-4" /> حفظ وإضافة المستخدم
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Users List & Management */}
      <Card className="border-primary/20 shadow-sm">
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10 text-primary">
                <UserCog className="h-5 w-5" />
              </div>
              <div>
                <CardTitle className="text-lg">قائمة مستخدمي المنفذ المحليين</CardTitle>
                <CardDescription className="text-xs">
                  إدارة الصلاحيات، تغيير كلمات المرور، وتفعيل البصمة الحيوية المحلية
                </CardDescription>
              </div>
            </div>

            {/* Search Input */}
            <div className="relative w-full sm:w-64">
              <Search className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="بحث بالاسم أو الرتبة..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pr-9 text-xs"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border overflow-hidden">
            <Table>
              <TableHeader className="bg-muted/50">
                <TableRow>
                  <TableHead className="text-right font-bold">اسم الموظف</TableHead>
                  <TableHead className="text-right font-bold">اسم المستخدم</TableHead>
                  <TableHead className="text-right font-bold">الصلاحية</TableHead>
                  <TableHead className="text-right font-bold">حالة البصمة الحيوية</TableHead>
                  <TableHead className="text-left font-bold min-w-[220px]">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground text-xs">
                      لا يوجد مستخدمين مطابقين للبحث
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id} className="hover:bg-muted/30">
                      <TableCell className="font-medium text-sm">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-foreground">{user.name}</span>
                          {user.id === currentUser?.id && (
                            <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded-sm font-medium">
                              حسابك الحالي
                            </span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">
                        @{user.username}
                      </TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold ${
                          user.role === 'آدمن' 
                            ? 'bg-purple-500/10 text-purple-700 dark:text-purple-300 border border-purple-500/20' 
                            : user.role === 'ضابط'
                            ? 'bg-sky-500/10 text-sky-700 dark:text-sky-300 border border-sky-500/20'
                            : 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20'
                        }`}>
                          {user.role}
                        </span>
                      </TableCell>
                      <TableCell>
                        {user.biometricEnabled ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-600 border border-emerald-500/20">
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            <span>بصمة مفعلة</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-muted text-muted-foreground border">
                            <XCircle className="h-3.5 w-3.5" />
                            <span>غير مسجلة</span>
                          </span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5 justify-start">
                          {/* Biometric Enrollment Toggle */}
                          <Button
                            variant={user.biometricEnabled ? 'outline' : 'secondary'}
                            size="sm"
                            onClick={() => handleToggleBiometric(user)}
                            className="h-8 text-xs gap-1"
                            title={user.biometricEnabled ? 'إلغاء البصمة الحيوية' : 'تسجيل بصمة الإصبع'}
                          >
                            <Fingerprint className={`h-3.5 w-3.5 ${user.biometricEnabled ? 'text-emerald-500' : 'text-primary'}`} />
                            <span className="hidden sm:inline">{user.biometricEnabled ? 'تعطيل' : 'تسجيل بصمة'}</span>
                          </Button>

                          {/* Edit User & Role */}
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => openEditDialog(user)}
                            className="h-8 text-xs gap-1"
                            title="تعديل البيانات والصلاحية"
                          >
                            <UserCog className="h-3.5 w-3.5" />
                            <span className="hidden sm:inline">الصلاحية</span>
                          </Button>

                          {/* Change Password */}
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => openPasswordDialog(user.id)}
                            className="h-8 text-xs gap-1"
                            title="تغيير كلمة المرور"
                          >
                            <Key className="h-3.5 w-3.5" />
                            <span className="hidden sm:inline">كلمة السر</span>
                          </Button>

                          {/* Delete */}
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 text-destructive hover:text-destructive/90 hover:bg-destructive/10"
                            onClick={() => handleDeleteUser(user.id)}
                            disabled={user.id === '1' || user.id === currentUser?.id}
                            title={user.id === '1' ? 'لا يمكن حذف المسؤول الرئيسي' : 'حذف المستخدم'}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Role Permissions Reference */}
      <Card className="bg-muted/40 border-dashed">
        <CardHeader className="py-4">
          <CardTitle className="text-sm flex items-center gap-2">
            <Shield className="h-4 w-4 text-primary" />
            جدول مصفوفة الصلاحيات الأمنية بالمنفذ
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-muted-foreground pb-4">
          <div className="p-3 bg-card rounded-lg border">
            <span className="font-bold text-purple-600 block mb-1">آدمن (مدير النظام)</span>
            <p>إدارة الحسابات، تغيير كلمات المرور، التحكم بالبصمات الحيوية، تهيئة المنفذ، وحذف وتعديل كافة السجلات.</p>
          </div>
          <div className="p-3 bg-card rounded-lg border">
            <span className="font-bold text-sky-600 block mb-1">ضابط (التحقيق والمنافذ)</span>
            <p>إجراء المعاينة والتدقيق الأمني، اتخاذ قرارات المنع والسماح بالسفر، اعتماد تقارير الضبط، وفحص القيود الجنائية.</p>
          </div>
          <div className="p-3 bg-card rounded-lg border">
            <span className="font-bold text-emerald-600 block mb-1">مدخل بيانات (تشغيل)</span>
            <p>تسجيل بيانات المسافرين الجدد، إدخال حركة المركبات والمتحركات اليومية، وعرض السجلات المصرح بها فقط.</p>
          </div>
        </CardContent>
      </Card>

      {/* Change Password Modal */}
      <Dialog open={passwordModalOpen} onOpenChange={setPasswordModalOpen}>
        <DialogContent className="sm:max-w-md text-right" dir="rtl">
          <DialogHeader className="text-right">
            <DialogTitle className="text-lg flex items-center gap-2">
              <Lock className="h-5 w-5 text-primary" />
              تغيير كلمة المرور
            </DialogTitle>
            <DialogDescription className="text-xs">
              أدخل كلمة المرور الجديدة وتأكيدها للمستخدم المحدد
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold">كلمة المرور الجديدة</label>
              <Input
                type="password"
                value={newPassword}
                onChange={e => setNewPassword(e.target.value)}
                placeholder="••••••••"
                className="text-right"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold">تأكيد كلمة المرور</label>
              <Input
                type="password"
                value={confirmNewPassword}
                onChange={e => setConfirmNewPassword(e.target.value)}
                placeholder="••••••••"
                className="text-right"
              />
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button onClick={handleSaveNewPassword} className="gap-1.5">
              <Key className="h-4 w-4" /> حفظ كلمة المرور
            </Button>
            <Button variant="outline" onClick={() => setPasswordModalOpen(false)}>
              إلغاء
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit User & Role Modal */}
      <Dialog open={editModalOpen} onOpenChange={setEditModalOpen}>
        <DialogContent className="sm:max-w-md text-right" dir="rtl">
          <DialogHeader className="text-right">
            <DialogTitle className="text-lg flex items-center gap-2">
              <UserCog className="h-5 w-5 text-primary" />
              تعديل بيانات ورتبة المستخدم
            </DialogTitle>
            <DialogDescription className="text-xs">
              تحديث الاسم، اسم المستخدم، وتعيين الرتبة والصلاحية الأمنية
            </DialogDescription>
          </DialogHeader>

          {editingUser && (
            <div className="space-y-4 py-2">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold">الاسم الكامل</label>
                <Input
                  value={editingUser.name}
                  onChange={e => setEditingUser({ ...editingUser, name: e.target.value })}
                  className="text-right"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold">اسم المستخدم</label>
                <Input
                  value={editingUser.username}
                  onChange={e => setEditingUser({ ...editingUser, username: e.target.value })}
                  className="text-right font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold">تعيين الصلاحية والرتبة</label>
                <Select
                  value={editingUser.role}
                  onValueChange={(val: User['role']) => setEditingUser({ ...editingUser, role: val })}
                >
                  <SelectTrigger className="text-right">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent dir="rtl">
                    <SelectItem value="مدخل بيانات">مدخل بيانات</SelectItem>
                    <SelectItem value="ضابط">ضابط</SelectItem>
                    <SelectItem value="آدمن">آدمن</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-0">
            <Button onClick={handleSaveEditUser} className="gap-1.5">
              <CheckCircle2 className="h-4 w-4" /> حفظ التغييرات
            </Button>
            <Button variant="outline" onClick={() => setEditModalOpen(false)}>
              إلغاء
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
