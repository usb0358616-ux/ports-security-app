import React, { useState } from 'react';
import { usePWAInstall } from '@/hooks/usePWAInstall';
import { Download, Smartphone, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [justInstalled, setJustInstalled] = useState(false);

  // If already running as an installed PWA, show a subtle installed indicator or null
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <Button
        variant="outline"
        size="sm"
        onClick={async () => {
          const success = await install();
          if (success) setJustInstalled(true);
        }}
        className="h-8 gap-1.5 text-xs font-medium border-primary/30 text-primary hover:bg-primary/10 shadow-sm"
      >
        {justInstalled ? (
          <>
            <Check className="h-3.5 w-3.5 text-emerald-500" />
            <span>تم التثبيت</span>
          </>
        ) : (
          <>
            <Smartphone className="h-3.5 w-3.5" />
            <span>تثبيت التطبيق على الجهاز</span>
          </>
        )}
      </Button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowIOSGuide(true)}
          className="h-8 gap-1.5 text-xs font-medium border-primary/30 text-primary hover:bg-primary/10"
        >
          <Download className="h-3.5 w-3.5" />
          <span>تثبيت على الشاشة</span>
        </Button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs" dir="rtl">
            <div className="w-full max-w-sm rounded-xl bg-card border p-5 shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b pb-3">
                <h3 className="text-base font-bold text-foreground flex items-center gap-2">
                  <Smartphone className="h-4 w-4 text-primary" />
                  تثبيت النظام على iPhone / iPad
                </h3>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setShowIOSGuide(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <ol className="space-y-2 text-xs text-muted-foreground list-decimal pr-4">
                <li>اضغط على زر <strong>المشاركة (Share)</strong> في شريط متصفح سفاري.</li>
                <li>مرر للأسفل واختر <strong>إضافة إلى الشاشة الرئيسية (Add to Home Screen)</strong>.</li>
                <li>اضغط على <strong>إضافة (Add)</strong> في الزاوية العلوية.</li>
              </ol>
              <Button onClick={() => setShowIOSGuide(false)} className="w-full h-8 text-xs">
                فهمت
              </Button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
