import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Fingerprint, ScanFace, CheckCircle2, AlertCircle, Shield, User as UserIcon } from 'lucide-react';
import { User } from '@/lib/types';
import { getUsers, setCurrentUser } from '@/lib/storage';
import { authenticateWithBiometric } from '@/lib/biometrics';
import { useToast } from '@/hooks/use-toast';

interface BiometricLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User) => void;
}

export const BiometricLoginModal = ({ isOpen, onClose, onSuccess }: BiometricLoginModalProps) => {
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [status, setStatus] = useState<'idle' | 'scanning' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      const allUsers = getUsers();
      setUsers(allUsers);
      const biometricUser = allUsers.find(u => u.biometricEnabled) || allUsers[0];
      if (biometricUser) {
        setSelectedUserId(biometricUser.id);
      }
      setStatus('idle');
      setErrorMessage('');
    }
  }, [isOpen]);

  const handleStartScan = async () => {
    const targetUser = users.find(u => u.id === selectedUserId) || users[0];
    if (!targetUser) return;

    setIsScanning(true);
    setStatus('scanning');
    setErrorMessage('');

    try {
      const result = await authenticateWithBiometric(targetUser);

      if (result.success && result.user) {
        setStatus('success');
        setCurrentUser(result.user);
        toast({
          title: 'تم التحقق بنجاح',
          description: `مرحباً بك، ${result.user.name} (${result.user.role})`,
        });
        setTimeout(() => {
          setIsScanning(false);
          onSuccess(result.user!);
        }, 800);
      } else {
        setStatus('error');
        setErrorMessage(result.error || 'فشل التحقق من البصمة. يرجى المحاولة مرة أخرى.');
        setIsScanning(false);
      }
    } catch (err: any) {
      setStatus('error');
      setErrorMessage(err.message || 'حدث خطأ أثناء فحص البصمة.');
      setIsScanning(false);
    }
  };

  const selectedUser = users.find(u => u.id === selectedUserId);

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && !isScanning && onClose()}>
      <DialogContent className="sm:max-w-md text-right border-primary/20" dir="rtl">
        <DialogHeader className="text-center sm:text-center space-y-2">
          <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-1">
            <Shield className="h-6 w-6" />
          </div>
          <DialogTitle className="text-xl font-bold">تسجيل الدخول بالبصمة الحيوية</DialogTitle>
          <DialogDescription className="text-xs">
            التحقق الأمني عبر حساس بصمة الإصبع أو التعرف على الوجه المحلي
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-3">
          {/* User selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
              <UserIcon className="h-3.5 w-3.5" />
              المستخدم المراد تسجيل الدخول إليه:
            </label>
            <select
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              disabled={isScanning}
              className="w-full bg-background border border-input rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary text-right"
            >
              {users.map(u => (
                <option key={u.id} value={u.id}>
                  {u.name} ({u.role}) {u.biometricEnabled ? '— بصمة مسجلة ✓' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Scanner visualizer */}
          <div className="flex flex-col items-center justify-center py-6 bg-muted/40 rounded-xl border border-dashed border-primary/20 relative overflow-hidden">
            {status === 'scanning' && (
              <div className="absolute inset-0 bg-primary/5 flex items-center justify-center">
                <div className="w-32 h-32 rounded-full border-2 border-primary/40 animate-ping opacity-75" />
                <div className="absolute w-24 h-24 rounded-full border border-primary animate-pulse" />
              </div>
            )}

            <div className={`relative z-10 p-5 rounded-full transition-all duration-300 ${
              status === 'scanning' 
                ? 'bg-primary/20 text-primary scale-110 shadow-lg shadow-primary/20' 
                : status === 'success'
                ? 'bg-emerald-500/20 text-emerald-600 scale-105'
                : status === 'error'
                ? 'bg-destructive/20 text-destructive'
                : 'bg-background text-muted-foreground hover:text-primary hover:border-primary border'
            }`}>
              {status === 'success' ? (
                <CheckCircle2 className="h-16 w-16 text-emerald-600 animate-in zoom-in" />
              ) : selectedUser?.biometricType === 'face' ? (
                <ScanFace className="h-16 w-16" />
              ) : (
                <Fingerprint className="h-16 w-16" />
              )}
            </div>

            <p className="mt-4 text-xs font-medium text-center">
              {status === 'scanning' && 'جاري قراءة البصمة الحيوية ومطابقتها...'}
              {status === 'success' && 'تم التحقق بنجاح! جاري تحويلك...'}
              {status === 'error' && (
                <span className="text-destructive flex items-center gap-1 justify-center">
                  <AlertCircle className="h-3.5 w-3.5" />
                  {errorMessage}
                </span>
              )}
              {status === 'idle' && 'ضع إصبعك على الحساس أو انقر لبدء المسح'}
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex gap-2">
            <Button
              onClick={handleStartScan}
              disabled={isScanning}
              className="flex-1 py-5 text-sm gap-2"
            >
              <Fingerprint className="h-4 w-4" />
              {isScanning ? 'جاري التحقق...' : 'فحص البصمة الآن'}
            </Button>
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isScanning}
              className="py-5"
            >
              إلغاء
            </Button>
          </div>

          <p className="text-[11px] text-center text-muted-foreground">
            تشفير محلي آمن متوافق مع معايير FIDO2 / WebAuthn للأجهزة المحمولة وحواسيب المنافذ
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};
