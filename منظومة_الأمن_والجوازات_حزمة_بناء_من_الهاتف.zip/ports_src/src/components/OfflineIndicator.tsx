import React from 'react';
import { useOfflineSync } from '@/lib/offlineSync';
import { Wifi, WifiOff, RefreshCw, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

export const OfflineStatusBadge: React.FC = () => {
  const { isOnline, queueCount, isSyncing, triggerSync } = useOfflineSync();

  return (
    <div className="flex items-center gap-2">
      <div 
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
          isOnline 
            ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20 dark:text-emerald-400' 
            : 'bg-amber-500/15 text-amber-700 border-amber-500/30 dark:text-amber-400'
        }`}
        title={isOnline ? 'الجهاز متصل بالشبكة ومحلي بالكامل' : 'الوضع غير المتصل (Offline) - كافة البيانات محفوظة محلياً'}
      >
        {isOnline ? (
          <>
            <Wifi className="h-3.5 w-3.5" />
            <span>متصل</span>
          </>
        ) : (
          <>
            <WifiOff className="h-3.5 w-3.5 animate-pulse" />
            <span>وضع غير متصل (Offline)</span>
          </>
        )}
      </div>

      {queueCount > 0 ? (
        <Button
          variant="outline"
          size="sm"
          onClick={triggerSync}
          disabled={isSyncing}
          className="h-7 text-xs gap-1 border-amber-500/40 text-amber-700 dark:text-amber-300 hover:bg-amber-500/10"
        >
          <RefreshCw className={`h-3 w-3 ${isSyncing ? 'animate-spin' : ''}`} />
          <span>مزامنة ({queueCount})</span>
        </Button>
      ) : (
        <div className="hidden sm:flex items-center gap-1 text-[11px] text-muted-foreground">
          <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
          <span>محفوظ محلياً</span>
        </div>
      )}
    </div>
  );
};

export const OfflineBanner: React.FC = () => {
  const { isOnline, queueCount } = useOfflineSync();

  if (isOnline && queueCount === 0) return null;

  return (
    <aside 
      aria-label="حالة الاتصال بالشبكة"
      className="bg-amber-600 text-white text-xs px-4 py-1.5 flex items-center justify-between shadow-sm animate-in fade-in duration-300"
    >
      <div className="flex items-center gap-2">
        <WifiOff className="h-4 w-4" />
        <span>
          <strong>تنبيه الوضع المحلي (Offline Mode):</strong> النظام يعمل بكامل طاقته دون إنترنت. يتم حفظ كافة المسافرين والبلاغات محلياً في جهازك.
        </span>
      </div>
      {queueCount > 0 && (
        <span className="bg-amber-800/60 px-2 py-0.5 rounded text-[11px] font-mono">
          {queueCount} عملية في طابور الحفظ
        </span>
      )}
    </aside>
  );
};
