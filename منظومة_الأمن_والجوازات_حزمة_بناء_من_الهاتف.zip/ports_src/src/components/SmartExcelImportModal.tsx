import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  FileSpreadsheet, Sparkles, CheckCircle2, AlertTriangle, ArrowRight, 
  HelpCircle, Check, RefreshCw, Eye, ShieldCheck, Layers, FileSearch
} from 'lucide-react';
import { KNOWN_SYSTEM_FIELDS, autoMatchColumn, FieldMappingDefinition, extractExcessRowData } from '@/lib/excelSmartDetector';
import { smartDetectExcelColumnsWithAI } from '@/services/geminiService';
import { useToast } from '@/hooks/use-toast';

export type ImportMode = 'excel_smart' | 'vetting_only' | 'standard';

interface SmartExcelImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  excelData: any[]; // Raw JSON parsed rows from Excel
  excelColumns: string[]; // Detected headers
  fileName: string;
  onConfirmImport: (mappedRows: any[], importMode: ImportMode, targetDefaultCategory: string) => void;
  currentActiveTab: string;
}

export const SmartExcelImportModal: React.FC<SmartExcelImportModalProps> = ({
  isOpen,
  onClose,
  excelData,
  excelColumns,
  fileName,
  onConfirmImport,
  currentActiveTab,
}) => {
  const [columnMapping, setColumnMapping] = useState<Record<string, string>>({});
  const [importMode, setImportMode] = useState<ImportMode>('excel_smart');
  const [targetCategory, setTargetCategory] = useState<string>(currentActiveTab === 'expiring' ? 'traveler' : currentActiveTab);
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [activeStep, setActiveStep] = useState<'configure' | 'preview'>('configure');
  const { toast } = useToast();

  // Initialize or reset mappings whenever modal opens or columns change
  React.useEffect(() => {
    if (isOpen && excelColumns.length > 0) {
      const initialMap: Record<string, string> = {};
      excelColumns.forEach(col => {
        const match = autoMatchColumn(col);
        initialMap[col] = match.matchedField || '';
      });
      setColumnMapping(initialMap);
      setTargetCategory(currentActiveTab === 'expiring' ? 'traveler' : currentActiveTab);
      setActiveStep('configure');
    }
  }, [isOpen, excelColumns, currentActiveTab]);

  // Handle single column mapping change
  const handleMappingChange = (excelCol: string, targetFieldKey: string) => {
    setColumnMapping(prev => ({
      ...prev,
      [excelCol]: targetFieldKey === 'IGNORE' ? '' : targetFieldKey,
    }));
  };

  // Run AI Column Detector (Gemini)
  const handleRunAiDetector = async () => {
    if (!navigator.onLine) {
      toast({
        title: 'وضع عدم الاتصال (Offline)',
        description: 'المطابقة الذكية التلقائية تعمل محلياً بنجاح 100%. الذكاء الاصطناعي السحابي يتطلب إنترنت.',
      });
      return;
    }

    setIsAiProcessing(true);
    try {
      const aiResults = await smartDetectExcelColumnsWithAI(excelColumns, excelData.slice(0, 5));
      setColumnMapping(prev => {
        const updated = { ...prev };
        for (const [col, field] of Object.entries(aiResults)) {
          if (field) {
            updated[col] = field;
          }
        }
        return updated;
      });
      toast({
        title: 'اكتمل التحليل الذكي للأعمدة',
        description: 'تم التعرف على بنية الأعمدة وربطها بالحقول المناسبة عبر النموذج الذكي.',
      });
    } catch (err: any) {
      toast({
        title: 'تنبيه التحليل الذكي',
        description: err.message || 'تعذر استدعاء الذكاء الاصطناعي، يرجى الاعتماد على المطابقة المحلية التلقائية.',
        variant: 'destructive',
      });
    } finally {
      setIsAiProcessing(false);
    }
  };

  // Reset to local heuristics
  const handleResetToAuto = () => {
    const freshMap: Record<string, string> = {};
    excelColumns.forEach(col => {
      const match = autoMatchColumn(col);
      freshMap[col] = match.matchedField || '';
    });
    setColumnMapping(freshMap);
    toast({ title: 'تمت إعادة المطابقة الذكية المحلية' });
  };

  // Calculate statistics
  const mappedCount = Object.values(columnMapping).filter(Boolean).length;
  const unmappedColumns = excelColumns.filter(col => !columnMapping[col] || columnMapping[col] === 'additionalData');
  const isNameMapped = Object.values(columnMapping).some(v => v === 'fullName' || v === 'firstName');
  const isIdMapped = Object.values(columnMapping).some(v => v === 'idNumber');
  const isVettingMapped = Object.values(columnMapping).some(v => v === 'vettingResult');

  // Preview processed data including excess data
  const processedPreview = React.useMemo(() => {
    return excelData.slice(0, 5).map(row => {
      const transformed: Record<string, any> = {};
      Object.entries(columnMapping).forEach(([col, fieldKey]) => {
        if (fieldKey && fieldKey !== 'additionalData' && row[col] !== undefined) {
          transformed[fieldKey] = row[col];
        }
      });
      // Extract excess unmapped columns
      const excess = extractExcessRowData(row, columnMapping);
      if (excess) {
        transformed.additionalData = excess;
      }
      return transformed;
    });
  }, [excelData, columnMapping]);

  // Execute Import
  const handleExecuteImport = () => {
    if (!isNameMapped && !isIdMapped && importMode !== 'vetting_only') {
      toast({
        title: 'تنبيه المطابقة',
        description: 'يرجى مطابقة حقل الاسم أو رقم الوثيقة/الجواز لضمان تخزين البيانات بدقة.',
        variant: 'destructive',
      });
      return;
    }

    // Transform full dataset using the finalized column mapping
    const finalTransformedRows = excelData.map(rawRow => {
      const item: Record<string, any> = {};
      Object.entries(columnMapping).forEach(([col, fieldKey]) => {
        if (fieldKey && fieldKey !== 'additionalData' && rawRow[col] !== undefined && rawRow[col] !== null) {
          item[fieldKey] = rawRow[col];
        }
      });

      // Collect all excess / unmapped columns into additionalData: [اسم العمود / القيمة]
      const excess = extractExcessRowData(rawRow, columnMapping);
      if (excess) {
        item.additionalData = excess;
      }

      return item;
    });

    onConfirmImport(finalTransformedRows, importMode, targetCategory);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[92vh] overflow-hidden flex flex-col p-0 rounded-2xl" dir="rtl">
        {/* Modal Header */}
        <div className="p-6 bg-slate-900 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl">
                <FileSpreadsheet className="h-6 w-6" />
              </div>
              <div>
                <DialogTitle className="text-lg font-bold text-white flex items-center gap-2">
                  <span>المعالج الذكي لاستيراد ملفات الإكسل والمباينة</span>
                  <Badge variant="secondary" className="bg-emerald-500/20 text-emerald-300 border-none text-[11px]">
                    التعرف الذكي على الأعمدة
                  </Badge>
                </DialogTitle>
                <DialogDescription className="text-xs text-slate-300 mt-0.5">
                  الملف: <span className="font-mono text-emerald-300">{fileName}</span> ({excelData.length} سجل، {excelColumns.length} عمود)
                </DialogDescription>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={handleRunAiDetector}
              disabled={isAiProcessing}
              className="bg-purple-950/40 border-purple-400 text-purple-200 hover:bg-purple-900/60 text-xs font-bold gap-1.5"
            >
              <Sparkles className={`h-3.5 w-3.5 ${isAiProcessing ? 'animate-spin text-purple-300' : 'text-purple-400'}`} />
              {isAiProcessing ? 'جارِ التحليل...' : 'استيراد ذكي (AI)'}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={handleResetToAuto}
              className="text-slate-300 hover:text-white hover:bg-slate-800 text-xs gap-1"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              إعادة التعرف
            </Button>
          </div>
        </div>

        {/* Mode Selector and Quick Options Bar */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-4">
            <span className="font-bold text-slate-700">نوع العملية:</span>
            <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-slate-200 shadow-2xs">
              <button
                type="button"
                onClick={() => setImportMode('excel_smart')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                  importMode === 'excel_smart' 
                    ? 'bg-primary text-white shadow-xs' 
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                استيراد سجلات ذكي شامل
              </button>
              <button
                type="button"
                onClick={() => setImportMode('vetting_only')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
                  importMode === 'vetting_only' 
                    ? 'bg-amber-600 text-white shadow-xs' 
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <ShieldCheck className="h-3.5 w-3.5" />
                استيراد المباينة والقيود الأمنية فقط
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700">القسم / التبويب الافتراضي:</span>
            <Select value={targetCategory} onValueChange={setTargetCategory}>
              <SelectTrigger className="h-8 text-xs w-44 bg-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="traveler">المسافرين (كافة السجلات)</SelectItem>
                <SelectItem value="foreigner">الأجانب (غير يمنيين)</SelectItem>
                <SelectItem value="entry">حركة الدخول (قادمون)</SelectItem>
                <SelectItem value="exit">حركة الخروج (مغادرون)</SelectItem>
                <SelectItem value="visa_renewal">التأشيرات</SelectItem>
                <SelectItem value="residency_renewal">الإقامات</SelectItem>
                <SelectItem value="marriage_yemeni_woman">زواج بيمنية</SelectItem>
                <SelectItem value="marriage_foreigner">زواج بأجنبي</SelectItem>
                <SelectItem value="citizenship_application">طالب جنسية</SelectItem>
                <SelectItem value="refugee">اللاجئين</SelectItem>
                <SelectItem value="illegal_immigrant">مهاجرين غير شرعيين</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Body Content - Scrollable */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Status Banner */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 text-xs text-emerald-900 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0" />
              <div>
                <strong>التعرف التلقائي مكتمل:</strong> تم ربط{' '}
                <span className="font-bold underline">{mappedCount}</span> عمود من أصل{' '}
                <span className="font-bold">{excelColumns.length}</span>. سيتم توجيه السجلات تلقائياً (غير اليمني للأجانب، حركات الدخول/الخروج، والتأشيرات والإقامات، وتنبيهات انتهاء الوثائق).
              </div>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={() => setActiveStep('configure')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                  activeStep === 'configure' ? 'bg-emerald-600 text-white' : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                تخصيص الأعمدة
              </button>
              <button
                type="button"
                onClick={() => setActiveStep('preview')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 ${
                  activeStep === 'preview' ? 'bg-emerald-600 text-white' : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                <Eye className="h-3.5 w-3.5" />
                معاينة عينة البيانات
              </button>
            </div>
          </div>

          {activeStep === 'configure' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Layers className="h-4 w-4 text-slate-500" />
                  <span>مطابقة أعمدة ملف الإكسل مع حقول النظام الذكي</span>
                </h3>
                <span className="text-[11px] text-slate-500">
                  يمكنك تغيير أي حقل إذا اختلفت تسميته في ملفك عن التسميات الافتراضية
                </span>
              </div>

              {/* Excess Columns Aggregation Notice */}
              <div className="bg-amber-50/90 border border-amber-200 rounded-xl p-3 flex items-start gap-3 text-xs text-amber-900 shadow-2xs">
                <div className="p-1.5 bg-amber-200/60 rounded-lg text-amber-800 shrink-0 mt-0.5">
                  <Layers className="h-4 w-4" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-amber-950">تجميع ذكي وتلقائي للأعمدة الفائضة والزائدة:</span>
                    <Badge variant="outline" className="border-amber-300 bg-white text-amber-800 text-[10px]">
                      {unmappedColumns.length} عمود إضافي
                    </Badge>
                  </div>
                  <p className="text-[11px] text-amber-800 leading-relaxed">
                    أي عمود يترك دون ربط أو يتم تجاهله، ولديه بيانات في صف المسافر، سيقوم النظام تلقائياً بجمع بياناته في حقل 
                    <span className="font-mono font-bold text-amber-950 bg-amber-100/90 px-1.5 py-0.5 rounded mx-1">بيانات إضافية</span>
                    بصيغة: <span className="font-mono font-bold text-amber-950">[اسم العمود / القيمة]</span> ليسهل عليك مراجعتها وتعديلها لاحقاً.
                  </p>
                </div>
              </div>

              {/* Column Mapping Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {excelColumns.map((colName, index) => {
                  const currentSelected = columnMapping[colName] || '';
                  const sampleValue = excelData[0]?.[colName] ?? '-';
                  const isMapped = Boolean(currentSelected);

                  return (
                    <div
                      key={colName}
                      className={`p-3 rounded-xl border transition-all ${
                        isMapped
                          ? 'bg-white border-slate-200 shadow-2xs hover:border-slate-300'
                          : 'bg-slate-50/70 border-dashed border-slate-200 text-slate-400'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2 overflow-hidden">
                          <span className="font-mono text-[10px] text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                            {index + 1}
                          </span>
                          <strong className="text-xs text-slate-800 truncate" title={colName}>
                            {colName}
                          </strong>
                        </div>
                        {isMapped ? (
                          <span className="text-[10px] text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                            <Check className="h-2.5 w-2.5" />
                            مرتبط
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
                            تم التجاهل
                          </span>
                        )}
                      </div>

                      <div className="text-[11px] text-slate-500 mb-2 truncate bg-slate-50 p-1.5 rounded border border-slate-100">
                        <span className="text-slate-400 font-normal">عينة من الملف: </span>
                        <span className="font-semibold text-slate-700">{String(sampleValue)}</span>
                      </div>

                      <div>
                        <Select
                          value={currentSelected || 'IGNORE'}
                          onValueChange={(val) => handleMappingChange(colName, val)}
                        >
                          <SelectTrigger className={`h-8 text-xs bg-white ${isMapped ? 'border-emerald-300 text-slate-900 font-semibold' : 'border-slate-200 text-slate-500'}`}>
                            <SelectValue placeholder="اختر الحقل المقابل في النظام" />
                          </SelectTrigger>
                          <SelectContent className="max-h-72">
                            <SelectItem value="IGNORE" className="text-slate-400 italic">
                              -- تجاهل هذا العمود وعدم استيراده --
                            </SelectItem>
                            
                            {/* Grouped Options */}
                            {['أساسي', 'تواريخ ووثائق', 'حركات ومنافذ', 'أجانب وإقامات', 'تأشيرات', 'زواج وجنسية', 'أمني ولجوء'].map((group) => {
                              const groupFields = KNOWN_SYSTEM_FIELDS.filter(f => f.categoryGroup === group);
                              if (groupFields.length === 0) return null;

                              return (
                                <React.Fragment key={group}>
                                  <div className="px-2 py-1 text-[10px] font-bold text-slate-400 bg-slate-100/80 my-1 rounded">
                                    {group}
                                  </div>
                                  {groupFields.map(f => (
                                    <SelectItem key={f.fieldKey} value={f.fieldKey} className="text-xs">
                                      <div className="flex items-center justify-between w-full gap-2">
                                        <span>{f.label}</span>
                                        <span className="text-[10px] font-mono text-slate-400">({f.fieldKey})</span>
                                      </div>
                                    </SelectItem>
                                  ))}
                                </React.Fragment>
                              );
                            })}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* Preview Step */
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <FileSearch className="h-4 w-4 text-emerald-600" />
                  <span>معاينة حية لأول 5 سجلات بعد المعالجة والتصنيف الذكي</span>
                </h3>
                <span className="text-[11px] text-slate-500">
                  تأكد من صحة توزيع الحقول قبل الإدراج النهائي في قاعدة البيانات
                </span>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-x-auto bg-white">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-100/70 border-b border-slate-200 text-slate-700">
                    <tr>
                      <th className="p-2.5">#</th>
                      <th className="p-2.5">الاسم الكامل</th>
                      <th className="p-2.5">رقم الوثيقة/الجواز</th>
                      <th className="p-2.5">الجنسية</th>
                      <th className="p-2.5">نوع الحركة</th>
                      <th className="p-2.5">المنفذ</th>
                      <th className="p-2.5">المباينة الأمنية</th>
                      <th className="p-2.5">التصنيف والتبويب المتوقع</th>
                      <th className="p-2.5 min-w-[200px]">البيانات الإضافية المجمعة (الفائضة)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {processedPreview.map((row, idx) => {
                      const name = row.fullName || [row.firstName, row.secondName, row.thirdName, row.lastName].filter(Boolean).join(' ') || '-';
                      const isNonYem = row.country && !row.country.includes('يمن');
                      const moveType = row.movementType || (targetCategory === 'entry' ? 'دخول' : targetCategory === 'exit' ? 'خروج' : 'عام');

                      return (
                        <tr key={idx} className="hover:bg-slate-50/50">
                          <td className="p-2.5 font-mono text-slate-400">{idx + 1}</td>
                          <td className="p-2.5 font-bold text-slate-900">{name}</td>
                          <td className="p-2.5 font-mono text-slate-700">{row.idNumber || '-'}</td>
                          <td className="p-2.5">
                            <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${isNonYem ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'}`}>
                              {row.country || 'اليمن'}
                            </span>
                          </td>
                          <td className="p-2.5">
                            <span className={`px-2 py-0.5 rounded text-[11px] ${moveType === 'دخول' ? 'bg-teal-100 text-teal-800' : moveType === 'خروج' ? 'bg-indigo-100 text-indigo-800' : 'bg-slate-100 text-slate-700'}`}>
                              {moveType}
                            </span>
                          </td>
                          <td className="p-2.5 text-slate-600">{row.entryPort || row.exitPort || 'الوديعة'}</td>
                          <td className="p-2.5 font-semibold text-slate-700">{row.vettingResult || 'سليم أمنياً'}</td>
                          <td className="p-2.5">
                            <div className="flex flex-wrap gap-1">
                              <span className="bg-blue-50 text-blue-700 border border-blue-200 text-[10px] px-1.5 py-0.5 rounded">
                                المسافرين
                              </span>
                              {isNonYem && (
                                <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] px-1.5 py-0.5 rounded">
                                  الأجانب
                                </span>
                              )}
                              {moveType === 'دخول' && (
                                <span className="bg-teal-50 text-teal-700 border border-teal-200 text-[10px] px-1.5 py-0.5 rounded">
                                  الدخول
                                </span>
                              )}
                              {moveType === 'خروج' && (
                                <span className="bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] px-1.5 py-0.5 rounded">
                                  الخروج
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-2.5">
                            {row.additionalData ? (
                              <div className="space-y-1">
                                {row.additionalData.split('\n').slice(0, 2).map((item: string, iIdx: number) => (
                                  <span key={iIdx} className="block text-[10px] font-mono bg-amber-50 text-amber-900 border border-amber-200/80 px-1.5 py-0.5 rounded truncate" title={item}>
                                    {item}
                                  </span>
                                ))}
                                {row.additionalData.split('\n').length > 2 && (
                                  <span className="text-[10px] text-amber-700 font-bold block">
                                    +{row.additionalData.split('\n').length - 2} حقول إضافية أخرى
                                  </span>
                                )}
                              </div>
                            ) : (
                              <span className="text-slate-400 text-[10px]">- لا توجد حقول فائضة -</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-600 flex items-center gap-2">
            <span className="font-bold">إجمالي السجلات الجاهزة للاستيراد:</span>
            <span className="bg-slate-200 text-slate-800 font-mono font-bold px-2 py-0.5 rounded">
              {excelData.length} سجل
            </span>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
            <Button variant="outline" size="sm" onClick={onClose} className="text-xs">
              إلغاء الأمر
            </Button>
            <Button
              size="sm"
              onClick={handleExecuteImport}
              className="bg-primary hover:bg-primary/90 text-white font-bold text-xs gap-2 px-5 shadow-sm"
            >
              <Check className="h-4 w-4" />
              تأكيد الاستيراد ونقل البيانات تلقائياً ({excelData.length})
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
