import { BrowserRouter as Router, Routes, Route, Link, useLocation, Navigate, useNavigate } from 'react-router-dom';
import { 
  Users, FileText, BarChart3, ShieldCheck, LogOut, Truck, Settings as SettingsIcon, 
  Menu, X, Bell, User as UserIcon, LogIn, ChevronRight, Home, Search as SearchIcon, 
  Globe, Calendar, AlertCircle, AlertTriangle, HeartHandshake, CreditCard, FileCheck,
  Heart, Award, UserPlus, ShieldAlert
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import Travelers from './pages/Travelers';
import Reports from './pages/Reports';
import Statistics from './pages/Statistics';
import Movements from './pages/Movements';
import Settings from './pages/Settings';
import Login from './pages/Login';
import { Toaster } from './components/ui/sonner';
import { getCurrentUser, setCurrentUser, getReports, getTravelers, checkTravelerExpirations } from './lib/storage';
import { useEffect, useState } from 'react';
import { Button } from './components/ui/button';

import { OfflineBanner, OfflineStatusBadge } from './components/OfflineIndicator';
import { PWAInstallButton } from './components/PWAInstallButton';

const Layout = ({ children }: { children: React.ReactNode }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [globalSearch, setGlobalSearch] = useState('');
  const [newReportsCount, setNewReportsCount] = useState(0);
  const [expiringDocsCount, setExpiringDocsCount] = useState(0);
  const location = useLocation();
  const navigate = useNavigate();
  const user = getCurrentUser();

  const handleGlobalSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (globalSearch.trim()) {
      navigate(`/?search=${encodeURIComponent(globalSearch)}`);
      setGlobalSearch('');
    }
  };

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Monitor new security reports & expiring documents
  useEffect(() => {
    const checkState = () => {
      try {
        const allReports = getReports();
        const unhandled = allReports.filter(r => r.status === 'جديد' || r.type === 'أمني');
        setNewReportsCount(unhandled.length);

        const allTravelers = getTravelers();
        const expiring = allTravelers.filter(t => checkTravelerExpirations(t).hasAlert);
        setExpiringDocsCount(expiring.length);
      } catch (err) {
        console.error(err);
      }
    };

    checkState();
    const interval = setInterval(checkState, 4000);
    window.addEventListener('storage', checkState);
    window.addEventListener('offline-sync-queue-updated', checkState);

    return () => {
      clearInterval(interval);
      window.removeEventListener('storage', checkState);
      window.removeEventListener('offline-sync-queue-updated', checkState);
    };
  }, []);

  const [travelersMenuOpen, setTravelersMenuOpen] = useState(true);
  const searchParams = new URLSearchParams(location.search);
  const currentTab = searchParams.get('tab') || 'traveler';

  const travelerSubItems = [
    { tab: 'traveler', label: 'المسافرين (كافة السجلات)', icon: Users },
    { tab: 'foreigner', label: 'الأجانب (قاعدة غير اليمنيين)', icon: Globe },
    { tab: 'entry', label: 'حركة الدخول (قادمون)', icon: LogIn },
    { tab: 'exit', label: 'حركة الخروج (مغادرون)', icon: LogOut },
    { tab: 'visa_renewal', label: 'التأشيرات (إصدار وتجديد)', icon: FileCheck },
    { tab: 'residency_renewal', label: 'الإقامات (إصدار وتجديد)', icon: CreditCard },
    { tab: 'marriage_yemeni_woman', label: 'طلب زواج بيمنية', icon: Heart },
    { tab: 'marriage_foreigner', label: 'طلب زواج بأجنبي', icon: HeartHandshake },
    { tab: 'citizenship_application', label: 'طالب جنسية يمنية', icon: Award },
    { tab: 'refugee', label: 'اللاجئين (UNHCR)', icon: UserPlus },
    { tab: 'illegal_immigrant', label: 'المهاجرين غير الشرعيين', icon: AlertTriangle },
    { tab: 'expiring', label: 'تنبيهات الانتهاء (أسبوع فأقل)', icon: ShieldAlert, badge: expiringDocsCount },
  ];

  const handleLogout = () => {
    setCurrentUser(null);
    navigate('/login');
  };

  const getPageTitle = () => {
    if (location.pathname === '/' || location.pathname.startsWith('/travelers')) {
      const foundSub = travelerSubItems.find(s => s.tab === currentTab);
      return foundSub ? `المنافذ · ${foundSub.label}` : 'المسافرين';
    }
    if (location.pathname === '/movements') return 'حركة الأطقم';
    if (location.pathname === '/reports') return 'بلاغات الضبط';
    if (location.pathname === '/statistics') return 'الإحصائيات';
    if (location.pathname === '/settings') return 'الإعدادات والمستخدمين';
    return 'الرئيسية';
  };

  const currentLabel = getPageTitle();

  return (
    <div className="flex flex-col h-screen bg-[#F8FAFC] overflow-hidden text-[#1E293B]" dir="rtl">
      {/* Visual Emergency Flash Banner if new security reports exist */}
      {newReportsCount > 0 && (
        <aside 
          aria-label="تنبيهات البلاغات الأمنية"
          className="bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white text-xs px-4 py-1.5 flex items-center justify-between shadow-md z-50 animate-in fade-in"
        >
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-white" />
            </span>
            <AlertTriangle className="h-4 w-4 text-amber-200" />
            <span>
              <strong>تنبيه أمني عاجل:</strong> يوجد <strong>{newReportsCount}</strong> بلاغ ضبط جديد يتطلب الفحص والتدقيق فوراً!
            </span>
          </div>
          <Link 
            to="/reports" 
            className="text-[11px] font-bold bg-white/20 hover:bg-white/30 text-white px-2.5 py-0.5 rounded-full transition-colors flex items-center gap-1"
          >
            <span>معاينة البلاغات</span>
            <ChevronRight className="h-3 w-3 rotate-180" />
          </Link>
        </aside>
      )}

      {/* Offline Alert Banner */}
      <OfflineBanner />

      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Sidebar */}
        <AnimatePresence mode="wait">
          {isSidebarOpen && (
            <motion.aside
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 290, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="bg-primary text-white flex flex-col z-50 relative shadow-2xl overflow-hidden shrink-0"
            >
              <div className="p-5 flex items-center justify-between border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="bg-accent p-2 rounded-xl shadow-lg">
                    <ShieldCheck className="h-6 w-6 text-accent-foreground" />
                  </div>
                  <div className="font-bold leading-tight">
                    <p className="text-base tracking-wide">نظام المنافذ</p>
                    <p className="text-[10px] uppercase opacity-70 tracking-widest">والجوازات الذكي</p>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-white hover:bg-white/10 lg:hidden"
                  onClick={() => setIsSidebarOpen(false)}
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
              
              <nav className="flex-1 p-3.5 space-y-1 mt-1 overflow-y-auto">
                {/* 1. Travelers Group with Sub-tabs */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <Link
                      to="/"
                      className={`flex-1 flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-all duration-200 ${
                        location.pathname === '/' || location.pathname.startsWith('/travelers')
                          ? 'bg-accent/30 text-white font-bold'
                          : 'hover:bg-white/5 opacity-80 hover:opacity-100'
                      }`}
                    >
                      <Users className="h-4.5 w-4.5 text-accent" />
                      <span className="text-sm">المسافرين والشؤون</span>
                    </Link>
                    <button 
                      onClick={() => setTravelersMenuOpen(!travelersMenuOpen)}
                      className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                      title="طي أو فتح الأقسام الفرعية"
                    >
                      <ChevronRight className={`h-3.5 w-3.5 transition-transform duration-200 ${travelersMenuOpen ? 'rotate-90' : ''}`} />
                    </button>
                  </div>

                  {/* Sub-items list */}
                  {travelersMenuOpen && (
                    <div className="pr-3 mr-2 space-y-0.5 border-r border-white/15 my-1 animate-in fade-in duration-200 max-h-[380px] overflow-y-auto">
                      {travelerSubItems.map((sub) => {
                        const SubIcon = sub.icon;
                        const isSubActive = (location.pathname === '/' || location.pathname.startsWith('/travelers')) && currentTab === sub.tab;
                        const hasBadge = Boolean(sub.badge && sub.badge > 0);

                        return (
                          <Link
                            key={sub.tab}
                            to={sub.tab === 'traveler' ? '/' : `/?tab=${sub.tab}`}
                            className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs transition-all ${
                              isSubActive
                                ? 'bg-accent text-accent-foreground font-bold shadow-xs'
                                : 'text-white/70 hover:text-white hover:bg-white/5 font-medium'
                            }`}
                          >
                            <div className="flex items-center gap-2 truncate">
                              <SubIcon className={`h-3.5 w-3.5 shrink-0 ${isSubActive ? 'text-accent-foreground' : 'text-white/60'}`} />
                              <span className="truncate">{sub.label}</span>
                            </div>
                            {hasBadge && (
                              <span className="bg-red-500 text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full font-mono animate-pulse">
                                {sub.badge}
                              </span>
                            )}
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* 2. Movements */}
                <Link
                  to="/movements"
                  className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-all duration-200 ${
                    location.pathname === '/movements'
                      ? 'bg-accent text-accent-foreground shadow-lg font-bold'
                      : 'hover:bg-white/5 opacity-80 hover:opacity-100'
                  }`}
                >
                  <Truck className="h-4.5 w-4.5" />
                  <span className="text-sm">حركة الأطقم</span>
                </Link>

                {/* 3. Reports */}
                <Link
                  to="/reports"
                  className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all duration-200 ${
                    location.pathname === '/reports'
                      ? 'bg-accent text-accent-foreground shadow-lg font-bold'
                      : newReportsCount > 0
                      ? 'bg-red-500/20 text-red-100 border border-red-500/40 emergency-pulse font-medium'
                      : 'hover:bg-white/5 opacity-80 hover:opacity-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <FileText className={`h-4.5 w-4.5 ${newReportsCount > 0 ? 'text-red-400 animate-bounce' : ''}`} />
                    <span className="text-sm">بلاغات الضبط</span>
                  </div>
                  {newReportsCount > 0 && (
                    <span className="bg-red-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-md font-mono">
                      {newReportsCount} جديد
                    </span>
                  )}
                </Link>

                {/* 4. Statistics */}
                <Link
                  to="/statistics"
                  className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-all duration-200 ${
                    location.pathname === '/statistics'
                      ? 'bg-accent text-accent-foreground shadow-lg font-bold'
                      : 'hover:bg-white/5 opacity-80 hover:opacity-100'
                  }`}
                >
                  <BarChart3 className="h-4.5 w-4.5" />
                  <span className="text-sm">الإحصائيات</span>
                </Link>

                {/* 5. Settings */}
                <Link
                  to="/settings"
                  className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-all duration-200 ${
                    location.pathname === '/settings'
                      ? 'bg-accent text-accent-foreground shadow-lg font-bold'
                      : 'hover:bg-white/5 opacity-80 hover:opacity-100'
                  }`}
                >
                  <SettingsIcon className="h-4.5 w-4.5" />
                  <span className="text-sm">الإعدادات والمستخدمين</span>
                </Link>
              </nav>

              <div className="p-4 mt-auto">
                <div className="bg-white/5 rounded-2xl p-4 mb-2 border border-white/10">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="bg-accent/20 h-10 w-10 rounded-full flex items-center justify-center">
                      <UserIcon className="h-5 w-5 text-accent" />
                    </div>
                    <div className="flex-1 overflow-hidden">
                      <p className="text-sm font-bold truncate">{user?.name}</p>
                      <p className="text-[10px] opacity-60 uppercase">{user?.role}</p>
                    </div>
                  </div>
                  <button 
                    onClick={handleLogout}
                    className="flex items-center justify-center gap-2 w-full py-2 rounded-xl bg-destructive/10 text-destructive-foreground hover:bg-destructive/20 transition-colors text-xs font-bold"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>تسجيل الخروج</span>
                  </button>
                </div>
                <div className="text-center">
                  <p className="text-[10px] opacity-40 font-mono">v1.3.0 · OFFLINE BIOMETRIC MODE</p>
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>


        {/* Content Area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Top Navbar */}
          <header className="h-20 bg-white border-b border-slate-200 flex items-center justify-between px-6 z-40 sticky top-0 shadow-sm">
            <div className="flex items-center gap-4 sm:gap-6">
              {!isSidebarOpen && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setIsSidebarOpen(true)}
                  className="hover:bg-slate-100"
                >
                  <Menu className="h-6 w-6 text-slate-600" />
                </Button>
              )}
              <div className="flex flex-col">
                <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
                  <Home className="h-3 w-3" />
                  <span>الرئيسية</span>
                  <ChevronRight className="h-3 w-3" />
                  <span className="text-primary font-medium">{currentLabel}</span>
                </div>
                <h2 className="text-xl font-bold text-slate-800">{currentLabel}</h2>
              </div>
            </div>

            <div className="flex items-center gap-3 sm:gap-4">
              {/* Document Expiration Warning Quick Action */}
              {expiringDocsCount > 0 && (
                <Link
                  to="/?tab=expiring"
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 hover:bg-red-100 border border-red-300 text-red-700 rounded-full text-xs font-bold transition-all shadow-xs animate-in fade-in"
                  title="تنبيه: يوجد وثائق تنتهي خلال أسبوع أو منتهية"
                >
                  <ShieldAlert className="h-4 w-4 text-red-600 animate-pulse" />
                  <span className="hidden sm:inline">انتهاء الوثائق:</span>
                  <span className="bg-red-600 text-white text-[10px] px-1.5 py-0.2 rounded-full font-mono font-black">
                    {expiringDocsCount}
                  </span>
                </Link>
              )}

              {/* PWA Install Button */}
              <PWAInstallButton />

              {/* Real-time Offline / Sync Badge */}
              <OfflineStatusBadge />

              <form onSubmit={handleGlobalSearch} className="hidden xl:flex items-center gap-2 bg-slate-50 border border-slate-200 px-4 py-1.5 rounded-full text-slate-500 focus-within:ring-2 focus-within:ring-primary/20 transition-all">
                <SearchIcon className="h-4 w-4" />
                <input 
                  type="text" 
                  placeholder="بحث شامل عن مسافر، بلاغ، أو رقم..." 
                  className="bg-transparent border-none outline-none text-xs w-64 text-right font-medium" 
                  value={globalSearch}
                  onChange={(e) => setGlobalSearch(e.target.value)}
                />
              </form>

              <div className="hidden lg:flex items-center gap-4 border-l pl-4 ml-2">
                <div className="flex flex-col items-end">
                  <p className="text-sm font-bold text-slate-700 font-mono">
                    {currentTime.toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </p>
                  <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-medium">
                    <Calendar className="h-3 w-3" />
                    <span>{currentTime.toLocaleDateString('ar-YE', { weekday: 'long', day: 'numeric', month: 'long' })}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="relative text-slate-500 hover:bg-slate-100 rounded-full">
                      <Bell className={`h-5 w-5 ${newReportsCount > 0 || expiringDocsCount > 0 ? 'text-red-500 animate-pulse' : ''}`} />
                      {(newReportsCount > 0 || expiringDocsCount > 0) ? (
                        <span className="absolute top-1 right-1 flex h-4 w-4">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                          <span className="relative inline-flex rounded-full h-4 w-4 bg-red-600 text-[10px] text-white font-bold items-center justify-center font-mono">
                            {newReportsCount + expiringDocsCount}
                          </span>
                        </span>
                      ) : (
                        <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-slate-300 rounded-full border-2 border-white"></span>
                      )}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-80" dir="rtl">
                    <DropdownMenuLabel className="flex items-center justify-between">
                      <span className="font-bold">التنبيهات والإشعارات الفورية</span>
                      {(newReportsCount > 0 || expiringDocsCount > 0) && (
                        <span className="bg-red-500/10 text-red-600 text-xs px-2 py-0.5 rounded-full font-bold">
                          {newReportsCount + expiringDocsCount} تنبيه
                        </span>
                      )}
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />

                    {/* Expiration item */}
                    {expiringDocsCount > 0 && (
                      <div className="p-3 text-xs bg-red-50/60 border-b border-red-100 space-y-1.5">
                        <div className="flex items-start gap-2 text-red-700 font-bold">
                          <ShieldAlert className="h-4 w-4 mt-0.5 shrink-0" />
                          <p>يوجد {expiringDocsCount} سجلات بإقامات أو تأشيرات أو جوازات تنتهي خلال أسبوع أو منتهية.</p>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full text-xs h-7 text-red-700 border-red-300 hover:bg-red-100"
                          onClick={() => navigate('/?tab=expiring')}
                        >
                          معاينة تنبيهات الانتهاء
                        </Button>
                      </div>
                    )}

                    {/* Security Reports item */}
                    {newReportsCount > 0 ? (
                      <div className="p-3 text-xs space-y-2">
                        <div className="flex items-start gap-2 text-destructive font-medium">
                          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                          <p>تنبيه طارئ: يوجد {newReportsCount} بلاغ ضبط جديد بانتظار الفحص والتدقيق فوراً.</p>
                        </div>
                        <Button
                          size="sm"
                          variant="destructive"
                          className="w-full text-xs h-8 mt-1 gap-1"
                          onClick={() => navigate('/reports')}
                        >
                          <FileText className="h-3.5 w-3.5" />
                          معاينة بلاغات الضبط الآن
                        </Button>
                      </div>
                    ) : expiringDocsCount === 0 ? (
                      <div className="p-4 text-center text-xs text-muted-foreground">
                        لا توجد بلاغات أو تنبيهات طارئة حالياً.
                      </div>
                    ) : null}
                  </DropdownMenuContent>
                </DropdownMenu>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="p-1 pr-3 hover:bg-slate-100 rounded-full flex items-center gap-3">
                      <div className="text-right hidden sm:block">
                        <p className="text-xs font-bold text-slate-700">{user?.name}</p>
                        <p className="text-[10px] text-slate-400 uppercase">{user?.role}</p>
                      </div>
                      <div className="h-8 w-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center overflow-hidden">
                        <UserIcon className="h-4 w-4 text-slate-600" />
                      </div>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56" dir="rtl">
                    <DropdownMenuLabel>حسابي</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => navigate('/settings')}>
                      <SettingsIcon className="h-4 w-4 ml-2" />
                      <span>الإعدادات والمستخدمين</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                      <LogOut className="h-4 w-4 ml-2" />
                      <span>تسجيل الخروج</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </header>

          {/* Page Content */}
          <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-[#F8FAFC]">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
};

export function App() {
  const [currentUser, setCurrentUserState] = useState(getCurrentUser());

  useEffect(() => {
    const handleStorage = () => {
      setCurrentUserState(getCurrentUser());
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
    if (!currentUser) {
      return <Navigate to="/login" replace />;
    }
    return <Layout>{children}</Layout>;
  };

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login onLoginSuccess={() => setCurrentUserState(getCurrentUser())} />} />
        
        <Route path="/" element={
          <ProtectedRoute>
            <Travelers />
          </ProtectedRoute>
        } />
        
        <Route path="/travelers" element={
          <ProtectedRoute>
            <Travelers />
          </ProtectedRoute>
        } />

        <Route path="/movements" element={
          <ProtectedRoute>
            <Movements />
          </ProtectedRoute>
        } />

        <Route path="/reports" element={
          <ProtectedRoute>
            <Reports />
          </ProtectedRoute>
        } />

        <Route path="/statistics" element={
          <ProtectedRoute>
            <Statistics />
          </ProtectedRoute>
        } />

        <Route path="/settings" element={
          <ProtectedRoute>
            <Settings />
          </ProtectedRoute>
        } />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <Toaster position="top-center" richColors />
    </Router>
  );
}

export default App;
