import { Traveler, Report, Movement, User, TravelerCategory } from './types';
import { queueOfflineAction } from './offlineSync';

export const generateId = () => Math.random().toString(36).substr(2, 9);

export const normalizeArabic = (text: string) => {
  if (!text) return '';
  return text
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .trim();
};

export const formatTravelerFullName = (t: Partial<Traveler>): string => {
  if (t.fullName && t.fullName.trim()) return t.fullName.trim();
  const parts = [t.firstName, t.secondName, t.thirdName, t.fourthName, t.lastName].filter(Boolean);
  return parts.join(' ').trim();
};

/**
 * Checks if a nationality is considered Non-Yemeni (Foreigner).
 */
export const isNonYemeni = (country?: string): boolean => {
  if (!country) return false;
  const normalized = normalizeArabic(country).toLowerCase();
  const yemeniVariants = ['اليمن', 'يمن', 'يمني', 'يمنيه', 'الجمهوريه اليمنيه', 'yemen', 'yemeni'];
  return !yemeniVariants.includes(normalized);
};

/**
 * Calculates days remaining until a specific date from today.
 * Returns negative if expired, 0 if today, positive if in the future.
 */
export const getDaysUntil = (dateStr?: string): number | null => {
  if (!dateStr || !dateStr.trim()) return null;
  const target = new Date(dateStr);
  if (isNaN(target.getTime())) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  target.setHours(0, 0, 0, 0);
  const diffTime = target.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

export interface ExpiryAlertItem {
  type: 'residency' | 'visa' | 'passport';
  label: string;
  days: number;
  status: 'expired' | 'urgent_week';
  date: string;
  badgeText: string;
  badgeClass: string;
}

/**
 * Evaluates document expiration for a single traveler (<= 7 days or expired)
 */
export const checkTravelerExpirations = (t: Traveler): {
  hasAlert: boolean;
  alerts: ExpiryAlertItem[];
} => {
  const alerts: ExpiryAlertItem[] = [];

  // 1. Residency expiration
  if (t.residencyExpiryDate) {
    const days = getDaysUntil(t.residencyExpiryDate);
    if (days !== null) {
      if (days < 0) {
        alerts.push({
          type: 'residency',
          label: 'الإقامة',
          days,
          status: 'expired',
          date: t.residencyExpiryDate,
          badgeText: `إقامة منتهية (${Math.abs(days)} يوم)`,
          badgeClass: 'bg-red-600 text-white animate-pulse',
        });
      } else if (days <= 7) {
        alerts.push({
          type: 'residency',
          label: 'الإقامة',
          days,
          status: 'urgent_week',
          date: t.residencyExpiryDate,
          badgeText: days === 0 ? 'إقامة تنتهي اليوم!' : `إقامة تنتهي خلال ${days} ${days === 1 ? 'يوم' : days === 2 ? 'يومين' : 'أيام'}`,
          badgeClass: 'bg-red-500 text-white font-bold',
        });
      }
    }
  }

  // 2. Visa expiration
  if (t.visaExpiryDate) {
    const days = getDaysUntil(t.visaExpiryDate);
    if (days !== null) {
      if (days < 0) {
        alerts.push({
          type: 'visa',
          label: 'التأشيرة',
          days,
          status: 'expired',
          date: t.visaExpiryDate,
          badgeText: `تأشيرة منتهية (${Math.abs(days)} يوم)`,
          badgeClass: 'bg-amber-600 text-white animate-pulse',
        });
      } else if (days <= 7) {
        alerts.push({
          type: 'visa',
          label: 'التأشيرة',
          days,
          status: 'urgent_week',
          date: t.visaExpiryDate,
          badgeText: days === 0 ? 'تأشيرة تنتهي اليوم!' : `تأشيرة تنتهي خلال ${days} ${days === 1 ? 'يوم' : days === 2 ? 'يومين' : 'أيام'}`,
          badgeClass: 'bg-amber-500 text-white font-bold',
        });
      }
    }
  }

  // 3. Passport expiration
  if (t.passportExpiryDate) {
    const days = getDaysUntil(t.passportExpiryDate);
    if (days !== null) {
      if (days < 0) {
        alerts.push({
          type: 'passport',
          label: 'جواز السفر',
          days,
          status: 'expired',
          date: t.passportExpiryDate,
          badgeText: `جواز منتهي (${Math.abs(days)} يوم)`,
          badgeClass: 'bg-rose-700 text-white',
        });
      } else if (days <= 7) {
        alerts.push({
          type: 'passport',
          label: 'جواز السفر',
          days,
          status: 'urgent_week',
          date: t.passportExpiryDate,
          badgeText: days === 0 ? 'جواز ينتهي اليوم!' : `جواز ينتهي خلال ${days} ${days === 1 ? 'يوم' : days === 2 ? 'يومين' : 'أيام'}`,
          badgeClass: 'bg-orange-500 text-white font-bold',
        });
      }
    }
  }

  return {
    hasAlert: alerts.length > 0,
    alerts,
  };
};

/**
 * Auto-classifies and synchronizes categories for any saved record.
 * Guarantees that:
 * 1. 'traveler' is always a foundation for all entries.
 * 2. If country is non-Yemeni, 'foreigner' is ALWAYS added to additionalCategories and isForeigner = true.
 * 3. Specific request categories (entry, exit, visa, residency, marriage, citizenship, etc.) are synchronized.
 */
export const sanitizeAndClassifyTraveler = (t: Partial<Traveler>): Traveler => {
  const country = t.country || 'اليمن';
  const isForeign = isNonYemeni(country) || t.isForeigner === true || t.category === 'foreigner';
  
  const categoriesSet = new Set<TravelerCategory>(t.additionalCategories || []);
  
  // Foundation: Travelers
  categoriesSet.add('traveler');
  
  // Primary category if present
  if (t.category) {
    categoriesSet.add(t.category);
  }

  // Automatic Foreigner inclusion if non-Yemeni
  if (isForeign) {
    categoriesSet.add('foreigner');
  }

  // Synchronize Movement Type
  if (t.movementType === 'دخول') {
    categoriesSet.add('entry');
  } else if (t.movementType === 'خروج') {
    categoriesSet.add('exit');
  }

  // Synchronize specific requests
  if (t.category === 'visa_renewal' || t.visaNumber || t.requestedVisaPeriod) {
    categoriesSet.add('visa_renewal');
  }
  if (t.category === 'residency_renewal' || t.residencyNumber || t.requestedResidencyPeriod) {
    categoriesSet.add('residency_renewal');
  }
  if (t.category === 'marriage_yemeni_woman' || t.spouseFullName) {
    categoriesSet.add('marriage_yemeni_woman');
  }
  if (t.category === 'marriage_foreigner' || t.foreignSpouseName) {
    categoriesSet.add('marriage_foreigner');
  }
  if (t.category === 'citizenship_application' || t.citizenshipFileNumber) {
    categoriesSet.add('citizenship_application');
  }
  if (t.category === 'refugee' || t.unhcrNumber) {
    categoriesSet.add('refugee');
  }
  if (t.category === 'illegal_immigrant' || t.interceptionPoint) {
    categoriesSet.add('illegal_immigrant');
  }

  const fullName = formatTravelerFullName(t);

  const now = new Date().toISOString();

  return {
    ...t,
    id: t.id || `t-${generateId()}`,
    category: t.category || (isForeign ? 'foreigner' : 'traveler'),
    additionalCategories: Array.from(categoriesSet),
    isForeigner: isForeign,
    fullName,
    firstName: t.firstName || fullName.split(' ')[0] || '',
    secondName: t.secondName || fullName.split(' ')[1] || '',
    thirdName: t.thirdName || fullName.split(' ')[2] || '',
    fourthName: t.fourthName || fullName.split(' ')[3] || '',
    lastName: t.lastName || fullName.split(' ').slice(4).join(' ') || '',
    age: Number(t.age) || 30,
    idNumber: t.idNumber || '',
    idType: t.idType || (isForeign ? 'جواز أجنبي' : 'جواز سفر'),
    country,
    governorate: t.governorate || '',
    phone: t.phone || '',
    destination: t.destination || 'الجمهورية اليمنية',
    visitReason: t.visitReason || '',
    investigatingOfficer: t.investigatingOfficer || 'ضابط المنافذ المناوب',
    travelAllowed: t.travelAllowed || 'نعم',
    vettingResult: t.vettingResult || 'سليم أمنياً - لا توجد قيود مسجلة',
    additionalData: t.additionalData ? String(t.additionalData).trim() : '',
    notes: t.notes || '',
    createdAt: t.createdAt || now,
    updatedAt: now,
  } as Traveler;
};

// Initial realistic dataset across all categories for offline port simulation
const getInitialTravelers = (): Traveler[] => {
  const now = new Date().toISOString();
  
  // Calculate dynamic dates for urgent 1-week alerts:
  // Today = reference date
  const today = new Date();
  
  // Expiry in 4 days (urgent 1-week alert!)
  const expIn4Days = new Date(today);
  expIn4Days.setDate(today.getDate() + 4);
  const expIn4DaysStr = expIn4Days.toISOString().split('T')[0];

  // Expiry in 6 days (urgent 1-week alert!)
  const expIn6Days = new Date(today);
  expIn6Days.setDate(today.getDate() + 6);
  const expIn6DaysStr = expIn6Days.toISOString().split('T')[0];

  // Expiry in 2 days (urgent 1-week alert!)
  const expIn2Days = new Date(today);
  expIn2Days.setDate(today.getDate() + 2);
  const expIn2DaysStr = expIn2Days.toISOString().split('T')[0];

  // Expired 5 days ago (expired alert!)
  const expired5DaysAgo = new Date(today);
  expired5DaysAgo.setDate(today.getDate() - 5);
  const expired5DaysAgoStr = expired5DaysAgo.toISOString().split('T')[0];

  const rawList: Partial<Traveler>[] = [
    // 1. حركة دخول (قادم عبر منفذ الوديعة البري) - مواطن يمني
    {
      id: 't-entry-01',
      category: 'entry',
      movementType: 'دخول',
      fullName: 'صالح أحمد علي الحميري',
      age: 38,
      idNumber: '08349201',
      idType: 'جواز سفر يمني',
      country: 'اليمن',
      governorate: 'حضرموت',
      phone: '771234567',
      passportIssueDate: '2023-01-10',
      passportExpiryDate: '2029-01-09',
      entryPort: 'منفذ الوديعة البري',
      entryDate: '2026-10-10',
      originCountry: 'المملكة العربية السعودية',
      entryCarrierOrFlight: 'باص نقل جماعي - شركة البركة (لوحة 4819)',
      entryPurpose: 'عودة للوطن بعد إجازة عمل',
      vettingResult: 'سليم أمنياً - لا توجد قيود مسجلة',
      destination: 'سيئون - حضرموت',
      visitReason: 'عودة إلى أرض الوطن',
      investigatingOfficer: 'ملازم أول/ أحمد الكندي',
      travelAllowed: 'نعم',
      center: 'منفذ الوديعة البري',
      status: 'دخول مكتمل',
    },

    // 2. حركة خروج (مغادر عبر مطار عدن الدولي) - مواطن يمني مع جواز ينتهي خلال 6 أيام! (تنبيه جواز)
    {
      id: 't-exit-01',
      category: 'exit',
      movementType: 'خروج',
      fullName: 'نجيب عبدالله قاسم المقطري',
      age: 42,
      idNumber: 'YEM-992100',
      idType: 'جواز سفر يمني',
      country: 'اليمن',
      governorate: 'عدن',
      phone: '733112233',
      passportIssueDate: '2020-10-17',
      passportExpiryDate: expIn6DaysStr, // ينتهي خلال 6 أيام! (تنبيه أسبوع)
      exitPort: 'مطار عدن الدولي',
      exitDate: '2026-10-11',
      destinationCountry: 'جمهورية مصر العربية',
      exitCarrierOrFlight: 'الخطوط الجوية اليمنية - رحلة IY601',
      exitPurpose: 'علاج وفحوصات طبية',
      exitPermitNumber: 'EX-ADE-2026-44',
      vettingResult: 'سليم أمنياً - تم إشعاره بضرورة تجديد الجواز في السفارة بالقاهرة',
      destination: 'القاهرة - مصر',
      visitReason: 'فحوصات طبية عاجلة',
      investigatingOfficer: 'نقيب/ عادل الشعيبي',
      travelAllowed: 'نعم',
      center: 'مطار عدن الدولي',
      status: 'مغادر',
    },

    // 3. أجنبي + حركة دخول + إقامة تنتهي بعد 4 أيام! (تنبيه إقامة أسبوع فقط)
    {
      id: 't-for-01',
      category: 'foreigner',
      movementType: 'دخول',
      fullName: 'طارق حسام الدين الدسوقي',
      age: 46,
      idNumber: 'EG5541092',
      idType: 'جواز سفر مصري',
      country: 'مصر',
      governorate: 'المهرة',
      phone: '711223344',
      passportIssueDate: '2022-02-12',
      passportExpiryDate: '2029-02-11',
      residencyNumber: 'IQ-2025-44910',
      residencyIssueDate: '2025-10-15',
      residencyExpiryDate: expIn4DaysStr, // تنتهي خلال 4 أيام فقط!
      profession: 'أخصائي جراحة عامة',
      employerName: 'مستشفى الغيضة المركزي',
      sponsorName: 'وزارة الصحة العامة والسكان',
      sponsorPhone: '771998822',
      entryPort: 'منفذ شحن البري',
      entryDate: '2026-10-09',
      originCountry: 'سلطنة عمان',
      entryCarrierOrFlight: 'سيارة خاصة (لوحة عمانية 83921)',
      entryPurpose: 'عمل - التحاق بالمستشفى',
      vettingResult: 'طبيب معتمد - مطلوب مراجعة شؤون الإقامة للتجديد قبل 4 أيام',
      destination: 'محافظة المهرة',
      visitReason: 'التحاق بالعمل الطبي',
      investigatingOfficer: 'عقيد/ عمر الكثيري',
      travelAllowed: 'نعم',
      center: 'منفذ شحن البري',
      status: 'دخول - مطلوب تجديد الإقامة فوراً',
    },

    // 4. أجنبي + طلب وتجديد تأشيرة + تأشيرة تنتهي بعد يومين! (تنبيه تأشيرة أسبوع)
    {
      id: 't-visa-01',
      category: 'visa_renewal',
      movementType: 'عام',
      fullName: 'راجيف كومار شارما',
      age: 40,
      idNumber: 'IN8834190',
      idType: 'جواز سفر هندي',
      country: 'الهند',
      governorate: 'حضرموت',
      phone: '772334455',
      passportIssueDate: '2021-08-10',
      passportExpiryDate: '2031-08-09',
      visaIssueDate: '2026-04-13',
      visaExpiryDate: expIn2DaysStr, // تنتهي خلال يومين!
      visaNumber: 'V-EXT-2026-094',
      requestedVisaPeriod: '6 أشهر إضافية',
      visaExtensionReason: 'استكمال مشروع البنية التحتية لشبكات الاتصالات',
      sponsorName: 'مؤسسة الوادي للمقاولات العامة',
      sponsorPhone: '777123987',
      visaFeeStatus: 'مسدد',
      visaReceiptNumber: 'RC-99812-2026',
      visaRequestStatus: 'قيد المراجعة',
      vettingResult: 'مستوفي اشتراطات التجديد - قيد الفحص الأمني النهائي',
      destination: 'سيئون - حضرموت',
      visitReason: 'تجديد تأشيرة فني متخصص',
      investigatingOfficer: 'ملازم أول/ ياسر النهدي',
      travelAllowed: 'نعم',
      center: 'فرع مصلحة الهجرة والجوازات - سيئون',
      status: 'طلب تجديد تأشيرة قيد المعالجة',
    },

    // 5. أجنبي + طلب زواج بيمنية (مستوفي الشروط وخاضع للتدقيق الأمني)
    {
      id: 't-marry-01',
      category: 'marriage_yemeni_woman',
      movementType: 'عام',
      fullName: 'أحمد محمود فؤاد الشربيني',
      age: 33,
      idNumber: 'EG-MAR-77312',
      idType: 'جواز سفر مصري',
      country: 'مصر',
      governorate: 'عدن',
      phone: '775566778',
      passportIssueDate: '2023-05-10',
      passportExpiryDate: '2030-05-09',
      residencyIssueDate: '2025-01-10',
      residencyExpiryDate: '2027-01-09',
      residencyNumber: 'IQ-MAR-2025-01',
      spouseFullName: 'فاطمة محمد ناصر المنصوري',
      spouseIdNumber: '0201994821',
      marriageContractNumber: 'CR-MAR-YEM-8821',
      marriageContractDate: '2026-09-15',
      courtOrAuthority: 'محكمة صيرة الابتدائية الشرعية - عدن',
      marriageApprovalStatus: 'موافقة أمنية معتمدة',
      marriageGuardianName: 'محمد ناصر المنصوري (والد الزوجة)',
      sponsorName: 'مجموعة الأمل التجارية - عدن',
      sponsorPhone: '771228844',
      vettingResult: 'شهادة خلو سوابق مصدقة + فحص جيني وطبي سليم + موافقة ولي الأمر',
      destination: 'عدن - المنصورة',
      visitReason: 'معاملة توثيق زواج أجنبي من مواطنة يمنية',
      investigatingOfficer: 'مقدم/ وجدي الصبيحي',
      travelAllowed: 'نعم',
      center: 'إدارة الهجرة والجوازات والجنسية - عدن',
      status: 'معتمد رسمياً',
    },

    // 6. مواطن يمني + طلب زواج بأجنبية
    {
      id: 't-marry-02',
      category: 'marriage_foreigner',
      movementType: 'عام',
      fullName: 'خالد عبدالباسط محمد الحكيمي',
      age: 29,
      idNumber: 'YEM-ID-033918',
      idType: 'بطاقة شخصية ذكية',
      country: 'اليمن',
      governorate: 'تعز',
      phone: '733994411',
      passportIssueDate: '2024-03-01',
      passportExpiryDate: '2030-03-01',
      foreignSpouseName: 'سارة إليزابيث جونسون',
      foreignSpouseNationality: 'المملكة المتحدة',
      foreignSpousePassport: 'GB-9921470',
      foreignMarriageApprovalNumber: 'MOI-YEM-FRG-2026-302',
      marriageApprovalStatus: 'قيد الدراسة والتحري',
      vettingResult: 'مقدم أوراق الفحص الطبي والسفارة البريطانية - قيد مراجعة المباحث الجنائية',
      destination: 'تعز / صنعاء',
      visitReason: 'طلب تصريح زواج مواطن يمني من أجنبية',
      investigatingOfficer: 'رائد/ نبيل الصلوي',
      travelAllowed: 'نعم',
      center: 'ديوان مصلحة الهجرة والجوازات',
      status: 'قيد التحري والدراسة',
    },

    // 7. أجنبي + طالب جنسية يمنية (مقيم منذ 16 عاماً)
    {
      id: 't-cit-01',
      category: 'citizenship_application',
      movementType: 'عام',
      fullName: 'بشير عدنان سليم كحالة',
      age: 51,
      idNumber: 'SY-PAS-88120',
      idType: 'جواز سفر سوري',
      country: 'سوريا',
      governorate: 'صنعاء',
      phone: '777334411',
      passportIssueDate: '2021-06-01',
      passportExpiryDate: '2028-06-01',
      residencyIssueDate: '2023-01-01',
      residencyExpiryDate: '2028-01-01',
      residencyNumber: 'IQ-SYR-09821',
      citizenshipFileNumber: 'CIT-NAT-2026-118',
      citizenshipApplicationDate: '2026-02-10',
      residenceYearsInYemen: 16,
      citizenshipReason: 'إقامة طويلة مستمرة',
      citizenshipStatus: 'استيفاء الشروط القانونية',
      profession: 'مهندس اتصالات ومدير مشاريع',
      employerName: 'شركة يمن تكنولوجي',
      vettingResult: 'مستوفي شرط الإقامة المتصلة (16 عاماً) وحسن السيرة واللغة العربية والسلامة الأمنية',
      destination: 'صنعاء - حدة',
      visitReason: 'طلب اكتساب الجنسية اليمنية بالتجنس',
      investigatingOfficer: 'عميد/ طه المعمري',
      travelAllowed: 'نعم',
      center: 'الإدارة العامة للجنسية وشؤون الأجانب',
      status: 'مرفوع للجنة التجنس العليا',
    },

    // 8. مهاجر غير شرعي (مضبوط في البحر العربي)
    {
      id: 't-imm-01',
      category: 'illegal_immigrant',
      movementType: 'دخول',
      fullName: 'تسفاي برهان أديسو',
      age: 23,
      idNumber: 'IMM-ETH-2026-01',
      idType: 'بدون وثائق رسمية',
      country: 'إثيوبيا',
      governorate: '',
      phone: '',
      interceptionPoint: 'نقطة صحراء العبر الحدودية',
      interceptionDate: '2026-10-08',
      smugglingRoute: 'تسلل بري عبر الصحراء بسيارة دفع رباعي غير مرخصة',
      biometricsTaken: 'نعم',
      healthStatus: 'فحص أولي سليم - إرهاق وجفاف شديد',
      deportationStatus: 'محتجز',
      interceptingUnit: 'سرية حرس الحدود الأولى',
      vettingResult: 'تم مطابقة البصمة العشرية محلياً - لم يسبق إبعاده',
      destination: 'توقيف أمني تمهيداً للإبعاد',
      visitReason: 'تسلل غير شرعي',
      investigatingOfficer: 'رائد/ فهد العولقي',
      travelAllowed: 'لا',
      center: 'مركز إيواء وترحيل المنفذ',
      status: 'قيد إجراءات الترحيل',
    },

    // 9. لاجئ مسجل لدى المفوضية
    {
      id: 't-ref-01',
      category: 'refugee',
      movementType: 'عام',
      fullName: 'أبيرا هايلي جبري',
      age: 31,
      idNumber: 'SOM-REF-88902',
      idType: 'كرت لجوء أممي',
      country: 'الصومال',
      governorate: 'عدن',
      phone: '733445566',
      passportIssueDate: '2024-06-01',
      passportExpiryDate: '2027-06-01',
      unhcrNumber: 'UNHCR-YEM-2024-99120',
      refugeeStatus: 'لاجئ معترف به',
      campLocation: 'مخيم خرز للاجئين - لحج',
      aidOrganization: 'المفوضية السامية للأمم المتحدة لشؤون اللاجئين (UNHCR)',
      dependentsCount: 3,
      vettingResult: 'مسجل ومعتمد رسمياً لدى مفوضية شؤون اللاجئين',
      destination: 'انتقال داخلي مرخص للمراجعة الطبية',
      visitReason: 'تصريح مرور إنساني صادر عن المفوضية',
      investigatingOfficer: 'نقيب/ سالم باوزير',
      travelAllowed: 'نعم',
      center: 'منفذ الوديعة البري',
      status: 'مرور مصرح',
    },

    // 10. وافد مع إقامة منتهية الصلاحية (تنبيه وثيقة منتهية)
    {
      id: 't-for-expired',
      category: 'foreigner',
      movementType: 'خروج',
      fullName: 'محمد أرشد خان',
      age: 48,
      idNumber: 'PK-8910443',
      idType: 'جواز سفر باكستاني',
      country: 'باكستان',
      governorate: 'المكلا',
      phone: '772991100',
      passportIssueDate: '2021-01-10',
      passportExpiryDate: '2029-01-10',
      residencyNumber: 'IQ-PK-00912',
      residencyIssueDate: '2024-10-05',
      residencyExpiryDate: expired5DaysAgoStr, // منتهية قبل 5 أيام!
      sponsorName: 'مؤسسة الساحل للأسماك',
      sponsorPhone: '771230099',
      exitPort: 'ميناء المكلا البحري',
      exitDate: '2026-10-11',
      destinationCountry: 'باكستان',
      exitPurpose: 'خروج نهائي بعد تسوية الغرامات',
      vettingResult: 'توجيه بسداد غرامة تأخير تجديد الإقامة قبل ختم الخروج النهائي',
      destination: 'كراتشي - باكستان',
      visitReason: 'مغادرة نهائية للبلاد',
      investigatingOfficer: 'مقدم/ خالد بارشيد',
      travelAllowed: 'لا',
      center: 'ميناء المكلا البحري',
      status: 'موقوف لحين سداد غرامات التأخير',
    }
  ];

  return rawList.map(item => sanitizeAndClassifyTraveler(item));
};

export const getTravelers = (): Traveler[] => {
  const data = localStorage.getItem('travelers');
  if (!data) {
    const initial = getInitialTravelers();
    localStorage.setItem('travelers', JSON.stringify(initial));
    return initial;
  }
  try {
    const list: Traveler[] = JSON.parse(data);
    let updated = false;
    const sanitized = list.map(t => {
      const sanitizedTraveler = sanitizeAndClassifyTraveler(t);
      if (
        !t.fullName || 
        !t.additionalCategories || 
        t.additionalCategories.length !== sanitizedTraveler.additionalCategories?.length ||
        t.isForeigner !== sanitizedTraveler.isForeigner
      ) {
        updated = true;
      }
      return sanitizedTraveler;
    });
    if (updated) {
      localStorage.setItem('travelers', JSON.stringify(sanitized));
    }
    return sanitized;
  } catch (e) {
    console.error('Failed to parse travelers from localStorage', e);
    return [];
  }
};

export const saveTravelers = (travelers: Traveler[]) => {
  // Sanitize every record to ensure cross-categorization
  const sanitized = travelers.map(t => sanitizeAndClassifyTraveler(t));
  localStorage.setItem('travelers', JSON.stringify(sanitized));
  queueOfflineAction('traveler', 'update', { count: sanitized.length });
};

export const getReports = (): Report[] => {
  const data = localStorage.getItem('reports');
  return data ? JSON.parse(data) : [];
};

export const saveReports = (reports: Report[]) => {
  localStorage.setItem('reports', JSON.stringify(reports));
  queueOfflineAction('report', 'update', { count: reports.length });
};

export const getMovements = (): Movement[] => {
  const data = localStorage.getItem('movements');
  return data ? JSON.parse(data) : [];
};

export const saveMovements = (movements: Movement[]) => {
  localStorage.setItem('movements', JSON.stringify(movements));
  queueOfflineAction('movement', 'update', { count: movements.length });
};

export const getUsers = (): User[] => {
  const data = localStorage.getItem('users');
  if (!data) {
    const defaultUsers: User[] = [
      {
        id: 'u-1',
        username: 'admin',
        password: '123',
        role: 'آدمن',
        name: 'مدير المنفذ العام',
        biometricEnabled: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'u-2',
        username: 'officer1',
        password: '123',
        role: 'ضابط',
        name: 'نقيب/ سالم باوزير',
        biometricEnabled: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'u-3',
        username: 'entry1',
        password: '123',
        role: 'مدخل بيانات',
        name: 'مساعد/ فهد الكثيري',
        biometricEnabled: false,
        createdAt: new Date().toISOString(),
      }
    ];
    localStorage.setItem('users', JSON.stringify(defaultUsers));
    return defaultUsers;
  }
  try {
    return JSON.parse(data);
  } catch (e) {
    console.error('Failed to parse users', e);
    return [];
  }
};

export const saveUsers = (users: User[]) => {
  localStorage.setItem('users', JSON.stringify(users));
  queueOfflineAction('user', 'update', { count: users.length });
};

export const getCurrentUser = (): User | null => {
  const data = localStorage.getItem('currentUser');
  if (!data) {
    const users = getUsers();
    const admin = users.find(u => u.username === 'admin') || users[0] || null;
    if (admin) {
      localStorage.setItem('currentUser', JSON.stringify(admin));
      return admin;
    }
    return null;
  }
  try {
    return JSON.parse(data);
  } catch {
    return null;
  }
};

export const setCurrentUser = (user: User | null) => {
  if (user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
  } else {
    localStorage.removeItem('currentUser');
  }
  window.dispatchEvent(new Event('storage'));
};

