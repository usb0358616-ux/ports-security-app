import { saveAs } from 'file-saver';
import { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, AlignmentType, WidthType } from 'docx';
import { toPng } from 'html-to-image';
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';

import { getOfficialHeaderConfig } from '@/components/OfficialHeader';

// Fallback constant for backwards compatibility
export const OFFICIAL_HEADER = {
  get country() { return getOfficialHeaderConfig().country; },
  get ministry() { return getOfficialHeaderConfig().ministry; },
  get sector() { return getOfficialHeaderConfig().sector; },
  get branch() { return getOfficialHeaderConfig().agencyName; },
};

/**
 * Common export utilities for the application.
 */

export const exportToExcel = (data: any[], fileName: string) => {
  if (!data || data.length === 0) return;

  // Format dataset with clear Arabic keys including additionalData
  const formattedData = data.map((item, idx) => {
    const row: Record<string, any> = {
      '#': idx + 1,
      'الاسم الكامل': item.fullName || [item.firstName, item.secondName, item.thirdName, item.lastName].filter(Boolean).join(' ') || '-',
      'رقم الوثيقة': item.idNumber || '-',
      'نوع الوثيقة': item.idType || 'جواز سفر',
      'الجنسية': item.country || 'اليمن',
      'نوع الحركة': item.movementType || 'عام',
      'المنفذ': item.entryPort || item.exitPort || item.center || '-',
      'القرار الأمني': item.travelAllowed === 'نعم' ? 'مسموح بالسفر' : 'ممنوع من السفر',
      'سجل المباينة': item.vettingResult || 'سليم أمنياً',
      'البيانات الإضافية (الأعمدة الفائضة)': item.additionalData || '-',
      'ملاحظات': item.notes || '',
    };
    return row;
  });

  const ws = XLSX.utils.json_to_sheet(formattedData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "كشف_المسافرين");
  XLSX.writeFile(wb, `${fileName}.xlsx`);
};

/**
 * Export array of data to CSV with UTF-8 BOM so Arabic displays properly in Excel
 */
export const exportToCSV = (data: any[], fileName: string, columnMap?: Record<string, string>) => {
  if (!data || data.length === 0) return;

  // Format data with Arabic columns
  const formattedData = data.map((item, idx) => {
    return {
      '#': idx + 1,
      'الاسم الكامل': item.fullName || [item.firstName, item.secondName, item.thirdName, item.lastName].filter(Boolean).join(' ') || '-',
      'رقم الوثيقة': item.idNumber || '-',
      'نوع الوثيقة': item.idType || 'جواز سفر',
      'الجنسية': item.country || 'اليمن',
      'نوع الحركة': item.movementType || 'عام',
      'المنفذ': item.entryPort || item.exitPort || item.center || '-',
      'القرار الأمني': item.travelAllowed === 'نعم' ? 'مسموح بالسفر' : 'ممنوع من السفر',
      'سجل المباينة': item.vettingResult || 'سليم أمنياً',
      'البيانات الإضافية (الأعمدة الفائضة)': (item.additionalData || '').replace(/\n/g, ' | '),
      'ملاحظات': item.notes || '',
    };
  });

  const keys = Object.keys(formattedData[0]);
  const headers = keys.map(k => columnMap && columnMap[k] ? columnMap[k] : k);
  const headerLine = headers.map(h => `"${String(h).replace(/"/g, '""')}"`).join(',');

  const rows = formattedData.map(item => {
    return keys.map(k => {
      const val = (item as any)[k] === null || (item as any)[k] === undefined ? '' : String((item as any)[k]);
      return `"${val.replace(/"/g, '""')}"`;
    }).join(',');
  });

  // UTF-8 BOM for Arabic compatibility in Excel
  const BOM = '\uFEFF';
  const csvContent = BOM + [headerLine, ...rows].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  saveAs(blob, `${fileName}.csv`);
};

/**
 * Export data object or array to JSON format
 */
export const exportToJSON = (data: any, fileName: string) => {
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
  saveAs(blob, `${fileName}.json`);
};

/**
 * Full System Backup of all Port records into a single JSON file
 */
export const exportFullSystemBackup = () => {
  const backup = {
    appName: 'نظام المنافذ والجوازات الذكي',
    version: '1.2.0',
    exportDate: new Date().toISOString(),
    config: {
      centerName: localStorage.getItem('config_centerName') || 'منفذ الوديعة البري',
      agencyName: localStorage.getItem('config_agencyName') || 'فرع مصلحة الجوازات',
      region: localStorage.getItem('config_region') || 'حضرموت',
      branchCode: localStorage.getItem('config_branchCode') || 'SHW-01',
    },
    travelers: JSON.parse(localStorage.getItem('travelers') || '[]'),
    reports: JSON.parse(localStorage.getItem('reports') || '[]'),
    movements: JSON.parse(localStorage.getItem('movements') || '[]'),
    users: JSON.parse(localStorage.getItem('users') || '[]').map((u: any) => {
      const { password: _, ...safeUser } = u;
      return safeUser;
    }),
  };

  const dateStr = new Date().toISOString().split('T')[0];
  exportToJSON(backup, `smart_ports_backup_${dateStr}`);
};

/**
 * Restore Full System Backup from a JSON file
 */
export const restoreFullSystemBackup = async (file: File): Promise<{ success: boolean; message: string; count?: any }> => {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const data = JSON.parse(text);

        if (!data || typeof data !== 'object') {
          resolve({ success: false, message: 'ملف النسخة الاحتياطية غير صالح' });
          return;
        }

        let travelersCount = 0;
        let reportsCount = 0;
        let movementsCount = 0;

        if (Array.isArray(data.travelers)) {
          localStorage.setItem('travelers', JSON.stringify(data.travelers));
          travelersCount = data.travelers.length;
        }

        if (Array.isArray(data.reports)) {
          localStorage.setItem('reports', JSON.stringify(data.reports));
          reportsCount = data.reports.length;
        }

        if (Array.isArray(data.movements)) {
          localStorage.setItem('movements', JSON.stringify(data.movements));
          movementsCount = data.movements.length;
        }

        if (data.config) {
          if (data.config.centerName) localStorage.setItem('config_centerName', data.config.centerName);
          if (data.config.agencyName) localStorage.setItem('config_agencyName', data.config.agencyName);
          if (data.config.region) localStorage.setItem('config_region', data.config.region);
          if (data.config.branchCode) localStorage.setItem('config_branchCode', data.config.branchCode);
        }

        resolve({ 
          success: true, 
          message: `تم استعادة النسخة الاحتياطية بنجاح (${travelersCount} مسافر، ${reportsCount} بلاغ، ${movementsCount} حركة)`,
          count: { travelersCount, reportsCount, movementsCount }
        });
      } catch (err: any) {
        resolve({ success: false, message: 'فشل قراءة ملف النسخة الاحتياطية: ' + err.message });
      }
    };
    reader.onerror = () => resolve({ success: false, message: 'فشل قراءة الملف' });
    reader.readAsText(file);
  });
};

export const exportToImage = async (elementId: string, fileName: string) => {
  const node = document.getElementById(elementId);
  if (!node) return;
  
  const dataUrl = await toPng(node, { backgroundColor: '#fff' });
  saveAs(dataUrl, `${fileName}.png`);
};

export const exportToPDF = async (elementId: string, fileName: string) => {
  const node = document.getElementById(elementId);
  if (!node) return;

  const dataUrl = await toPng(node, { backgroundColor: '#fff', quality: 0.95 });
  const pdf = new jsPDF('p', 'mm', 'a4');
  const imgProps = pdf.getImageProperties(dataUrl);
  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
  
  pdf.addImage(dataUrl, 'PNG', 0, 0, pdfWidth, pdfHeight);
  pdf.save(`${fileName}.pdf`);
};

export const exportToWord = async (
  titleOrData: string | any[], 
  dataOrFileName?: Record<string, any> | string, 
  optionalFileName?: string
) => {
  const cfg = getOfficialHeaderConfig();
  const dateStr = new Date().toLocaleDateString('ar-YE');

  // Case 1: titleOrData is an Array (e.g. travelers dataset)
  if (Array.isArray(titleOrData)) {
    const list = titleOrData;
    const resolvedFileName = (typeof dataOrFileName === 'string' ? dataOrFileName : optionalFileName) || 'كشف_المسافرين';
    const docTitle = `كشف حركة المسافرين والسجلات الرسمية (${list.length} سجل)`;

    const tableRows = [
      // Table Header Row
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph({ text: '#', bold: true, alignment: AlignmentType.CENTER })], width: { size: 5, type: WidthType.PERCENTAGE } }),
          new TableCell({ children: [new Paragraph({ text: 'الاسم الكامل', bold: true, alignment: AlignmentType.RIGHT })], width: { size: 25, type: WidthType.PERCENTAGE } }),
          new TableCell({ children: [new Paragraph({ text: 'الجنسية', bold: true, alignment: AlignmentType.CENTER })], width: { size: 10, type: WidthType.PERCENTAGE } }),
          new TableCell({ children: [new Paragraph({ text: 'رقم الوثيقة', bold: true, alignment: AlignmentType.CENTER })], width: { size: 15, type: WidthType.PERCENTAGE } }),
          new TableCell({ children: [new Paragraph({ text: 'نوع الحركة', bold: true, alignment: AlignmentType.CENTER })], width: { size: 10, type: WidthType.PERCENTAGE } }),
          new TableCell({ children: [new Paragraph({ text: 'القرار الأمني', bold: true, alignment: AlignmentType.CENTER })], width: { size: 15, type: WidthType.PERCENTAGE } }),
          new TableCell({ children: [new Paragraph({ text: 'البيانات الإضافية (الفائضة)', bold: true, alignment: AlignmentType.RIGHT })], width: { size: 20, type: WidthType.PERCENTAGE } }),
        ],
      }),
      // Table Data Rows
      ...list.slice(0, 100).map((t, idx) => {
        const fullName = t.fullName || [t.firstName, t.secondName, t.thirdName, t.lastName].filter(Boolean).join(' ') || '-';
        const addData = (t.additionalData || '-').replace(/\n/g, ' | ');
        return new TableRow({
          children: [
            new TableCell({ children: [new Paragraph({ text: String(idx + 1), alignment: AlignmentType.CENTER })], width: { size: 5, type: WidthType.PERCENTAGE } }),
            new TableCell({ children: [new Paragraph({ text: fullName, bold: true, alignment: AlignmentType.RIGHT })], width: { size: 25, type: WidthType.PERCENTAGE } }),
            new TableCell({ children: [new Paragraph({ text: t.country || 'اليمن', alignment: AlignmentType.CENTER })], width: { size: 10, type: WidthType.PERCENTAGE } }),
            new TableCell({ children: [new Paragraph({ text: t.idNumber || '-', alignment: AlignmentType.CENTER })], width: { size: 15, type: WidthType.PERCENTAGE } }),
            new TableCell({ children: [new Paragraph({ text: t.movementType || 'عام', alignment: AlignmentType.CENTER })], width: { size: 10, type: WidthType.PERCENTAGE } }),
            new TableCell({ children: [new Paragraph({ text: t.travelAllowed === 'نعم' ? 'مسموح' : 'ممنوع', alignment: AlignmentType.CENTER })], width: { size: 15, type: WidthType.PERCENTAGE } }),
            new TableCell({ children: [new Paragraph({ text: addData, alignment: AlignmentType.RIGHT })], width: { size: 20, type: WidthType.PERCENTAGE } }),
          ],
        });
      }),
    ];

    const doc = new Document({
      sections: [
        {
          properties: { textDirection: 'rtl' as any },
          children: [
            new Paragraph({
              children: [new TextRun({ text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', bold: true, size: 22 })],
              alignment: AlignmentType.CENTER,
            }),
            new Paragraph({
              children: [new TextRun({ text: cfg.country, bold: true, size: 26 })],
              alignment: AlignmentType.CENTER,
            }),
            new Paragraph({
              children: [new TextRun({ text: cfg.ministry, size: 22 })],
              alignment: AlignmentType.CENTER,
            }),
            new Paragraph({
              children: [new TextRun({ text: `${cfg.agencyName} - ${cfg.centerName}`, size: 20, bold: true })],
              alignment: AlignmentType.CENTER,
            }),
            new Paragraph({ text: "", spacing: { after: 300 } }),
            new Paragraph({
              children: [new TextRun({ text: docTitle, bold: true, size: 28, underline: {} })],
              alignment: AlignmentType.CENTER,
              spacing: { after: 300 },
            }),
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: tableRows,
            }),
            new Paragraph({ text: "", spacing: { before: 600 } }),
            new Paragraph({
              children: [new TextRun({ text: `تاريخ التصدير: ${dateStr}م · ${cfg.centerName}`, size: 18 })],
              alignment: AlignmentType.LEFT,
            }),
          ],
        },
      ],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, `${resolvedFileName}.docx`);
    return;
  }

  // Case 2: titleOrData is string, dataOrFileName is Record
  const docTitle = String(titleOrData);
  const data = (dataOrFileName as Record<string, any>) || {};
  const resolvedFileName = optionalFileName || 'مستند_رسمي';

  const doc = new Document({
    sections: [
      {
        properties: { textDirection: 'rtl' as any },
        children: [
          new Paragraph({
            children: [new TextRun({ text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', bold: true, size: 22 })],
            alignment: AlignmentType.CENTER,
          }),
          new Paragraph({
            children: [new TextRun({ text: cfg.country, bold: true, size: 28 })],
            alignment: AlignmentType.CENTER,
          }),
          new Paragraph({
            children: [new TextRun({ text: cfg.ministry, size: 24 })],
            alignment: AlignmentType.CENTER,
          }),
          new Paragraph({
            children: [new TextRun({ text: `${cfg.agencyName} - ${cfg.centerName}`, size: 22 })],
            alignment: AlignmentType.CENTER,
          }),
          new Paragraph({ text: "", spacing: { after: 400 } }),
          new Paragraph({
            children: [new TextRun({ text: docTitle, bold: true, size: 32, underline: {} })],
            alignment: AlignmentType.CENTER,
            spacing: { after: 400 },
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: Object.entries(data).map(([key, value]) => (
              new TableRow({
                children: [
                  new TableCell({
                    children: [new Paragraph({ text: String(value || '-'), alignment: AlignmentType.RIGHT })],
                    width: { size: 70, type: WidthType.PERCENTAGE },
                  }),
                  new TableCell({
                    children: [new Paragraph({ text: key, bold: true, alignment: AlignmentType.RIGHT })],
                    width: { size: 30, type: WidthType.PERCENTAGE },
                  }),
                ],
              })
            )),
          }),
          new Paragraph({ text: "", spacing: { before: 800 } }),
          new Paragraph({
            children: [new TextRun({ text: `تاريخ التصدير: ${dateStr}م · ${cfg.centerName}`, size: 18 })],
            alignment: AlignmentType.LEFT,
          }),
        ],
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, `${resolvedFileName}.docx`);
};

export const handlePrint = () => {
  window.print();
};

