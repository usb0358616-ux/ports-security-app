export type TravelerCategory = 
  | 'traveler'               // كافة المسافرين (القاعدة الأساسية)
  | 'foreigner'              // الأجانب (القاعدة الأساسية لغير اليمنيين)
  | 'entry'                  // حركة الدخول
  | 'exit'                   // حركة الخروج
  | 'illegal_immigrant'      // المهاجرين غير الشرعيين
  | 'refugee'                // اللاجئين
  | 'visa_renewal'           // التأشيرات (طلب وتجديد تأشيرة)
  | 'residency_renewal'      // الإقامات (طلب وتجديد إقامة)
  | 'marriage_yemeni_woman'  // طلب زواج بيمنية
  | 'marriage_foreigner'     // طلب زواج بأجنبي
  | 'citizenship_application'// طالب جنسية يمنية
;

export type MovementType = 'دخول' | 'خروج' | 'عام' | 'ترانزيت';

export interface Traveler {
  id: string;
  category?: TravelerCategory;
  additionalCategories?: TravelerCategory[]; // Cross-referenced categories
  isForeigner?: boolean; // Flagged true automatically if non-Yemeni
  movementType?: MovementType; // Entry or Exit movement

  fullName?: string; // Unified full name field (first, second, third, fourth, and last name)
  firstName: string;
  secondName: string;
  thirdName: string;
  fourthName: string;
  lastName: string;
  age: number;
  idNumber: string;
  idType: string;
  country: string; // Nationality
  governorate: string;
  phone: string;
  
  // Passports, Visas, and Residencies issue and expiry dates
  passportIssueDate?: string;
  passportExpiryDate?: string;
  visaIssueDate?: string;
  visaExpiryDate?: string;
  residencyIssueDate?: string;
  residencyExpiryDate?: string;

  // Security & Vetting
  vettingResult: string;
  vettingResult1?: string;
  vettingResult2?: string;
  vettingResult3?: string;
  vettingResult4?: string;
  destination: string;
  visitReason: string;
  investigatingOfficer: string;
  travelAllowed: 'نعم' | 'لا';
  center?: string;
  agency?: string;
  receiveDate?: string;
  status?: string;
  returnReason?: string;
  visaType?: string;
  requestNumber?: string;
  photoUrl?: string;
  documentsUrls?: string[];
  linkedReportIds?: string[];

  // Additional Data & Excess Excel Fields (بيانات إضافية مجمعة من الأعمدة الفائضة في الإكسل)
  additionalData?: string; // بصيغة: اسم العمود / القيمة
  notes?: string; // ملاحظات عامة

  // Entry specific fields (حركة الدخول)
  entryPort?: string;
  entryDate?: string;
  originCountry?: string; // جهة القدوم
  entryCarrierOrFlight?: string; // رقم الرحلة / وسيلة النقل
  entryPurpose?: string; // الغرض من الدخول
  allowedStayDays?: number | string; // مدة الإقامة المصرح بها

  // Exit specific fields (حركة الخروج)
  exitPort?: string;
  exitDate?: string;
  destinationCountry?: string; // جهة المغادرة
  exitCarrierOrFlight?: string; // رقم رحلة الخروج / المركبة
  exitPurpose?: string; // سبب المغادرة
  exitPermitNumber?: string; // رقم تصريح الخروج / خروج وعودة

  // Foreigners specific fields (شؤون الأجانب)
  sponsorName?: string;
  sponsorPhone?: string;
  sponsorAddress?: string;

  // Undocumented / Illegal Immigrants specific fields
  interceptionPoint?: string;
  interceptionDate?: string;
  smugglingRoute?: string;
  biometricsTaken?: 'نعم' | 'لا' | 'قيد الإجراء';
  healthStatus?: string;
  deportationStatus?: 'قيد التحقيق' | 'محتجز' | 'قرار ترحيل' | 'تم الترحيل';
  interceptingUnit?: string;

  // Refugees specific fields
  unhcrNumber?: string;
  refugeeStatus?: 'طالب لجوء' | 'لاجئ معترف به' | 'حماية مؤقتة';
  campLocation?: string;
  aidOrganization?: string;
  dependentsCount?: number;

  // Visa specific fields
  visaNumber?: string;
  requestedVisaPeriod?: string;
  visaExtensionReason?: string;
  visaFeeStatus?: 'مسدد' | 'غير مسدد' | 'معفى';
  visaRequestStatus?: 'قيد المراجعة' | 'معتمد' | 'مرفوض';
  visaReceiptNumber?: string;

  // Residency specific fields
  residencyNumber?: string;
  profession?: string;
  employerName?: string;
  requestedResidencyPeriod?: string;
  medicalTestStatus?: 'لائق' | 'غير لائق' | 'قيد الفحص';
  residencyFeeStatus?: 'مسدد' | 'غير مسدد' | 'معفى';
  residencyRequestStatus?: 'قيد الإجراء' | 'معتمد ومجدد' | 'مرفوض';
  residencyReceiptNumber?: string;

  // Marriage to Yemeni Woman specific fields (طلب زواج بيمنية)
  spouseFullName?: string; // اسم الزوجة اليمنية
  spouseIdNumber?: string; // رقم بطاقة الزوجة
  marriageContractNumber?: string; // رقم عقد الزواج أو الطلب
  marriageContractDate?: string; // تاريخ العقد
  courtOrAuthority?: string; // المحكمة الشرعية أو الجهة المصادقة
  marriageApprovalStatus?: 'قيد الدراسة والتحري' | 'موافقة أمنية معتمدة' | 'مرفوض';
  marriageGuardianName?: string; // ولي الأمر

  // Marriage to Foreigner specific fields (طلب زواج بأجنبي)
  foreignSpouseName?: string; // اسم الطرف الأجنبي
  foreignSpouseNationality?: string; // جنسية الطرف الأجنبي
  foreignSpousePassport?: string; // جواز الطرف الأجنبي
  foreignMarriageApprovalNumber?: string; // رقم تصريح الزواج

  // Yemeni Citizenship Application specific fields (طالب جنسية يمنية)
  citizenshipFileNumber?: string; // رقم ملف الجنسية
  citizenshipApplicationDate?: string; // تاريخ تقديم الطلب
  residenceYearsInYemen?: number | string; // سنوات الإقامة المتصلة بالجمهورية
  motherNationality?: string; // جنسية الأم (في حال أبناء اليمنيات)
  citizenshipReason?: 'إقامة طويلة مستمرة' | 'ابن مواطنة يمنية' | 'زواج من مواطن يمني' | 'كفاءات وخدمات جليلة' | 'أخرى';
  citizenshipStatus?: 'قيد البحث والتحري' | 'استيفاء الشروط القانونية' | 'مرفوع للجنة العليا' | 'ممنوح بقرار جمهوري' | 'مرفوض';

  createdAt: string;
  updatedAt: string;
}

export interface Report {
  id: string;
  title: string;
  description: string;
  type: string;
  status: 'جديد' | 'قيد التحقيق' | 'معتمد' | 'مرفوض';
  attachments?: string[];
  linkedTravelerIds?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Movement {
  id: string;
  type: 'طقم' | 'دراجة نارية' | 'أخرى';
  plateNumber: string;
  driverName: string;
  personnelCount: number;
  mission: string;
  departureTime: string;
  expectedReturnTime: string;
  actualReturnTime?: string;
  outcome?: string;
  status: 'خروج' | 'عودة';
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  username: string;
  password?: string;
  role: 'آدمن' | 'ضابط' | 'مدخل بيانات';
  name: string;
  biometricEnabled?: boolean;
  biometricCredentialId?: string;
  biometricType?: 'fingerprint' | 'face' | 'both';
  createdAt?: string;
  lastLogin?: string;
}
