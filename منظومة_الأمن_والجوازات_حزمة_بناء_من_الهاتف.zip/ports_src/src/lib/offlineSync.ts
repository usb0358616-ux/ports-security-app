import { useState, useEffect } from 'react';

export interface SyncQueueItem {
  id: string;
  type: 'traveler' | 'report' | 'movement' | 'user';
  action: 'create' | 'update' | 'delete';
  data: any;
  timestamp: string;
  synced: boolean;
}

const SYNC_QUEUE_KEY = 'offline_sync_queue';
const LAST_SYNC_KEY = 'last_sync_timestamp';

export function getSyncQueue(): SyncQueueItem[] {
  try {
    const raw = localStorage.getItem(SYNC_QUEUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveSyncQueue(queue: SyncQueueItem[]) {
  try {
    localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(queue));
  } catch (err) {
    console.error('Failed to save sync queue:', err);
  }
}

export function queueOfflineAction(type: SyncQueueItem['type'], action: SyncQueueItem['action'], data: any) {
  const queue = getSyncQueue();
  const newItem: SyncQueueItem = {
    id: `sync_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
    type,
    action,
    data,
    timestamp: new Date().toISOString(),
    synced: false,
  };
  queue.push(newItem);
  saveSyncQueue(queue);

  // Trigger custom event so reactive hooks update immediately
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('offline-sync-queue-updated'));
  }
}

export function getLastSyncTime(): string {
  return localStorage.getItem(LAST_SYNC_KEY) || new Date().toISOString();
}

export function setLastSyncTime(isoDate: string) {
  localStorage.setItem(LAST_SYNC_KEY, isoDate);
}

export function clearSyncedQueue() {
  const queue = getSyncQueue().filter(item => !item.synced);
  saveSyncQueue(queue);
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('offline-sync-queue-updated'));
  }
}

export async function processSyncQueue(): Promise<{ processedCount: number; remainingCount: number }> {
  const queue = getSyncQueue();
  if (queue.length === 0) {
    setLastSyncTime(new Date().toISOString());
    return { processedCount: 0, remainingCount: 0 };
  }

  // Mark pending items as synced in offline storage ledger
  const updatedQueue = queue.map(item => ({ ...item, synced: true }));
  saveSyncQueue(updatedQueue);
  setLastSyncTime(new Date().toISOString());

  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('offline-sync-queue-updated'));
  }

  return { processedCount: queue.length, remainingCount: 0 };
}

/**
 * React hook to observe offline status and background sync queue
 */
export function useOfflineSync() {
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [queueCount, setQueueCount] = useState<number>(0);
  const [lastSync, setLastSync] = useState<string>(getLastSyncTime());
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  useEffect(() => {
    const updateQueue = () => {
      const q = getSyncQueue();
      setQueueCount(q.filter(i => !i.synced).length);
      setLastSync(getLastSyncTime());
    };

    updateQueue();

    const handleOnline = () => {
      setIsOnline(true);
      // Auto-trigger sync when returning online or network status flips
      triggerSync();
    };

    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('offline-sync-queue-updated', updateQueue);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('offline-sync-queue-updated', updateQueue);
    };
  }, []);

  const triggerSync = async () => {
    setIsSyncing(true);
    try {
      await processSyncQueue();
      setQueueCount(0);
      setLastSync(new Date().toISOString());
    } finally {
      setIsSyncing(false);
    }
  };

  return {
    isOnline,
    queueCount,
    lastSync,
    isSyncing,
    triggerSync,
  };
}
