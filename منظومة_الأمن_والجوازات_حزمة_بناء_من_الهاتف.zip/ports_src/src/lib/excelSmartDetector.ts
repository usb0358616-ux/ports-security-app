/**
 * Smart Excel Column Detection and Mapping Engine
 * 
 * Works 100% offline with comprehensive Arabic/English port vocabulary heuristics,
 * plus optional Gemini AI enhancement if available.
 */

export interface FieldMappingDefinition {
  fieldKey: string;
  label: string;
  description: string;
  categoryGroup: 'أساسي' | 'تواريخ ووثائق' | 'حركات ومنافذ' | 'أجانب وإقامات' | 'تأشيرات' | 'زواج وجنسية' | 'أمني ولجوء';
  synonyms: string[]; // Lowercase normalized synonyms in Arabic and English
}

export const KNOWN_SYSTEM_FIELDS: FieldMappingDefinition[] = [
  // Master & Personal
  {
    fieldKey: 'fullName',
    label: 'الاسم الكامل',
    description: 'الاسم الرباعي أو الخماسي واللقب',
    categoryGroup: 'أساسي',
    synonyms: [
      'الاسم الكامل', 'اسم المسافر', 'الاسم', 'اسم الشخص', 'الاسم رباعي', 'الاسم خماسي',
      'fullname', 'full_name', 'name', 'passenger_name', 'traveler_name', 'person_name'
    ]
  },
  {
    fieldKey: 'firstName',
    label: 'الاسم الأول',
    description: 'الاسم الشخصي الأول',
    categoryGroup: 'أساسي',
    synonyms: ['الاسم الاول', 'اسم اول', 'الاسم1', 'firstname', 'first_name', 'fname']
  },
  {
    fieldKey: 'secondName',
    label: 'اسم الأب',
    description: 'الاسم الثاني / والد',
    categoryGroup: 'أساسي',
    synonyms: ['اسم الاب', 'الاسم الثاني', 'الاب', 'father', 'father_name', 'second_name', 'secondname']
  },
  {
    fieldKey: 'thirdName',
    label: 'اسم الجد',
    description: 'الاسم الثالث',
    categoryGroup: 'أساسي',
    synonyms: ['اسم الجد', 'الاسم الثالث', 'الجد', 'grandfather', 'third_name', 'thirdname']
  },
  {
    fieldKey: 'fourthName',
    label: 'اسم والد الجد',
    description: 'الاسم الرابع',
    categoryGroup: 'أساسي',
    synonyms: ['الاسم الرابع', 'رابع', 'fourth_name', 'fourthname']
  },
  {
    fieldKey: 'lastName',
    label: 'اللقب / العائلة',
    description: 'اللقب أو اسم القبيلة/العائلة',
    categoryGroup: 'أساسي',
    synonyms: ['اللقب', 'العائله', 'القبيله', 'اسم العائله', 'lastname', 'last_name', 'surname', 'family_name']
  },
  {
    fieldKey: 'idNumber',
    label: 'رقم الوثيقة / الجواز',
    description: 'رقم جواز السفر أو البطاقة أو وثيقة الإثبات',
    categoryGroup: 'أساسي',
    synonyms: [
      'رقم الجواز', 'رقم الوثيقه', 'رقم الهويه', 'رقم البطاقه', 'رقم وثيقه السفر', 'رقم الاثبات',
      'passport', 'passport_no', 'passport_number', 'id_number', 'idnumber', 'id_no', 'doc_no', 'document_number'
    ]
  },
  {
    fieldKey: 'idType',
    label: 'نوع الوثيقة',
    description: 'جواز سفر، بطاقة شخصية، كرت لجوء، إلخ',
    categoryGroup: 'أساسي',
    synonyms: ['نوع الوثيقه', 'نوع الهويه', 'نوع الجواز', 'نوع الاثبات', 'id_type', 'doc_type', 'document_type']
  },
  {
    fieldKey: 'country',
    label: 'الجنسية / الدولة',
    description: 'جنسية المسافر أو الدولة التابع لها (أساسي لتوجيه الأجانب)',
    categoryGroup: 'أساسي',
    synonyms: ['الجنسيه', 'الدوله', 'البلد', 'الوطن', 'بلد الجنسيه', 'nationality', 'country', 'citizenship']
  },
  {
    fieldKey: 'age',
    label: 'العمر',
    description: 'عمر المسافر بالسنوات',
    categoryGroup: 'أساسي',
    synonyms: ['العمر', 'السن', 'سنوات العمر', 'age', 'years_old']
  },
  {
    fieldKey: 'phone',
    label: 'رقم الهاتف / التواصل',
    description: 'رقم هاتف المسافر أو جهة الاتصال',
    categoryGroup: 'أساسي',
    synonyms: ['الهاتف', 'رقم الهاتف', 'الجوال', 'الموبايل', 'التلفون', 'phone', 'phone_number', 'mobile', 'tel']
  },
  {
    fieldKey: 'governorate',
    label: 'المحافظة / المدينة',
    description: 'محافظة الإقامة أو الميلاد',
    categoryGroup: 'أساسي',
    synonyms: ['المحافظه', 'المدينه', 'المديريه', 'مكان الميلاد', 'governorate', 'city', 'province']
  },

  // Dates & Documents
  {
    fieldKey: 'passportIssueDate',
    label: 'تاريخ إصدار الجواز',
    description: 'تاريخ منح وثيقة السفر',
    categoryGroup: 'تواريخ ووثائق',
    synonyms: ['تاريخ اصدار الجواز', 'اصدار الجواز', 'تاريخ الاصدار', 'passport_issue_date', 'issue_date', 'passport_issued']
  },
  {
    fieldKey: 'passportExpiryDate',
    label: 'تاريخ انتهاء الجواز',
    description: 'تاريخ صلاحية الجواز (لتنبيهات الانتهاء)',
    categoryGroup: 'تواريخ ووثائق',
    synonyms: ['تاريخ انتهاء الجواز', 'انتهاء الجواز', 'صلاحيه الجواز', 'نهايه الجواز', 'passport_expiry_date', 'passport_exp', 'expiry_date']
  },
  {
    fieldKey: 'visaIssueDate',
    label: 'تاريخ إصدار التأشيرة',
    description: 'تاريخ منح تأشيرة الدخول/الخروج',
    categoryGroup: 'تواريخ ووثائق',
    synonyms: ['تاريخ اصدار التاشيره', 'اصدار التاشيره', 'منح التاشيره', 'visa_issue_date', 'visa_issued']
  },
  {
    fieldKey: 'visaExpiryDate',
    label: 'تاريخ انتهاء التأشيرة',
    description: 'تاريخ صلاحية التأشيرة (لتنبيهات أسبوع فأقل)',
    categoryGroup: 'تواريخ ووثائق',
    synonyms: ['تاريخ انتهاء التاشيره', 'انتهاء التاشيره', 'صلاحيه التاشيره', 'visa_expiry_date', 'visa_expiry', 'visa_exp']
  },
  {
    fieldKey: 'residencyIssueDate',
    label: 'تاريخ إصدار الإقامة',
    description: 'تاريخ منح الإقامة للأجنبي',
    categoryGroup: 'تواريخ ووثائق',
    synonyms: ['تاريخ اصدار الاقامه', 'اصدار الاقامه', 'منح الاقامه', 'residency_issue_date', 'iqama_issue']
  },
  {
    fieldKey: 'residencyExpiryDate',
    label: 'تاريخ انتهاء الإقامة',
    description: 'تاريخ انتهاء هوية مقيم / الإقامة للأجانب',
    categoryGroup: 'تواريخ ووثائق',
    synonyms: ['تاريخ انتهاء الاقامه', 'انتهاء الاقامه', 'صلاحيه الاقامه', 'نهايه الاقامه', 'residency_expiry_date', 'residency_exp', 'iqama_expiry']
  },

  // Movements & Ports (Entry / Exit)
  {
    fieldKey: 'movementType',
    label: 'نوع الحركة',
    description: 'دخول أو خروج أو ترانزيت (يوجه تلقائياً لتبويبات الدخول والخروج)',
    categoryGroup: 'حركات ومنافذ',
    synonyms: ['نوع الحركه', 'الحركه', 'الاتجاه', 'حركه المسافر', 'movement_type', 'movement', 'direction', 'travel_type']
  },
  {
    fieldKey: 'entryPort',
    label: 'منفذ الدخول',
    description: 'المنفذ الجوي أو البري أو البحري للقدوم',
    categoryGroup: 'حركات ومنافذ',
    synonyms: ['منفذ الدخول', 'منفذ القدوم', 'المنفذ', 'الميناء', 'المطار', 'entry_port', 'port_of_entry', 'arrival_port']
  },
  {
    fieldKey: 'entryDate',
    label: 'تاريخ الدخول',
    description: 'تاريخ الوصول الفعلي إلى المنفذ',
    categoryGroup: 'حركات ومنافذ',
    synonyms: ['تاريخ الدخول', 'تاريخ القدوم', 'تاريخ الوصول', 'entry_date', 'arrival_date', 'date_of_entry']
  },
  {
    fieldKey: 'originCountry',
    label: 'جهة القدوم / الدولة القادم منها',
    description: 'الدولة أو الجهة التي قدم منها المسافر',
    categoryGroup: 'حركات ومنافذ',
    synonyms: ['جهه القدوم', 'القادم منها', 'دوله القدوم', 'من اين قدم', 'origin_country', 'country_of_origin', 'arrived_from', 'origin']
  },
  {
    fieldKey: 'entryCarrierOrFlight',
    label: 'وسيلة النقل / رقم رحلة الدخول',
    description: 'رقم الرحلة الجوية أو حافلة النقل أو المركبة',
    categoryGroup: 'حركات ومنافذ',
    synonyms: ['رقم الرحله', 'وسيله النقل', 'الناقل', 'المركبه', 'flight_number', 'carrier', 'flight_no', 'vehicle']
  },
  {
    fieldKey: 'entryPurpose',
    label: 'الغرض من الدخول',
    description: 'زيارة، عمل، علاج، سياحة، إلخ',
    categoryGroup: 'حركات ومنافذ',
    synonyms: ['الغرض من الدخول', 'سبب القدوم', 'سبب الدخول', 'الغرض', 'entry_purpose', 'purpose_of_entry', 'visit_purpose']
  },
  {
    fieldKey: 'exitPort',
    label: 'منفذ الخروج',
    description: 'المنفذ الجوي أو البري أو البحري للمغادرة',
    categoryGroup: 'حركات ومنافذ',
    synonyms: ['منفذ الخروج', 'منفذ المغادره', 'exit_port', 'port_of_exit', 'departure_port']
  },
  {
    fieldKey: 'exitDate',
    label: 'تاريخ الخروج',
    description: 'تاريخ المغادرة الفعلي من المنفذ',
    categoryGroup: 'حركات ومنافذ',
    synonyms: ['تاريخ الخروج', 'تاريخ المغادره', 'تاريخ السفر', 'exit_date', 'departure_date', 'date_of_exit']
  },
  {
    fieldKey: 'destinationCountry',
    label: 'جهة المغادرة / الوجهة المقصودة',
    description: 'الدولة أو المدينة المسافر إليها',
    categoryGroup: 'حركات ومنافذ',
    synonyms: ['جهه المغادره', 'الوجهه', 'المسافر اليها', 'دوله المقصد', 'destination_country', 'destination', 'travel_destination']
  },
  {
    fieldKey: 'exitCarrierOrFlight',
    label: 'وسيلة النقل / رقم رحلة الخروج',
    description: 'رقم رحلة المغادرة أو المركبة',
    categoryGroup: 'حركات ومنافذ',
    synonyms: ['رقم رحله الخروج', 'رحله المغادره', 'exit_flight', 'departure_flight']
  },
  {
    fieldKey: 'exitPurpose',
    label: 'سبب المغادرة',
    description: 'سفر، علاج، عودة نهائية، إلخ',
    categoryGroup: 'حركات ومنافذ',
    synonyms: ['سبب المغادره', 'الغرض من السفر', 'سبب الخروج', 'exit_purpose', 'reason_for_exit']
  },

  // Foreigners & Residency
  {
    fieldKey: 'sponsorName',
    label: 'اسم الكفيل / المستضيف',
    description: 'اسم الشخص أو الشركة الضامنة للأجنبي',
    categoryGroup: 'أجانب وإقامات',
    synonyms: ['الكفيل', 'اسم الكفيل', 'المستضيف', 'الضامن', 'sponsor', 'sponsor_name', 'host_name', 'guarantor']
  },
  {
    fieldKey: 'sponsorPhone',
    label: 'هاتف الكفيل',
    description: 'رقم هاتف الكفيل أو الشركة',
    categoryGroup: 'أجانب وإقامات',
    synonyms: ['هاتف الكفيل', 'جوال الكفيل', 'تلفون الكفيل', 'sponsor_phone', 'sponsor_mobile']
  },
  {
    fieldKey: 'residencyNumber',
    label: 'رقم الإقامة / هوية مقيم',
    description: 'الرقم التسلسلي لبطاقة إقامة الأجنبي',
    categoryGroup: 'أجانب وإقامات',
    synonyms: ['رقم الاقامه', 'رقم هويه مقيم', 'رقم بطاقه الاقامه', 'residency_number', 'residency_no', 'iqama_no', 'residence_id']
  },
  {
    fieldKey: 'profession',
    label: 'المهنة / العمل',
    description: 'مهنة الأجنبي أو طبيعة العمل في الجمهورية',
    categoryGroup: 'أجانب وإقامات',
    synonyms: ['المهنه', 'الوظيفه', 'العمل', 'طبيعه العمل', 'profession', 'occupation', 'job', 'position']
  },
  {
    fieldKey: 'employerName',
    label: 'جهة العمل / صاحب العمل',
    description: 'اسم المنشأة أو المؤسسة أو صاحب العمل',
    categoryGroup: 'أجانب وإقامات',
    synonyms: ['جهه العمل', 'صاحب العمل', 'الشركه', 'المؤسسه', 'employer', 'employer_name', 'company']
  },

  // Visas
  {
    fieldKey: 'visaNumber',
    label: 'رقم التأشيرة',
    description: 'الرقم المرجعي أو التسلسلي للتأشيرة',
    categoryGroup: 'تأشيرات',
    synonyms: ['رقم التاشيره', 'رقم الفيزا', 'visa_number', 'visa_no', 'visa_id']
  },
  {
    fieldKey: 'visaType',
    label: 'نوع التأشيرة',
    description: 'تأشيرة دخول، مرور، زيارة، عمل، دبلوماسية، إلخ',
    categoryGroup: 'تأشيرات',
    synonyms: ['نوع التاشيره', 'نوع الفيزا', 'تصنيف التاشيره', 'visa_type', 'type_of_visa']
  },
  {
    fieldKey: 'requestedVisaPeriod',
    label: 'المدة المطلوبة للتأشيرة',
    description: 'المدة المحددة للتأشيرة (شهر، 3 أشهر، سنة)',
    categoryGroup: 'تأشيرات',
    synonyms: ['مده التاشيره', 'المدة المطلوبه', 'الفتره', 'visa_period', 'duration']
  },

  // Marriage & Yemeni Citizenship
  {
    fieldKey: 'spouseFullName',
    label: 'اسم الزوجة اليمنية',
    description: 'الاسم الكامل للزوجة في طلب زواج الأجنبي بيمنية',
    categoryGroup: 'زواج وجنسية',
    synonyms: ['اسم الزوجه اليمنيه', 'اسم الزوجه', 'الزوجه', 'yemeni_wife_name', 'spouse_name', 'wife_name']
  },
  {
    fieldKey: 'foreignSpouseName',
    label: 'اسم الطرف الأجنبي (طلب زواج)',
    description: 'اسم الأجنبي أو الأجنبية في طلب الزواج بأجنبي',
    categoryGroup: 'زواج وجنسية',
    synonyms: ['اسم الطرف الاجنبي', 'اسم الاجنبي', 'اسم الزوج الاجنبي', 'foreign_spouse_name', 'foreign_partner']
  },
  {
    fieldKey: 'foreignSpouseNationality',
    label: 'جنسية الطرف الأجنبي',
    description: 'جنسية الطرف الأجنبي في معاملات الزواج المختلط',
    categoryGroup: 'زواج وجنسية',
    synonyms: ['جنسيه الطرف الاجنبي', 'جنسيه الزوج الاجنبي', 'جنسيه الزوجه الاجنبيه', 'foreign_spouse_country', 'partner_nationality']
  },
  {
    fieldKey: 'citizenshipFileNumber',
    label: 'رقم ملف طلب الجنسية',
    description: 'رقم القيد أو الإحالة لملف طلب الحصول على الجنسية اليمنية',
    categoryGroup: 'زواج وجنسية',
    synonyms: ['رقم ملف الجنسيه', 'ملف الجنسيه', 'رقم طلب الجنسيه', 'citizenship_file', 'citizenship_number', 'citizenship_id']
  },

  // Security, Vetting & Reports
  {
    fieldKey: 'vettingResult',
    label: 'المباينة الأمنية / نتيجة الفحص',
    description: 'نتيجة المطابقة والتدقيق الأمني بالمنافذ',
    categoryGroup: 'أمني ولجوء',
    synonyms: ['المباينه', 'المباينه الامنيه', 'الفحص الامني', 'نتيجه الفحص', 'القيود الامنيه', 'vetting', 'vetting_result', 'security_check']
  },
  {
    fieldKey: 'travelAllowed',
    label: 'قرار مسموح بالسفر',
    description: 'نعم أو لا (منع من السفر / مصرح)',
    categoryGroup: 'أمني ولجوء',
    synonyms: ['مسموح بالسفر', 'القرار', 'قرار السفر', 'حاله السفر', 'travel_allowed', 'allowed_to_travel', 'status_travel']
  },
  {
    fieldKey: 'unhcrNumber',
    label: 'رقم قيد المفوضية (اللاجئين)',
    description: 'رقم ملف اللجوء المسجل لدى المفوضية السامية UNHCR',
    categoryGroup: 'أمني ولجوء',
    synonyms: ['رقم المفوضيه', 'رقم اللجوء', 'كرت اللجوء', 'ملف اللجوء', 'unhcr_number', 'unhcr_no', 'refugee_number']
  },
  {
    fieldKey: 'interceptionPoint',
    label: 'نقطة الضبط (الهجرة غير الشرعية)',
    description: 'موقع أو نقطة ضبط المهاجر غير الشرعي',
    categoryGroup: 'أمني ولجوء',
    synonyms: ['نقطه الضبط', 'موقع الضبط', 'مكان التوقيف', 'نقطه الاحتجاز', 'interception_point', 'arrest_point']
  },
  // Additional / Excess Data
  {
    fieldKey: 'additionalData',
    label: 'بيانات إضافية / حقول فائضة',
    description: 'تجميع الحقول الزائدة من الإكسل بصيغة: اسم العمود / القيمة',
    categoryGroup: 'أساسي',
    synonyms: [
      'بيانات اضافيه', 'حقول اضافيه', 'معلومات اضافيه', 'بيانات زائده', 'حقول زائده', 
      'بيانات اخرى', 'معلومات اخرى', 'ملاحظات', 'اضافي', 'extra_data', 'additional_data', 'notes'
    ]
  },
];

/**
 * Normalizes any header string by removing diacritics, symbols, extra spaces,
 * and converting Arabic variations (أ/إ/آ -> ا, ة -> ه, ى -> ي).
 */
export const normalizeColumnHeader = (header: string): string => {
  if (!header) return '';
  return String(header)
    .trim()
    .toLowerCase()
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[_\-\/\.\:\(\)\[\]]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
};

/**
 * Smart Offline Column Matcher
 * Computes match confidence between an Excel column and all known system fields.
 */
export const autoMatchColumn = (
  excelCol: string
): { matchedField: string | null; confidence: number; label: string } => {
  const normExcel = normalizeColumnHeader(excelCol);
  if (!normExcel) {
    return { matchedField: null, confidence: 0, label: 'تجاهل هذا العمود' };
  }

  let bestField: string | null = null;
  let bestConfidence = 0;
  let bestLabel = 'تجاهل هذا العمود';

  for (const def of KNOWN_SYSTEM_FIELDS) {
    for (const syn of def.synonyms) {
      const normSyn = normalizeColumnHeader(syn);

      // Exact normalized match -> 100% confidence
      if (normExcel === normSyn) {
        return { matchedField: def.fieldKey, confidence: 1.0, label: def.label };
      }

      // Exact substring or containment
      if (normExcel.includes(normSyn) || normSyn.includes(normExcel)) {
        const score = Math.min(normSyn.length, normExcel.length) / Math.max(normSyn.length, normExcel.length);
        if (score > bestConfidence) {
          bestConfidence = score;
          bestField = def.fieldKey;
          bestLabel = def.label;
        }
      }
    }
  }

  // Threshold: if score is >= 0.5, accept match
  if (bestConfidence >= 0.5 && bestField) {
    return { matchedField: bestField, confidence: bestConfidence, label: bestLabel };
  }

  return { matchedField: null, confidence: 0, label: 'تجاهل هذا العمود' };
};

/**
 * Generates an initial mapping dictionary for all columns found in an uploaded Excel file.
 */
export const generateInitialMapping = (excelColumns: string[]): Record<string, string> => {
  const mapping: Record<string, string> = {};
  const assignedFields = new Set<string>();

  excelColumns.forEach(col => {
    const match = autoMatchColumn(col);
    if (match.matchedField && !assignedFields.has(match.matchedField)) {
      mapping[col] = match.matchedField;
      assignedFields.add(match.matchedField);
    } else {
      mapping[col] = ''; // unmapped / ignore
    }
  });

  return mapping;
};

/**
 * Extracts all excess, unmapped, or ignored columns for a given row and formats them
 * according to the user's specification:
 * اسم العمود / القيمة
 * 
 * Example:
 * رقم محضر الضبط / 123
 * نيتتبنبت / هاةكتتتنت
 */
export const extractExcessRowData = (
  rawRow: Record<string, any>,
  columnMapping: Record<string, string>
): string => {
  const lines: string[] = [];

  // 1. Process explicit additionalData mapping first if any
  Object.entries(columnMapping).forEach(([col, fieldKey]) => {
    if (fieldKey === 'additionalData') {
      const val = rawRow[col];
      if (val !== undefined && val !== null && String(val).trim() !== '') {
        lines.push(`${col} / ${String(val).trim()}`);
      }
    }
  });

  // 2. Process all columns in the row that have NO mapping (ignored / unassigned)
  Object.entries(rawRow).forEach(([col, val]) => {
    const assignedField = columnMapping[col];
    // If not mapped to any known field (and not already processed as additionalData above)
    if (!assignedField || assignedField === '') {
      if (val !== undefined && val !== null && String(val).trim() !== '') {
        lines.push(`${col} / ${String(val).trim()}`);
      }
    }
  });

  return lines.join('\n');
};
