import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ye.gov.portssecurity',
  appName: 'منظومة الأمن والجوازات والمنافذ',
  webDir: 'dist'
};

export default config;
